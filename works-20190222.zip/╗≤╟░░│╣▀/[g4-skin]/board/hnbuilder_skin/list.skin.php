<?
/* hn_skin
 * =======================================================================
 * Author : Huon
 * URL : http://huon.co.kr
 * ======================================================================= */
// hn_resize_image.lib.php 사용
// 여분필드는 bo_1에만 썸네일 너비 지정
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

$thumb_width = $board[bo_1];
if (!$thumb_width) alert("게시판 설정 : 여분 필드 1 에 목록에서 보여질 이미지의 폭을 설정하십시오. (픽셀 단위)");
if (!function_exists("imagecopyresampled")) alert("GD 2.0.1 이상 버전이 설치되어 있어야 사용할 수 있는 갤러리 게시판 입니다.");

//썸네일 라이브러리
if (!is_file($g4[path]."/lib/hn_resize_image.lib.php")) {
	alert(" hn_resize_image 라이브러리가 필요합니다. \\n\\n \'\/lib\' 폴더에 썸네일 라이브러리를 설치하시고 사용하세요.\\n");
} else {
	include_once($g4[path]."/lib/hn_resize_image.lib.php");
}

$data_path = $g4[path]."/data/file/$bo_table";
$thumb_path = $data_path.'/thumb';

@mkdir($thumb_path, 0707);
@chmod($thumb_path, 0707);

// 내용 길이
$content_length = 360;

// 이미지 크기
$view_w=$board[bo_1];
//$view_h=(int)($board[bo_1]*0.75);

$mod = $board[bo_gallery_cols];
$img_td_width = (int)(100 / $mod);

// 이미지 롤오버 효과
$img_normal_color="#f5f5f5";
$img_over_color="#ffcc11";

// CSS용 폭 지정
if($board[bo_table_width] < 100) {
	$bo_width = $board[bo_table_width]."%";
} else {
	$bo_width = $board[bo_table_width]."px";
}

// 제목이 두줄로 표시되는 경우 이 코드를 사용해 보세요.
// <nobr style='display:block; overflow:hidden; width:000px;'>제목</nobr>
?>
<!-- 스타일시트 -->
<link href="<?=$board_skin_path?>/hn_skin.css" rel="stylesheet" type="text/css">
<style type="text/css">
.imgBoxOut { margin:0 0 8px; width:<?=$view_w+2?>px; border:<?=$img_normal_color?> solid 4px; }
.imgBoxIn { overflow:hidden; width:<?=$view_w?>px; }
</style>

<?/*
<div style="text-align:center">
<span style="font-family: '맑은 고딕'; line-height: 1.5; letter-spacing:-1px; font-size:16px; color:#00b0f0">휴온빌더 사용자용 스킨</span><br>
<span style="color:#777;">- 휴온빌더 사용권이 있으면 모든 스킨을 이용할 수 있습니다. -</span>
</div>


<div class="listTitle">
<img src='<?=$board_skin_path?>/img/hnbuilder_skin.gif' border=0 align=absmiddle>
</div>


<div class="listInfo">
휴온빌더 스킨은 그누보드4, 그누보드5와 호환됩니다.
</div>

*/?>

<? if ($admin_href) { ?>
<!-- 분류 셀렉트 박스, 게시물 몇건, 관리자화면 링크 -->
<div id="listTop" style="width:<?=$bo_width?>;">
<!-- 기본 카테고리 
       <div class="category">
            <form name="fcategory" method="get" style="margin:0px;">
            <? if ($is_category) { ?>
            <select name=sca onchange="location='<?=$category_location?>'+<?=strtolower($g4[charset])=='utf-8' ? "encodeURIComponent(this.value)" : "this.value"?>;">
            <option value=''>전체</option>
            <?=$category_option?>
            </select>
            <? } ?>
            </form>
        </div>
-->		

        <div class="adminArticle">            
            <span style="color:#888888; font-weight:bold;">Total <?=number_format($total_count)?></span>
            <? if ($rss_href) { ?><a href="<?=$rss_href?>" class="hnBtn">RSS</a><?}?>
            <? if ($admin_href) { ?><a href="<?=$admin_href?>"  class="hnBtn admin">관리자</a><?}?>
        </div>
        <div style="clear:both;"></div>
</div>
<?}?>

<? 
// 탭 카테고리
if($is_category) { 
	include $board_skin_path."/category.inc.php";
} 
?>

<form name="fboardlist" method="post">
<input type="hidden" name="bo_table" value="<?=$bo_table?>">
<input type="hidden" name="sfl"  value="<?=$sfl?>">
<input type="hidden" name="stx"  value="<?=$stx?>">
<input type="hidden" name="spt"  value="<?=$spt?>">
<input type="hidden" name="page" value="<?=$page?>">
<input type="hidden" name="sw"   value="">

<div id="hnSkin" style="width:<?=$bo_width?>;">
<ul class="skinList">
<?
//목록 출력
for ($i=0; $i<count($list); $i++)
{
    if ($i && $i%$mod==0)
        echo "</tr><tr>\n";

    $noimg = "<img src='$board_skin_path/img/noimage.gif' border=0 width='$board[bo_1]' alt=''>";

    $thumb_file = $thumb_path.'/'.$list[$i][wr_id];
    //썸네일이 없다면 생성하기
    if (!is_file($thumb_file)) {
	    //썸네일 생성
	    $org_file = $list[$i][file][0][path] .'/'. $list[$i][file][0][file];
	    if(is_file($org_file)) {
		    $thumb_file = $thumb_path."/".$list[$i][wr_id];
		    //만일 썸네일 생성하지 못하면 원본을 썸네일로 사용한다.
	    	if(!hn_resize_image($org_file, $thumb_file, $thumb_width))
	    			$thumb_file = $org_file;
    	}
    }

	//썸네일이 있다면
    if (is_file($thumb_file)) {
	    $thumb_info = getimagesize($thumb_file);
	    $thumb_height = $thumb_info[1];
        $img = "<img src='$thumb_file' width='$thumb_width' height='auto' border=0>";
    } else {
	    $img = $noimg;
    }

    //새글
    if ($list[$i][icon_new])
    	$subject = "<span class='textNew'>".cut_str($list[$i][subject],30)."</span>";
    else
    	$subject = cut_str($list[$i][subject],30);

    $comment_cnt = "";
    if ($list[$i][comment_cnt])
        $comment_cnt = " <span class='listComment'><a href=\"{$list[$i][comment_href]}\">{$list[$i][comment_cnt]}</a></span>";

  	// 이미지 영역의 최대 높이 조절
  	$max_h = (int)($thumb_width*0.76);
  	if($thumb_height > $max_h) {
  		$hn_imgbox_h = $max_h;
	} else {
		$hn_imgbox_h = $thumb_height;
	}

	//이미지가 테두리보다 큰 경우 중앙정렬
	$img_margin_top = "margin-top:0px;";
	if($thumb_height > $hn_imgbox_h) {
  		$image_top = (int)(($thumb_height - $hn_imgbox_h)/2);
  		$img_margin_top = "margin-top:-".$image_top."px;";
	}
?>
<li>
	<div class="thumbs"><a href="<?=$list[$i][href]?>"><?=$img?></a></div>
	<h3><? if ($is_checkbox) { ?><input type=checkbox name=chk_wr_id[] value='<?=$list[$i][wr_id]?>'><? }  ?>
	<a href="<?=$list[$i][href]?>"><?=$list[$i][wr_subject]?></a>
	<?  if ($list[$i][icon_new]) { ?> <img src='<?=$board_skin_path?>/img/icon_new.gif' border=0 align=absmiddle> <? } ?>
    <?  if ($list[$i][icon_hot]) { ?> <img src='<?=$board_skin_path?>/img/icon_hot.gif' border=0 align=absmiddle> <? } ?>
	<?=$comment_cnt?>
	<span class="skinName">&nbsp;
	<? if($list[$i][wr_5]=="1") { ?> <span class="signG5">g5</span><? } ?>
	<? if($list[$i][wr_4]=="1") { ?> <span class="signG4">g4</span><? } ?>
	</span>
	</h3>		
	<p><a href="<?=$list[$i][href]?>"><?=cut_str(strip_tags($list[$i][wr_2]), $content_length,"...")?></a></p>
	<div class="date">
	<? if($list[$i][ca_name]) echo "<a href='{$g4[bbs_path]}/board.php?bo_table={$bo_table}&sca={$list[$i][ca_name]}'>".$list[$i][ca_name]."</a> / "; ?>
	<?=$list[$i][datetime2]?> / hit:<?=$list[$i][wr_hit]?>
	</div> 	
</li>
<?
}
?>

<? if (count($list) == 0) { echo "<li><p>준비 중입니다.</p></li>"; } ?>
</ul>
</div><!-- /#hnSkin -->

</form>

<script>
$(function() {
/*
// 목록 클릭시 게시물로 이동 
$('.skinList li').click(function() {	
	var url = $(this).find('a:first').attr('href');
	$(location).attr('href',url);	
});
*/
});
</script>

<div id="hnListBtn" style="width:<?=$bo_width?>;">
<div class="btnLeft">
	<? if ($list_href) { ?><a href="<?=$list_href?>"  class="hnBtn">목록</a><? } ?>
	<? if ($is_checkbox) { ?>
	<a href="javascript:select_delete();"  class="hnBtn narrowBtn">선택삭제</a>
	<a href="javascript:select_copy('copy');" class="hnBtn">복사</a>
	<a href="javascript:select_copy('move');" class="hnBtn">이동</a>
	<? } ?>
</div>
<div class="btnRight">
	<? if ($write_href) { ?><a href="<?=$write_href?>" class="hnBtn"><span class="iconPoint">글쓰기<span></a><? } ?>
</div>
</div><!-- /hnListBtn -->


<!-- 페이지 -->
<div id="hnListPage" style="width:<?=$bo_width?>">
	<? if ($prev_part_href) { echo "<a href='$prev_part_href'><img src='$board_skin_path/img/page_search_prev.gif' border='0' align=absmiddle title='이전검색'></a>"; } ?>
	<?
	// 기본으로 넘어오는 페이지를 아래와 같이 변환하여 이미지로도 출력할 수 있습니다.
	//echo $write_pages;
	$write_pages = str_replace("처음", "<img src='$board_skin_path/img/page_begin.gif' border='0' align='absmiddle' title='처음'>", $write_pages);
	$write_pages = str_replace("이전", "<img src='$board_skin_path/img/page_prev.gif' border='0' align='absmiddle' title='이전'>", $write_pages);
	$write_pages = str_replace("다음", "<img src='$board_skin_path/img/page_next.gif' border='0' align='absmiddle' title='다음'>", $write_pages);
	$write_pages = str_replace("맨끝", "<img src='$board_skin_path/img/page_end.gif' border='0' align='absmiddle' title='맨끝'>", $write_pages);
	//$write_pages = preg_replace("/<span>([0-9]*)<\/span>/", "$1", $write_pages);
	$write_pages = preg_replace("/<b>([0-9]*)<\/b>/", "<b><span style=\"color:#4D6185; font-size:12px; text-decoration:underline;\">$1</span></b>", $write_pages);
	?>
	<?=$write_pages?>
	<? if ($next_part_href) { echo "<a href='$next_part_href'><img src='$board_skin_path/img/page_search_next.gif' border='0' align=absmiddle title='다음검색'></a>"; } ?>
</div>

<!-- 검색 -->
<div id="hnListSearch" style="width:<?=$bo_width?>">
	<form name="fsearch" method="get">
	<input type="hidden" name="bo_table" value="<?=$bo_table?>">
	<input type="hidden" name="sca"  value="<?=$sca?>">
	<select name="sfl">
	<option value="wr_subject">제목</option>
	<option value="wr_content">내용</option>
	<option value="wr_subject||wr_content">제목+내용</option>
	<option value="mb_id,1">회원아이디</option>
	<option value="mb_id,0">회원아이디(코)</option>
	<option value="wr_name,1">글쓴이</option>
	<option value="wr_name,0">글쓴이(코)</option>
	</select>
	<input name="stx" class="stx" maxlength="15" itemname="검색어" required value='<?=$stx?>'>
	<input type="submit" value="search" class="hnBtn">
	<input type="radio" name="sop" value="and">and
	<input type="radio" name="sop" value="or">or
	</form>
</div>

<script language="JavaScript">
// 기본 카테고리 - $sca 값 있으면 분류에 표시
// if ('<?=$sca?>') document.fcategory.sca.value = '<?=$sca?>';

// 검색어가 있다면
if ('<?=$stx?>') {
    document.fsearch.sfl.value = '<?=$sfl?>';
    if ('<?=$sop?>' == 'and')
        document.fsearch.sop[0].checked = true;
    if ('<?=$sop?>' == 'or')
        document.fsearch.sop[1].checked = true;
} else {
    document.fsearch.sop[0].checked = true;
}
</script>

<?
// 관리자일때 체크박스 스크립트 실행
if ($is_checkbox) {
?>
<script language="JavaScript">
// 모두 선택
function all_checked(sw) {
    var f = document.fboardlist;
    for (var i=0; i<f.length; i++) {
        if (f.elements[i].name == "chk_wr_id[]")
            f.elements[i].checked = sw;
    }
}

// 하나 이상 체크되었나
function check_confirm(str) {
    var f = document.fboardlist;
    var chk_count = 0;

    for (var i=0; i<f.length; i++) {
        if (f.elements[i].name == "chk_wr_id[]" && f.elements[i].checked)
            chk_count++;
    }

    if (!chk_count) {
        alert(str + "할 게시물을 하나 이상 선택하세요.");
        return false;
    }
    return true;
}

// 선택한 게시물 삭제
function select_delete() {
    var f = document.fboardlist;

    str = "삭제";
    if (!check_confirm(str))
        return;

    if (!confirm("선택한 게시물을 정말 "+str+" 하시겠습니까?\n\n한번 "+str+"한 자료는 복구할 수 없습니다"))
        return;

    f.action = "./delete_all.php";
    f.submit();
}

// 선택한 게시물 복사 및 이동
function select_copy(sw) {
    var f = document.fboardlist;

    if (sw == "copy")
        str = "복사";
    else
        str = "이동";

    if (!check_confirm(str))
        return;

    var sub_win = window.open("", "move", "left=50, top=50, width=396, height=550, scrollbars=1");

    f.sw.value = sw;
    f.target = "move";
    f.action = "./move.php";
    f.submit();
}
</script>
<? } ?>
<!-- 게시판 목록 끝 -->
