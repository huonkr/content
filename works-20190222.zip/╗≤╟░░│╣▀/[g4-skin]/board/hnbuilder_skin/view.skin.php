<?
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

// 게시판 폭 지정
if($board[bo_table_width] < 100) {
	$bo_width = $board[bo_table_width]."%";
} else {
	$bo_width = $board[bo_table_width]."px";
}
?>
<!-- 스타일시트 -->
<link href="<?=$board_skin_path?>/hn_skin.css" rel="stylesheet" type="text/css">


<table id="hnView" cellpadding="0" cellspacing="0" style="width:<?=$bo_width?>;">
<tr><td class="viewSubject">
	<? if ($is_category) { echo ($category_name ? "<span class='viewCategory'>[$view[ca_name]]</span> " : ""); } ?>
	<?=$view[subject]?>
</td></tr>
<tr><td class="viewCredit">
	<div class="viewCreditLeft">
        <? if($is_admin) { ?>글쓴이 : <?=$view[name]?><? if ($is_ip_view) { echo "&nbsp;($ip)"; } ?>&nbsp;&nbsp;<? } ?>
        날짜 : <?=substr($view[wr_datetime],2,14)?>&nbsp;&nbsp;
		조회 : <?=number_format($view[wr_hit])?>
	</div>
	<div class="viewCreditRight">
		<? if ($update_href) { echo "	<a href=\"$update_href\" class=\"hnBtn strong\">수정하기</a> \n"; } ?>
		&nbsp;
		<? if ($scrap_href) { echo "<a href=\"javascript:;\" onclick=\"win_scrap('$scrap_href');\"   class=\"hnBtn smallBtn\">스크랩</a> "; } ?>
		<? if ($trackback_url) { ?><a href="javascript:trackback_send_server('<?=$trackback_url?>');" style="letter-spacing:0;" title='주소 복사'   class="hnBtn smallBtn">트랙백</a><?}?>
		&nbsp;        
		<?
		if ($prev_href || $next_href) { echo "&nbsp;"; }
		if ($prev_href) { echo "<a href=\"$prev_href\" title=\"$prev_wr_subject\"  class=\"hnBtn\"><span class=\"iconPrev\"></span></a>"; }
		if ($next_href) { echo "<a href=\"$next_href\" title=\"$next_wr_subject\"  class=\"hnBtn\"><span class=\"iconNext\"></span></a> "; }
		?>
	</div>
</td></tr>
<tr><td class="viewItem">
<span class="itemTitle"><i class="fa fa-home"></i> 스킨명</span><strong><?=$view[wr_1]?></strong>
</td></tr>
<tr><td class="viewItem">
<span class="itemTitle"><i class="fa fa-code"></i> 사용환경</span><?	
	if($view[wr_5]=="1") { echo "그누보드5"; }
	if($view[wr_5]=="1" && $view[wr_4]=="1") { echo ", "; }
	if($view[wr_4]=="1") { echo "그누보드4"; }		
?></td></tr>
<?
// 링크
if ($view[link][2]) {
	$link = cut_str($view[link][2], 70);
	echo "<tr><td class='viewItem'><span class=\"itemTitle\"><i class=\"fa fa-link\"></i> g5-demo</span>";
	echo "&nbsp;<a href='{$view[link_href][2]}' target=_blank>{$link}";
	echo "&nbsp;<span style=\"color:#ff6600; font-size:11px;\">[{$view[link_hit][2]}]</span></a></td></tr>";
}
if ($view[link][1]) {
	$link = cut_str($view[link][1], 70);
	echo "<tr><td class='viewItem'><span class=\"itemTitle\"><i class=\"fa fa-link\"></i> g4-demo</span>";
	echo "&nbsp;<a href='{$view[link_href][1]}' target=_blank>{$link}";
	echo "&nbsp;<span style=\"color:#ff6600; font-size:11px;\">[{$view[link_hit][1]}]</span></a></td></tr>";
}

// 첨부파일
$cnt = 0;
for ($i=0; $i<count($view[file]); $i++) {
    if ($view[file][$i][source] && !$view[file][$i][view])
    {
        $cnt++;
        //echo "<tr><td height=22>&nbsp;&nbsp;<img src='{$board_skin_path}/img/icon_file.gif' align=absmiddle> <a href='{$view[file][$i][href]}' title='{$view[file][$i][content]}'><strong>{$view[file][$i][source]}</strong> ({$view[file][$i][size]}), Down : {$view[file][$i][download]}, {$view[file][$i][datetime]}</a></td></tr>";
        echo "<tr><td class='viewItem'><span class=\"itemTitle\"><i class=\"fa fa-file-code-o\"></i> 다운로드</span> ";
        echo "<a href=\"javascript:file_download('{$view[file][$i][href]}', '{$view[file][$i][source]}');\" title='{$view[file][$i][content]}'>";
        echo "<strong>{$view[file][$i][source]}</strong> ({$view[file][$i][size]})";
        echo "&nbsp;<span style=\"color:#ff6600; font-size:11px;\">[{$view[file][$i][download]}]</span>";
        echo " <span style=\"color:#aaa; font-size:11px;\">Date : {$view[file][$i][datetime]}</span></a></td></tr>";
    }
}
?>


<? /* if($view[wr_2] || $view[wr_3]) { ?>
<tr><td class="viewItem viewPrice">
휴온빌더 멤버 : <span class="price">0원</span>,&nbsp; 
<? if($view[wr_2]) { ?>비즈용: <span class="price"><?=number_format($view[wr_2])?>원</span>,&nbsp; <? } ?>
<? if($view[wr_3]) { ?>무제한: <span class="price"><?=number_format($view[wr_3])?>원</span><? } ?> 
 <a href="#" title="'멤버용'은 허가된 범위내에서 무료로 사용할 수 있습니다. <? if($view[wr_2]) { ?>'비즈용'은 단일 웹사이트에 사용할 수 있으며,<? } ?>  <? if($view[wr_3]) { ?>'무제한용'은 사용 기간이나 횟수에 제한없이 사용할 수 있습니다.<? } ?>" class="helpBtn">[?]</a>
 <form method="post" action="<?=$g4['bbs_path']?>/write.php" style="display:inline;">
 <input type="hidden" name="bo_table" value="hnskin_order">
 <input type="hidden" name="subject" value="<?=$view[wr_1]?> 스킨 사용 문의">
 <? if($view[wr_2]) { ?>
 <input type="hidden" name="biz" value="biz">
 <input type="hidden" name="biz_price" value="<?=$view[wr_2]?>">
 <? } ?>
  <? if($view[wr_3]) { ?>
 <input type="hidden" name="exp" value="exp">
 <input type="hidden" name="exp_price" value="<?=$view[wr_3]?>">
 <? } ?>
 <button type="submit">문의</button>
 </form>
</td></tr>
<? } */?>

<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<style type="text/css">
.ui-tooltip {
    position: absolute;
    z-index: 9999;
    max-width: 500px; padding:15px 20px;
    background-color:#fff;
	font-size:13px; color:#0489B1;
	font-family:"맑은 고딕", "Malgun Gothic", "나눔고딕", "NanumGothic", "돋움", "Dotum", "굴림", "Gulim",  "Tahoma", "sans-serif";
}
</style>
<script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
<script>
$(function() {
    $( document ).tooltip({tooltipClass:"ui-tooltip"});
});
</script>
  
<tr><td class="viewContent">	
<?
// 이미지 출력
$cnt_img=0;
for ($i=0; $i<=count($view[file]); $i++) {
	if ($view[file][$i][view]) {
		echo "	<div class='viewIMG'>".$view[file][$i][view] . "</div>";
		$cnt_img++;
	}
}
// 이미지 출력된것이 있다면 줄바꿈 추가
if ($cnt_img>0)
	echo "	<br>";

// html 글일때 공백표시
if (strstr($view[wr_option], "html2") || strstr($view[wr_option], "html2")) {
	$view[content] = str_replace("  ", "&nbsp;&nbsp;", $view[content]);//두개의 공백이 있을 경우 특수문자로 교체하여 올바로 공백 출력
}
?>
<?
// 링크
echo "	<div class='linkBtn'>";
// 데모
if ($view[link][1] || $view[link][2]) {
	if ($view[link][2])
		echo "&nbsp;<a href='{$view[link_href][2]}' target='_blank' class='hnBtn'>DEMO-g5</a>&nbsp;";
	if ($view[link][1])
		echo "&nbsp;<a href='{$view[link_href][1]}' target='_blank' class='hnBtn'>DEMO-g4</a>&nbsp;";	
}
// 다운로드
for ($i=0; $i<count($view[file]); $i++) {
    if ($view[file][$i][source] && !$view[file][$i][view]) {
        echo "<a href=\"javascript:file_download('{$view[file][$i][href]}', '{$view[file][$i][source]}');\" title='{$view[file][$i][content]}' class='hnBtn strong'>{$view[file][$i][source]}</a>&nbsp;";        
    }
}
echo "</div>\n";
?>

<? if($view[wr_2]) { ?>
<div class="viewSummary">
<?
// 요약글 출력
// html 글일때 공백표시
if (strstr($view[wr_option], "html2") || strstr($view[wr_option], "html2")) {
	$view[wr_2] = str_replace("  ", "&nbsp;&nbsp;", $view[wr_2]);//두개의 공백이 있을 경우 특수문자로 교체하여 올바로 공백 출력
}
$view[wr_2] = nl2br($view[wr_2]);
echo $view[wr_2]; 
?>
</div>
<? } ?>

	<?=$view[content];?>
<?//echo $view[rich_content]; // {이미지:0} 과 같은 코드를 사용할 경우?>
<!-- 테러 태그 방지용 --></xml></xmp><a href=""></a><a href=''></a>

<?
//SNS공유
include_once($g4['path']."/inc/sns_share.php");
?>

<? if ($is_good || $is_nogood) { ?>
<div class="goodSign" style="width:<?=$bo_width?>;">	
	<? if ($is_good) { ?>&nbsp;<img src="<?=$board_skin_path?>/img/icon_good.gif" border='0' align=absmiddle> 추천 : <?=number_format($view[wr_good])?><? } ?>
	<? if ($is_nogood) { ?>&nbsp;<img src="<?=$board_skin_path?>/img/icon_nogood.gif" border='0' align=absmiddle> 비추천 : <?=number_format($view[wr_nogood])?><? } ?>
</div>
<? } ?>

</td></tr>
</table>


<?
//코멘트
include_once($g4['bbs_path']."/view_comment.php");
?>


<!-- 링크 버튼 -->
<div  id="viewBtn" style="width:<?=$bo_width?>;">
<p class="leftBtn">
<?
	if ($search_href) { echo "	<a href=\"$search_href\" class=\"hnBtn\">검색</a> \n"; }
	echo "	<a href=\"$list_href\" class=\"hnBtn\"><span class=\"iconList\">목록</span></a> ";	
	if ($reply_href) { echo "	<a href=\"$reply_href\" class=\"hnBtn\">답변</a> \n"; }
	if ($update_href) { echo "	<a href=\"$update_href\" class=\"hnBtn\">수정</a> \n"; }
	if ($delete_href) { echo "	<a href=\"$delete_href\" class=\"hnBtn\">삭제</a> \n"; }
	if ($good_href) { echo "	<a href=\"$good_href\" target=\"hiddenframe\" class=\"hnBtn\">추천</a> \n"; }
	if ($nogood_href) { echo "	<a href=\"$nogood_href\" target=\"hiddenframe\" class=\"hnBtn\">비추천</a> \n"; }
	if ($scrap_href) { echo "	<a href=\"javascript:;\" onclick=\"win_scrap('$scrap_href');\" class=\"hnBtn\">스크랩</a> \n"; }
	if ($copy_href) { echo "	<a href=\"$copy_href\" class=\"hnBtn\">복사</a> \n"; }
	if ($move_href) { echo "	<a href=\"$move_href\" class=\"hnBtn\">이동</a> \n"; }	
?>
</p>
<p class="rightBtn">
<?	
	if ($write_href) { echo "&nbsp;	<a href=\"$write_href\" class=\"hnBtn\"><span class=\"iconPoint\">글쓰기</span></a> \n"; }	
?>
</p>
</div>


<script type="text/javascript">
function file_download(link, file) {
    <? if ($board[bo_download_point] < 0) { ?>if (confirm("'"+file+"' 파일을 다운로드 하시면 포인트가 차감(<?=number_format($board[bo_download_point])?>점)됩니다.\n\n포인트는 게시물당 한번만 차감되며 다음에 다시 다운로드 하셔도 중복하여 차감하지 않습니다.\n\n그래도 다운로드 하시겠습니까?"))<?}?>
    document.location.href=link;
}
</script>

<script type="text/javascript" src="<?="$g4[path]/js/board.js"?>"></script>
<script type="text/javascript">
window.onload=function() {
    resizeBoardImage(<?=(int)$board[bo_image_width]?>);
    drawFont();
}
</script>
<!-- 게시글 보기 끝 -->

<?
// 전체목록 보이기일 경우 구분자 출력
if($board['bo_use_list_view']) {
?>
<hr style="width:<?=$bo_width?>; margin:30px auto; color:#eee; border:none; border-top:1px solid #eee; ">
<? } ?>
