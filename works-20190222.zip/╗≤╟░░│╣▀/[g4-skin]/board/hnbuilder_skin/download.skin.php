<?
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

// $is_hnmember는 common.php에서 처리
if(!$is_hnmember) {	
	//hnbuilder_join 게시판의 신청과 승인 확인하여 다운로드 승인
	$is_join_confirm = false;
	$join_str = "";

	//wr_1 라이센스종류, wr_2 카피수, wr_3 가격, wr_4 입금자명, wr_9 확인여부, wr_10 승인날짜
	$join_table = $g4['write_prefix']."hnbuilder_join"; 

	$join_count = 0;
	$result = sql_query(" select mb_id, wr_1, wr_2, wr_3, wr_9, wr_10 from ".$join_table." where mb_id = '".$member['mb_id']."' ");
	while ($row = sql_fetch_array($result) ) {
		$join_count++;
		$join_str.= $row['mb_id'].", ".$row['wr_1'].", ".$row['wr_2'].", ".$row['wr_3'].", ".$row['wr_9'].", ".$row['wr_10']."\\n";
		
		//승인여부 
		if($row['wr_9']=="confirm" && $row['wr_10'] && $row['wr_10'] > "2014-07-01") {
			$is_join_confirm = true;
		}
	}

	if(!$is_admin && !$is_join_confirm && $join_str) {
		alert("회원님의 신청이 확인되으며 현재 사용 승인 전입니다. \\n결제 확인 후 사용이 가능합니다. \\n감사합니다.", $g4['bbs_path']."/board.php?bo_table=hnbuilder_join");
	} else if(!$is_join_confirm && !$join_str) {
		alert("휴온빌더 신청 후 이용해주세요.");
	}
}
// alert($join_count." \\n ".$join_str);
?>
