<?
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

if ($member[mb_level] < $board[bo_download_level]) {     
    if ($member[mb_id])
        alert("( ! ) 다운로드 권한이 없으시네요. \\n\\n휴온빌더 사용자 신청 후 이용할 수 있습니다~.");
    else
        alert("( ! ) 다운로드 권한이 없으시네요. \\n\\n휴온빌더 사용자이시면 로그인 후 이용해 주세요.", "./login.php?wr_id=$wr_id&$qstr&url=".urlencode("$g4[bbs_path]/board.php?bo_table=$bo_table&wr_id=$wr_id"));
}

//alert($join_count." \\n ".$join_str);
?>
