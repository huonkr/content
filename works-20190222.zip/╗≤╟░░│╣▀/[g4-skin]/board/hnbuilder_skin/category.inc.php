<link type="text/css" href="<?=$board_skin_path; ?>/category.css"  rel="stylesheet"/>
<form name="fcategory" method="get" style="margin:0px;">

<div id="tabs_container" style="width:<?=$bo_width?>;">
<ul id="tabs">
<? 
//전체
$total=sql_fetch("select sum(bo_count_write) as cnt from $g4[board_table] where bo_table IN('$bo_table')");
$ca_total = $total[cnt];

// $ca_sca 그대로 사용시 특정 한글에서 깨짐현상 
$ca_sca = $_GET['sca'];
if($ca_sca){
?>
<li><a href='./board.php?bo_table=<?=$bo_table?>&page=<?=$page?>'>전체<span class="cnt">(<?= $ca_total;?>)</span></a></li>
<? }else{ ?>
<li class="active"><a href="./board.php?bo_table=<?=$bo_table?>&page=<?=$page?>"><strong>전체</strong>
<span class="cnt">(<?= $ca_total;?>)</span></a></li>
<?}?>

<?  
$ca_arr = explode("|", $board[bo_category_list]);
for($i=0; $i<count($ca_arr); $i++) {
	$ca_name = $ca_arr[$i];	
	$ca_sql = " SELECT count(*) as cnt FROM $write_table WHERE ca_name = '{$ca_arr[$i]}' and wr_is_comment = 0 ";
	$ca_row = sql_fetch($ca_sql);	
	$ca_cnt = $ca_row[cnt];
	
	// new 아이콘 표시
	$new_icon = "";	
	$bo_row = sql_fetch("select bo_new from $g4[board_table] where bo_table='$bo_table'");   
	$new_time = date("Y-m-d H:i:s", time()-$bo_row[bo_new]*3600);  
	$table_row = sql_fetch("select wr_datetime from `$g4[write_prefix]$bo_table` where !wr_is_comment and ca_name='$ca_name' and wr_datetime > '$new_time'");
	if($table_row && is_file("$board_skin_path/img/icon_new.gif")) {
		$new_icon = " <img src=\"$board_skin_path/img/icon_new.gif\" border=\"0\" alt=\"new\" />";		
	}
	
	if ($ca_sca == $ca_name) {
		echo "<li class=\"active\"><a href=\"./board.php?bo_table=$bo_table&sca=".urlencode($ca_name)."\">$ca_name<span class=\"cnt\">($ca_cnt)</span>$new_icon</a></li>";
	} else {
		echo "<li><a href=\"./board.php?bo_table=$bo_table&sca=".urlencode($ca_name)."\">$ca_name<span class=\"cnt\">($ca_cnt)</span>$new_icon</a></li>";
	}
}
?>
</ul>
</div>

</form>

<script>
$(document).ready(function(){    
$("#tabs li").click(function() {        
	$("#tabs li").removeClass('active');
	$(this).addClass("active");
	$(".tab_content").hide();
	var selected_tab = $(this).find("a").attr("href");
	$(selected_tab).fadeIn();
	return false;
});
});
</script>
