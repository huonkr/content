<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (defined('G5_THEME_PATH')) {
    require_once(G5_THEME_PATH.'/head.php');
    return;
} 

if (G5_IS_MOBILE) {
    include_once(G5_MOBILE_PATH.'/head.php');
    return;
}

include_once(G5_PATH.'/head.sub.php');
include_once(G5_LIB_PATH.'/latest.lib.php');
include_once(G5_LIB_PATH.'/outlogin.lib.php');
include_once(G5_LIB_PATH.'/poll.lib.php');
include_once(G5_LIB_PATH.'/visit.lib.php');
include_once(G5_LIB_PATH.'/connect.lib.php');
include_once(G5_LIB_PATH.'/popular.lib.php');
?>
<!-- header -->
<div id="headerWrap"><div id="header">
<?php
	// 팝업레이어
	if (defined('_INDEX_')) { // index에서만 실행
		include G5_BBS_PATH.'/newwin.inc.php'; 
	}	
	
	// 부가메뉴
	// 북마크 설정
	$bookmark_url = (@$_SERVER["HTTPS"] == "on") ? "https://" : "http://";
	$bookmark_url .= $_SERVER["SERVER_NAME"]; 
	if($_SERVER["SERVER_PORT"] != "80" && $_SERVER["SERVER_PORT"] != "443") {
		 $bookmark_url .= ":".$_SERVER["SERVER_PORT"];
	} 
	$bookmark_url .= $_SERVER["REQUEST_URI"];
	$bookmark_title = $g5['title'];
?>
	<!-- 반응형 부가메뉴 -->
	<div id="utilmenu">	
	<!-- large -->
	<ul class="lg">
		<li><a href="<?php echo G5_URL ?>/index.php"><i class="fa fa-home"></i>홈</a></li>
		<?php if ($is_member) {  ?>
		<?php if ($is_admin) {  ?>
		<li><a href="<?php echo G5_ADMIN_URL ?>"><strong><i class="fa fa-cog" aria-hidden="true"></i>관리자</strong></a></li>
		<?php }  ?>		
		<li><a href="<?php echo G5_BBS_URL ?>/logout.php"><i class="fa fa-sign-out"></i>로그아웃</a></li>		
		<li class="lg"><a href="<?php echo G5_BBS_URL ?>/member_confirm.php?url=<?php echo G5_BBS_URL ?>/register_form.php">정보수정</a></li>
		<?php } else {  ?>		
		<li><a href="<?php echo G5_BBS_URL ?>/login.php"><i class="fa fa-key" aria-hidden="true"></i>로그인</a></li>
		<li><a href="<?php echo G5_BBS_URL ?>/register.php">회원가입</a></li>
		<?php }  ?>		
		<li><a href="<?php echo G5_BBS_URL ?>/faq.php"><i class="fa fa-list-ul" aria-hidden="true"></i>FAQ</a></li>
		<li><a href="<?php echo G5_BBS_URL ?>/qalist.php"><i class="fa fa-question" aria-hidden="true"></i>1:1문의</a></li>
		<li><a href="<?php echo G5_BBS_URL ?>/current_connect.php">접속자 <?php echo connect(); // 현재 접속자수  ?></a></li>
		<li><a href="<?php echo G5_BBS_URL ?>/new.php">새글</a></li>			
		<li><a href="<?=$bookmark_url?>" id="bookmark" title="즐겨찾기" rel="sidebar"><i class="fa fa-bookmark fa-only"></i><span class="sr-only">즐겨찾기</span></a></li>
		<li><a href="<?php echo G5_URL ?>/page/sitemap.php"><i class="fa fa-sitemap  fa-only" aria-hidden="true"></i><span class="sr-only">사이트맵</span></a></li>		
		<li><a href="#searchForm" title="검색" class="toggle-search"><i class="fa fa-search fa-only"></i><span class="sr-only">검색버튼</span></a></li>
	</ul>
	
	<!-- middle -->
	<ul class="md">
		<li><a href="<?php echo G5_URL ?>/index.php"><i class="fa fa-home"></i>홈</a></li>
		<?php if ($is_member) {  ?>
		<?php if ($is_admin) {  ?>
		<li><a href="<?php echo G5_ADMIN_URL ?>"><strong><i class="fa fa-cog" aria-hidden="true"></i>관리자</strong></a></li>
		<?php }  ?>		
		<li><a href="<?php echo G5_BBS_URL ?>/logout.php"><i class="fa fa-sign-out"></i>로그아웃</a></li>		
		<li class="lg"><a href="<?php echo G5_BBS_URL ?>/member_confirm.php?url=<?php echo G5_BBS_URL ?>/register_form.php">정보수정</a></li>
		<?php } else {  ?>		
		<li><a href="<?php echo G5_BBS_URL ?>/login.php"><i class="fa fa-key" aria-hidden="true"></i>로그인</a></li>
		<li class="lg"><a href="<?php echo G5_BBS_URL ?>/register.php">회원가입</a></li>
		<?php }  ?>		
		<li class="md-over"><a href="<?php echo G5_BBS_URL ?>/faq.php"><i class="fa fa-list-ul" aria-hidden="true"></i>FAQ</a></li>
		<li class="md-over"><a href="<?php echo G5_BBS_URL ?>/qalist.php"><i class="fa fa-question" aria-hidden="true"></i>1:1문의</a></li>
		<li class="lg"><a href="<?=$bookmark_url?>" id="bookmark" title="즐겨찾기" rel="sidebar"><i class="fa fa-bookmark fa-only"></i><span class="sr-only">즐겨찾기</span></a></li>
		<li><a href="#searchForm" title="검색" class="toggle-search"><i class="fa fa-search fa-only"></i><span class="sr-only">검색버튼</span></a></li>
	</ul>
	
	<!-- small -->
	<ul class="sm">
		<li><a href="<?php echo G5_URL ?>/index.php"><i class="fa fa-home fa-only"></i><span class="sr-only">홈</span></a></li>
		<?php if ($is_member) {  ?>
		<?php if ($is_admin) {  ?>
		<li><a href="<?php echo G5_ADMIN_URL ?>"><strong><i class="fa fa-cog fa-only" aria-hidden="true"></i><span class="sr-only">관리자</span></strong></a></li>
		<?php }  ?>		
		<li><a href="<?php echo G5_BBS_URL ?>/logout.php"><i class="fa fa-sign-out fa-only"></i><span class="sr-only">로그아웃</span></a></li>		
		<?php } else {  ?>		
		<li><a href="<?php echo G5_BBS_URL ?>/login.php"><i class="fa fa-key fa-only" aria-hidden="true"></i><span class="sr-only">로그인</span></a></li>
		<?php }  ?>			
		<li><a href="#searchForm" title="검색" class="toggle-search"><i class="fa fa-search fa-only"></i><span class="sr-only">검색버튼</span></a></li>
	</ul>
	</div>
	
	<!-- 로고 -->	    
	<h1 id="logo">
	<a href="<?php echo G5_URL ?>/index.php"><?php echo $config['cf_title']; ?></a>
	<!-- <a href="<?php echo G5_URL ?>/index.php"><img src="<?php echo G5_URL;?>/images/logo.jpg" alt="" title="<?php echo $config['cf_title']; ?>"></a> -->
	</h1>	
		
<?php
	// 메뉴 라이브러리
	include_once(G5_LIB_PATH.'/menu.lib.php');
?>	
	<!-- small size 메뉴 토글버튼 -->
	<div class="nav-toggle-icon"><i class="fa fa-bars" aria-hidden="true"></i></div>
		
	<!-- 글로벌네비게이션 -->
	<nav id="globalnav">
	<?php echo get_globalnav(); ?>
	</nav>	
	
<div class="hnClear"></div>
</div></div><!-- /header -->



<!-- 검색 -->	
<div id="search">
	<form name="fsearchbox" method="get" action="<?php echo G5_BBS_URL ?>/search.php" onsubmit="return fsearchbox_submit(this);" class="pure-form" >
	<input type="hidden" name="sfl" value="wr_subject||wr_content">
	<input type="hidden" name="sop" value="and">
	<label for="sch_stx" class="sound_only">검색어<strong class="sound_only"> 필수</strong></label>
	<input type="text" name="stx" id="sch_stx" maxlength="20" class="pure-input-rounded">		
	<button type="submit"><i class="fa fa-search fa-lg" aria-hidden="true"></i></button>
	</form>
</div>
<script>
$(function() {
	var is_search = false;
	var $search = $('#search');
	$('.toggle-search').click(function() {
		 if (!is_search) {
			$search.slideDown("fast");
			is_search = true; 
		 } else {
			$search.slideUp("fast");
			is_search = false; 
		 }
		 return false;
	});
});

function fsearchbox_submit(f)
{
	if (f.stx.value.length < 2) {
		alert("검색어는 두글자 이상 입력하십시오.");
		f.stx.select();
		f.stx.focus();
		return false;
	}

	// 검색에 많은 부하가 걸리는 경우 이 주석을 제거하세요.
	var cnt = 0;
	for (var i=0; i<f.stx.value.length; i++) {
		if (f.stx.value.charAt(i) == ' ')
			cnt++;
	}

	if (cnt > 1) {
		alert("빠른 검색을 위하여 검색어에 공백은 한개만 입력할 수 있습니다.");
		f.stx.select();
		f.stx.focus();
		return false;
	}

	return true;
}
</script>
<!-- /검색 -->



<!-- slider -->
<?php
include_once(G5_LIB_PATH.'/slider.lib.php');

// 메인이미지
if (defined('_INDEX_')) {	
	// 슬라이더 옵션
	$slider_options = array(
		'height' 		=> 550, // 슬라이더 높이
		'num' 			=> 5, // 이미지수
		'pause_time' 	=> 3, // 슬라이드 멈춤 시간(초)	
		'is_title' 		=> true, // 타이틀 출력 여부
		'is_content' 	=> true, // 내용 출력 여부
		'text_top' 		=> "20%", // 텍스트 상단포지션 : 0%, 0px
		'text_align' 	=> "center", // 텍스트정렬 : left, center, right		
		'title_color' 	=> "white", // 제목 색상
		'content_color' => "white", // 내용 텍스트 색상
		// 'content_bgcolor' => "rgba(0,0,0,0.2)" // 내용 배경 색상 : HTML색상표, 색상명, rgba()
		'content_bgcolor' => "black"
	);
	// 매개변수 : 스킨명, 게시판명, wr_id, 옵션
	echo slider("hn_slider", "media", 1, $slider_options); 
	
// 서브이미지
} else if ($global_index) { 	
	$slider_options = array(
		'height' 		=> 270,
		'num' 			=> 5, 
		'pause_time' 	=> 3,	
		'is_title' 		=> true,
		'is_content' 	=> true,
		'text_top' 		=> "25%",
		'text_align' 	=> "left",
		'title_color' 	=> "#fffff0",
		'content_color' => "white",
		'content_bgcolor' => "orange"		
	);
	echo slider("hn_slider", "media", 3, $slider_options); 
}
?>


<!-- main -->
<div id="mainWrap"><div id="main">
<?php
// 사이드바는 서브페이지에서만 보임
if(!defined('_INDEX_')) {
?>
	<!-- sidebar -->
	<div id="sidebar">
	<?php
	// 사이드바 구성
	include_once(G5_PATH."/inc/sidebar.php");
	?>  
	</div><!-- /sidebar -->
<?php } ?>
	
    <!-- content -->
	<div id="content">
<?php	
// 페이지 제목 출력
// 문서에 $page_title_hide=true; 설정되면 페이지 제목을 출력하지 않음
if ($page_title && !$page_title_hide) {
?>
		<h2 id="pageTitle"><?php echo $page_title ?></h2>
<?php } ?>