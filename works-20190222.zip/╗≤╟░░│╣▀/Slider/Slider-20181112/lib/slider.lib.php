<?php
if (!defined('_GNUBOARD_')) exit;

// 게시물 파일에서 비주얼 이미지 추출
function slider($skin_dir="hn_slider", $bo_table, $wr_id=1, $options=array())
{
    global $g5;
	$cache_time=1;

	if(preg_match('#^theme/(.+)$#', $skin_dir, $match)) {
        if (G5_IS_MOBILE) {
            $latest_skin_path = G5_THEME_MOBILE_PATH.'/'.G5_SKIN_DIR.'/latest/'.$match[1];
            if(!is_dir($latest_skin_path))
                $latest_skin_path = G5_THEME_PATH.'/'.G5_SKIN_DIR.'/latest/'.$match[1];
            $latest_skin_url = str_replace(G5_PATH, G5_URL, $latest_skin_path);
        } else {
            $latest_skin_path = G5_THEME_PATH.'/'.G5_SKIN_DIR.'/latest/'.$match[1];
            $latest_skin_url = str_replace(G5_PATH, G5_URL, $latest_skin_path);
        }
        $skin_dir = $match[1];
    } else {
        if(G5_IS_MOBILE) {
			$latest_skin_path = G5_MOBILE_PATH.'/'.G5_SKIN_DIR.'/latest/'.$skin_dir;
			$latest_skin_url  = G5_MOBILE_URL.'/'.G5_SKIN_DIR.'/latest/'.$skin_dir;
		} else {
			$latest_skin_path = G5_SKIN_PATH.'/latest/'.$skin_dir;
			$latest_skin_url  = G5_SKIN_URL.'/latest/'.$skin_dir;
		}
    }
	
	$list = array();

	$sql = " select * from {$g5['board_table']} where bo_table = '{$bo_table}' ";
	$board = sql_fetch($sql);
	$bo_subject = get_text($board['bo_subject']);
	
	if($board['bo_table'] != $bo_table) {
		return "<div style='margin:10px 0; padding:30px 5px; text-align:center; font-size:12px; '>&lt;!&gt; <strong>$bo_table</strong> 게시판이 존재하지 않습니다.</div>";	
	}				

	$tmp_write_table = $g5['write_prefix'] . $bo_table; // 게시판 테이블 전체이름		
	
	$sql = " select * from {$tmp_write_table} where wr_id='$wr_id' ";
	$row = sql_fetch($sql);			
	$list = get_list($row, $board, $latest_skin_path);

    ob_start();
    include $latest_skin_path.'/latest.skin.php';
    $content = ob_get_contents();
    ob_end_clean();

    return $content;
}
?>
