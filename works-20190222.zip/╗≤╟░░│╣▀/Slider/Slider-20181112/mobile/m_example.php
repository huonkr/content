<?php
include_once('./_common.php');
include_once(G5_PATH.'/_head.php');
?>




<!-- slider -->
<?php
// 이미지 슬라이더
include_once(G5_LIB_PATH.'/slider.lib.php');

// 슬라이더 옵션
$slider_options = array(
	'height' 		=> 350, // 슬라이더 높이
	'num' 			=> 5, // 이미지수
	'pause_time' 	=> 3, // 슬라이드 멈춤 시간(초)	
	'view_title' 	=> true, // 타이틀 출력 여부
	'view_content' 	=> true, // 내용 출력 여부
	'top' 			=> "20%", // 텍스트 상단포지션 : 0%, 0px
	'align' 		=> "center", // 텍스트정렬 : left, center, right		
	'title_color' 	=> "", // 제목 색상(기본 white)
	'content_bgcolor' => "rgba(0,0,0,0.2)", // 내용 배경 색상 : HTML색상표, 색상명, 투명도
	'content_color' => "" // 내용 텍스트 색상(기본 white)
);
// 매개변수 : 스킨명, 게시판명, wr_id, 옵션
echo slider("hn_slider", "media", 1, $slider_options); 
?>



	
<?php
include_once(G5_PATH.'/_tail.php');
?>
