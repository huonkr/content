<?php
include_once('./_common.php');
include_once(G5_PATH.'/_head.php');
?>
<style>
#sidebar { display:none; }
</style>


<!-- slider -->
<?php
include_once(G5_LIB_PATH.'/slider.lib.php');

// 메인이미지
if (defined('_INDEX_')) {	
	
// 서브이미지
} else if ($global_index) { 	
	$slider_options = array(
		'height' 		=> 270,
		'num' 			=> 5, 
		'pause_time' 	=> 3,	
		'view_title' 	=> true,
		'view_content' 	=> true,
		'top' 			=> "10%",
		'align' 		=> "left",
		'content_bgcolor' => "orange",
		'content_color' => "white"
	);
	echo slider("hn_slider", "media", 3, $slider_options); 
}


	// 슬라이더 옵션
	$slider_options = array(
		'height' 		=> 550, // 슬라이더 높이
		'num' 			=> 5, // 이미지수
		'pause_time' 	=> 3, // 슬라이드 멈춤 시간(초)	
		'view_title' 	=> true, // 타이틀 출력 여부
		'view_content' 	=> true, // 내용 출력 여부
		'top' 			=> "20%", // 텍스트 상단포지션 : 0%, 0px
		'align' 		=> "center", // 텍스트정렬 : left, center, right		
		'title_color' 	=> "white", // 제목 색상
		'content_bgcolor' => "rgba(0,0,0,0.2)", // 내용 배경 색상 : HTML색상표, 색상명, 투명도
		'content_color' => "white" // 내용 텍스트 색상
	);
	// 매개변수 : 스킨명, 게시판명, wr_id, 옵션
	echo slider("hn_slider", "media", 1, $slider_options); 
?>





	
<?php
include_once(G5_PATH.'/_tail.php');
?>
