<?php
include_once('./_common.php');
include_once(G5_PATH.'/head.sub.php');
?>
<style>
html, body { background-color:#393939; }

.hn h1 { 
	width: 500px; margin: 3em auto;
	background-color: white; border: 3px dashed #6bb2b6;
	line-height:3em; text-align:center; color:#0F7693;

	/*shadow*/
	-webkit-box-shadow: 3px 6px 12px rgba(0,0,0,0.2);
	-moz-box-shadow: 3px 6px 12px rgba(0,0,0,0.2);
	box-shadow: 3px 6px 12px rgba(0,0,0,0.2);

	/*rounded corners*/
	-webkit-border-radius: 20px;
	-moz-border-radius: 20px;
	border-radius: 20px;
}
#sidebar { display:none; }
</style>


<!-- hn_nivo_content -->
<?php
include_once(G5_LIB_PATH.'/slider.lib.php');

// hn_nivo slider
$slider_options = array(
	'height' 			=> "700px|70vw", // 슬라이더 기본 높이, 반응형 높이(% 또는 vw)		
	'pause_time' 		=> 3, // 슬라이드 멈춤 시간(초)		
	'is_content' 		=> true, // 내용 출력 여부
	'is_content_html' 	=> true, // 텍스트 내용이면 false, html 내용이면 true
	'content_top' 		=> "25%", // 내용 상단 위치(%, vh, px)
	'content_align' 	=> "center", // 정렬(left, center, right)
	'content_hide_time' => 0, // 내용 숨기는 슬라이드 전환 횟수, 0이면 계속 보임		
	'content_style' 	=> "text-align:center; color:#fff; background-color:transparent; outline-color:transparent; ", // 내용 스타일
	'is_headline' 		=> true, // 제목 출력 여부
	'headline_style' 	=> "padding:0; font-size:4rem; color:#fff; background-color:transparent; " // 제목 스타일
	
);
// 매개변수 : 스킨명, 게시판명, wr_id, 옵션
echo slider("hn_nivo_content", "media", 1, 3, $slider_options);
?>

	
<?php
include_once(G5_PATH.'/tail.sub.php');
?>
