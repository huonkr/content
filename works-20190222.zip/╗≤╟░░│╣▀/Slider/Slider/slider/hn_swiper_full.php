<?php
include_once('./_common.php');
include_once(G5_PATH.'/head.sub.php');
?>


<!-- hn_swiper_full --> 
<?php
include_once(G5_LIB_PATH.'/slider.lib.php');

// hn_swiper_full
// 매개변수 : 스킨명, 게시판명, wr_id, 이미지 개수
echo slider("hn_swiper_full", "media", 1, 0); 
?>
	
	
<?php
include_once(G5_PATH.'/tail.sub.php');
?>
