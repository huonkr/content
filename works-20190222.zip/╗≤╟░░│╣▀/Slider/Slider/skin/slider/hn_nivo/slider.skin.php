<?php
/*  
 * hn_nivo_basic : $wr_id에 해당되는 게시물의 이미지 슬라이더 
 *
 * jQuery Plugin : Nivo Slider v3.2
 * 
 * [ 사용법 ] 
 * ---------------------------------------------------------------------
 * include_once(G5_LIB_PATH.'/slider.lib.php'); 
 * // 매개변수 : 스킨명, 게시판명, wr_id, 이미지 개수
 * echo slider("hn_nivo_basic", $bo_table, $wr_id, 3);
 * ---------------------------------------------------------------------	
 */ 
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

$slider_class = "nivo-".rand();

$img_idx = 0;
$img_count = $list[file]['count'];
$pause_time = 5*1000; // 이미지 보여지는 시간(초)
$img_tag = "";
$caption_str = "";

//출력할 이미지 개수 체크
if ($number && $img_count > $number) {
	$img_count = $number;
}

for ($i=0; $i<$img_count; $i++) {	
	$img_file = $list[file][$i][path]."/".$list[file][$i][file]; // 원본 이미지
	
	// 업로드된 파일 이미지가 존재하면
	if (preg_match("/\.(jp[e]?g|gif|png)$/i", $img_file)) {
		$img_idx++;		
		
		// 이미지캡션
		if($list[file][$i][bf_content] && strlen($list[file][$i][bf_content]) > 2) {
			$list_href = $list[file][$i][bf_content];
			//링크 체크7
			if (preg_match('#^https?://#i', $list_href)) {				
				$img_tag .= "	<a href=\"$list_href\"><img src=\"$img_file\" alt=\"\" border=\"0\" /></a> \n";
			} else {
				$list_content = $list[file][$i][bf_content];
				$caption_str .= "<div id=\"imgcaption".$i."\" class=\"nivo-html-caption\">$list_content</div> \n";	
				$img_tag .= "	<img src=\"$img_file\" alt=\"\" border=\"0\" title=\"#imgcaption".$i."\" /> \n";
			}			
		} else {
			$img_tag .= "	<img src=\"$img_file\" alt=\"\" border=\"0\" /> \n";
		}
	}
}
?>
<link href="<?php echo $slider_skin_url?>/hn_nivo_basic.css" rel="stylesheet" type="text/css">

<div id="nivoSlider">
<?php
if($img_tag) {
?>
	<link href="<?php echo G5_URL?>/plugin/nivo/themes/default/default.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="<?php echo G5_URL?>/plugin/nivo/themes/light/light.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="<?php echo G5_URL?>/plugin/nivo/themes/dark/dark.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="<?php echo G5_URL?>/plugin/nivo/themes/bar/bar.css" rel="stylesheet" type="text/css" media="screen" />	
	<link href="<?php echo G5_URL?>/plugin/nivo/nivo-slider.css" rel="stylesheet" type="text/css" media="screen" />	

	<div class="slider-wrapper theme-default">
	<?php 
	if($is_admin) { ?>
	<div class="admin-btn">
	<a href="<?php echo G5_BBS_URL?>/board.php?bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>" class="hnBtn small admin" >수정</a>
	</div>
	<?php } ?>

	<div id="slider" class="<?php echo $slider_class?>">
	<?php echo $img_tag ?>	
	</div>	
	<?php echo $caption_str ?>
	</div>

	<script type="text/javascript" src="<?php echo G5_URL?>/plugin/nivo/jquery.nivo.slider.js"></script>
	<script type="text/javascript">	
	$(window).load(function() {		
		$('#slider.<?php echo $slider_class;?>').nivoSlider({
			effect: 'random',               // Specify sets like: 'fold,fade,sliceDown'
			slices: 15,                     // For slice animations
			boxCols: 8,                     // For box animations
			boxRows: 4,                     // For box animations
			animSpeed: 500,                 // Slide transition speed
			pauseTime: <?php echo $pause_time?>,    // How long each slide will show
			startSlide: 0,                  // Set starting Slide (0 index)
			directionNav: true,             // Next & Prev navigation
			controlNav: true,               // 1,2,3... navigation
			controlNavThumbs: false,        // Use thumbnails for Control Nav
			pauseOnHover: true,             // Stop animation while hovering
			manualAdvance: false,           // Force manual transitions
			prevText: 'Prev',               // Prev directionNav text
			nextText: 'Next',               // Next directionNav text
			randomStart: false,             // Start on a random slide
			beforeChange: function(){},     // Triggers before a slide transition
			afterChange: function(){},      // Triggers after a slide transition
			slideshowEnd: function(){},     // Triggers after all slides have been shown
			lastSlide: function(){},        // Triggers when last slide is shown
			afterLoad: function(){}         // Triggers when slider has loaded
		});
	});
	</script>
<?php } else { ?>	
	<div class="empty-msg">
	<a href="<?php echo G5_BBS_URL?>/write.php?w=u&bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>">이미지를 추가해 주세요.</a>
	</div>
<?php } ?>
</div>
<script>
$(function() {	
	$("#nivoSlider img").one("load", function() {
		$('.slider-wrapper').addClass('active');		
	}).each(function() {
		if(this.complete) $(this).load();
	});	
}) ;
</script>