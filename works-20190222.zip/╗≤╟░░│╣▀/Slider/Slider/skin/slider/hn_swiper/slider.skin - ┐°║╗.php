<?php
/* 
 * hn_swiper_basic : $wr_id에 해당되는 게시물의 이미지 슬라이더
 * 
 * jQuery Plugin : Swiper - Mobile Touch Slider : http://idangero.us/swiper/
 * 
 * [ 사용법 ] 
 * ---------------------------------------------------------------------------- 
 * include_once(G5_LIB_PATH.'/slider.lib.php'); 
 * // 매개변수 : 스킨명, 게시판명, wr_id, 이미지 개수
 * echo slider("hn_swiper_basic", $bo_table, $wr_id, 3);
 * ----------------------------------------------------------------------------
 */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가 

$img_idx = 0;
$img_count = $list[file]['count'];
$img_tag = "";
$caption_str = "";
$slider_class = "swiper-".rand();

//출력할 이미지 개수 체크
if ($number && $img_count > $number) {
	$img_count = $number;
}

for ($i=0; $i<$img_count; $i++) {	
	$img_file = $list[file][$i][path]."/".$list[file][$i][file]; // 원본 이미지
		 
	if(preg_match("/\.(jp[e]?g|gif|png)$/i", $img_file)) {			
		$img_idx++;		
		$img_tag .= "	<li class=\"swiper-slide\">";
		
		// 이미지캡션
		if($list[file][$i][bf_content] && strlen($list[file][$i][bf_content]) > 2) {
			$list_href = $list[file][$i][bf_content];			
			//링크 체크
			if (preg_match('#^https?://#i', $list_href)) {				
				$img_tag .= "<a href=\"$list_href\"><img src=\"$img_file\" alt=\"\" border=\"0\" /></a>";
			} else {
				$list_content = $list[file][$i][bf_content];
				$img_tag .= "<div class=\"img-caption\">$list_content</div>";	
				$img_tag .= "<img src=\"$img_file\" alt=\"\" border=\"0\" title=\"#imgcaption".$i."\" />";
			}			
		} else {
			$img_tag .= "<img src=\"$img_file\" alt=\"\" border=\"0\" />";
		}
		$img_tag .= "</li>\n";
	}	
}
?>
<link href="<?php echo $slider_skin_url?>/hn_swiper_basic.css" rel="stylesheet" >
<link href="<?php echo G5_URL?>/plugin/swiper/swiper.min.css" rel="stylesheet">
<style>
.swiper-button-prev {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTEuNDMzIDE1Ljk5MkwyMi42OSA1LjcxMmMuMzkzLS4zOS4zOTMtMS4wMyAwLTEuNDItLjM5My0uMzktMS4wMy0uMzktMS40MjMgMGwtMTEuOTggMTAuOTRjLS4yMS4yMS0uMy40OS0uMjg1Ljc2LS4wMTUuMjguMDc1LjU2LjI4NC43N2wxMS45OCAxMC45NGMuMzkzLjM5IDEuMDMuMzkgMS40MjQgMCAuMzkzLS40LjM5My0xLjAzIDAtMS40MmwtMTEuMjU3LTEwLjI5IiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIxIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=);    
}
.swiper-button-next {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTAuNzIyIDQuMjkzYy0uMzk0LS4zOS0xLjAzMi0uMzktMS40MjcgMC0uMzkzLjM5LS4zOTMgMS4wMyAwIDEuNDJsMTEuMjgzIDEwLjI4LTExLjI4MyAxMC4yOWMtLjM5My4zOS0uMzkzIDEuMDIgMCAxLjQyLjM5NS4zOSAxLjAzMy4zOSAxLjQyNyAwbDEyLjAwNy0xMC45NGMuMjEtLjIxLjMtLjQ5LjI4NC0uNzcuMDE0LS4yNy0uMDc2LS41NS0uMjg2LS43NkwxMC43MiA0LjI5M3oiIGZpbGw9IiNmZmZmZmYiIG9wYWNpdHk9IjEiIGZpbGwtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==);    
}
</style>

<div id="swiperSlider"  class="swiper-slider <?php echo $slider_class?>">
	<?php if($is_admin) { ?>
	<div class="admin-btn">
	<a href="<?php echo G5_BBS_URL?>/board.php?bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>" class="hnBtn small admin" >수정</a>
	</div>
	<?php } ?>
<?php
if($img_tag) {
?>
	<ul class="swiper-wrapper">
		<?php echo $img_tag ?>
	</ul>
	<div class="swiper-pagination"></div>
	<div class="swiper-button-prev"></div>
	<div class="swiper-button-next"></div>
<?php } else { 	?>
	<div class="empty-msg">
		<a href="<?php echo G5_BBS_URL?>/write.php?w=u&bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>">이미지를 추가해 주세요.</a>
	</div>
<?php } ?>
</div>

<script src="<?php echo G5_URL?>/plugin/swiper/swiper.min.js"></script>
<script>
var mySwiper = new Swiper ('.swiper-slider.<?php echo $slider_class?>', {
    loop: true,
    pagination: {
      el: '.swiper-pagination',
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    }
});

$(function() {	
	$(".swiper-slide img").one("load", function() {
		$('.swiper-slide img').addClass('active');		
	}).each(function() {
		if(this.complete) $(this).load();
	});	
}) ;
</script>