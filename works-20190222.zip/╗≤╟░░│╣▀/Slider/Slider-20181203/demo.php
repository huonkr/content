<?php
include_once('./_common.php');
include_once(G5_PATH.'/head.sub.php');
?>
<style>
html, body { background-color:#393939; }

.hn h1 { 
	width: 500px; margin: 3em auto;
	background-color: white; border: 3px dashed #6bb2b6;
	line-height:3em; text-align:center; color:#0F7693;

	/*shadow*/
	-webkit-box-shadow: 3px 6px 12px rgba(0,0,0,0.2);
	-moz-box-shadow: 3px 6px 12px rgba(0,0,0,0.2);
	box-shadow: 3px 6px 12px rgba(0,0,0,0.2);

	/*rounded corners*/
	-webkit-border-radius: 20px;
	-moz-border-radius: 20px;
	border-radius: 20px;
}
#sidebar { display:none; }
</style>


<div class="hn">
	<h1>HN SLIDER</h1>
</div>

<?php 
include_once(G5_LIB_PATH.'/slider.lib.php');
?>



<!-- hn_nivo_basic -->
<?php
/*
include_once(G5_LIB_PATH.'/slider.lib.php');
*/
// hn_nivo_basic slider
// 매개변수 : 스킨명, 게시판명, wr_id
echo slider("hn_nivo_basic", "media", 1);

?>

<br>

<!-- hn_owl_basic -->
<?php
/*
include_once(G5_LIB_PATH.'/slider.lib.php');
*/
// hn_owl slider
// 매개변수 : 스킨명, 게시판명, wr_id
echo slider("hn_owl_basic", "media", 1);
 
?>

<br>

<!-- hn_swiper_basic --> 
<?php
/* 
include_once(G5_LIB_PATH.'/slider.lib.php');
*/
// hn_swiper_basic
// 매개변수 : 스킨명, 게시판명, wr_id
echo slider("hn_swiper_basic", "media", 1); 

?>

<br>

<!-- hn_nivo -->
<?php
/*
include_once(G5_LIB_PATH.'/slider.lib.php');

// hn_nivo slider
$slider_options = array(
	'height' 		=> "550px|70vw", // 슬라이더 기본 높이, 반응형 높이(% 또는 vw)	
	'num' 			=> 5, // 이미지수
	'pause_time' 	=> 3, // 슬라이드 멈춤 시간(초)	
	'is_headline' 	=> true, // 타이틀 출력 여부
	'is_lead' 		=> true, // 리드문 출력 여부
	'is_lead_html' 	=> false, // 리드문(내용)에 포함된 html 적용여부
	'text_top' 		=> "25%", // 텍스트 상단포지션(%, vh, px)
	'text_align' 	=> "center", // 텍스트정렬(left, center, right)
	'text_hide_time' => 0, // 슬라이드 전환 후 텍스트 사라짐 효과, 0이면 계속 보임	
	'headline_style' => "padding:0; font-size:4rem; color:#fff; background-color:transparent; ", // 타이틀 스타일
	'lead_style' => "text-align:center; color:#fff; background-color:transparent; outline-color:transparent; " // 리드문 스타일
);
// 매개변수 : 스킨명, 게시판명, wr_id, 옵션
echo slider("hn_nivo", "media", 1, $slider_options);
*/
?>

<br>

<!-- hn_owl -->
<?php
/*  
include_once(G5_LIB_PATH.'/slider.lib.php');

// hn_owl slider
$slider_options = array(
	'height' 		=> "550px|70vw", // 슬라이더 기본 높이, 반응형 높이(% 또는 vw)	
	'num' 			=> 5, // 이미지수
	'is_headline' 	=> true, // 타이틀 출력 여부
	'is_lead' 		=> true, // 내용 출력 여부
	'is_lead_html' 	=> false, // 리드문(내용)에 포함된 html 적용여부
	'is_caption' 	=> true, // 이미지 캡션 출력 여부
	'text_top' 		=> "25%", // 텍스트 상단포지션(%, vh, px)
	'text_align'	=> "center", // 텍스트정렬 : left, center, right		
	'text_hide_time' => 0, // 슬라이드 전환 후 텍스트 사라짐 효과, 0이면 계속 보임
	'headline_style' => "padding:0; font-size:4rem; color:#fff; background-color:transparent; ", // 타이틀 스타일
	'lead_style' => "text-align:center; color:#fff; background-color:transparent; outline-color:transparent; " // 리드문 스타일
);
// 매개변수 : 스킨명, 게시판명, wr_id, 옵션
echo slider("hn_owl", "media", 1, $slider_options);
*/
?>
 
<br>

<!-- hn_swiper -->
<?php
/* 
include_once(G5_LIB_PATH.'/slider.lib.php');

// hn_swiper
$slider_options = array(
	'height' 		=> "550px|70vw", // 슬라이더 기본 높이, 반응형 높이(% 또는 vw)	
	'num' 			=> 5, // 이미지수
	'is_headline' 	=> true, // 타이틀 출력 여부
	'is_lead' 		=> true, // 내용 출력 여부
	'is_lead_html' 	=> false, // 리드문(내용)에 포함된 html 적용여부
	'is_caption' 	=> true, // 이미지 캡션 출력 여부
	'text_top' 		=> "25%", // 텍스트 상단포지션(%, vh, px)
	'text_align'	=> "center", // 텍스트정렬 : left, center, right		
	'text_hide_time' => 0, // 슬라이드 전환 후 텍스트 사라짐 효과, 0이면 계속 보임	
	'headline_style' => "padding:0; font-size:4rem; color:#fff; background-color:transparent; ", // 타이틀 스타일
	'lead_style' => "text-align:center; color:#fff; background-color:transparent; outline-color:transparent; " // 리드문 스타일	
);	
// 매개변수 : 스킨명, 게시판명, wr_id, 옵션
echo slider("hn_swiper", "media", 1, $slider_options);
*/
?>



<br><br>



	
<?php
include_once(G5_PATH.'/tail.sub.php');
?>
