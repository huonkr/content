<?php
/* 
 * hn_swiper 슬라이더 
 * 
 * Swiper - Mobile Touch Slider : http://idangero.us/swiper/
 *
 * 사용법
 * ---------------------------------------------------------------------------- 
 * include_once(G5_LIB_PATH.'/slider.lib.php');
 * 
 * // hn_swiper
 * $slider_options = array(
 * 	'height' 		=> "550px|70vw", // 슬라이더 기본 높이, 반응형 높이(% 또는 vw)	
 * 	'num' 			=> 5, // 이미지수
 * 	'is_headline' 	=> true, // 타이틀 출력 여부
 * 	'is_lead' 		=> true, // 내용 출력 여부
 * 	'is_caption' 	=> true, // 이미지 캡션 출력 여부
 * 	'text_top' 		=> "25%", // 텍스트 상단포지션(%, vh, px)
 * 	'text_align'	=> "center", // 텍스트정렬 : left, center, right		
 * 	'text_hide_time' => 0, // 슬라이드 전환 후 텍스트 사라짐 효과, 0이면 계속 보임	
 * 	'headline_style' => "padding:0; font-size:4rem; color:#fff; background-color:transparent; ", // 타이틀 스타일
 * 	'lead_style' => "text-align:center; color:#fff; background-color:transparent; outline-color:transparent; " // 리드문 스타일	
 * );	
 * // 매개변수 : 스킨명, 게시판명, wr_id, 옵션
 * echo slider("hn_swiper", "media", 1, $slider_options);
 * ----------------------------------------------------------------------------
 */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가 

// 옵션 변수화
extract($options);

$tmp_arr = explode("|", $height);
$height = $tmp_arr[0];
$r_height = $tmp_arr[1];

if ($is_headline) {
	$wr_subject = $list['wr_subject'];
}

if ($is_lead) {
	// html 출력여부
	if ($is_lead_html) {
		$wr_content = $list['wr_content'];
	} else {
		$list['wr_content'] = str_ireplace("</p><p>", "</p>\n\r<p>", $list['wr_content']);
		$wr_content = nl2br(strip_tags($list['wr_content']));
	}	
}

$img_idx = 0;
$img_count = count($list[file]);
$img_tag = "";

//출력할 이미지 개수 체크
if($img_count > $num) {
	$img_count = $num;
}

for ($i=0; $i<$img_count; $i++) {	
	$img_file = $list[file][$i][path]."/".$list[file][$i][file]; // 원본 이미지
		 
	if(preg_match("/\.(jp[e]?g|gif|png)$/i", $img_file)) {			
		$img_idx++;		
		$img_tag .= "	<li class=\"swiper-slide\">";
		
		// 이미지캡션
		if($list[file][$i][bf_content] && strlen($list[file][$i][bf_content]) > 2) {
			$list_href = $list[file][$i][bf_content];			
			//링크 체크
			if (preg_match('#^https?://#i', $list_href)) {				
				$img_tag .= "<a href=\"$list_href\"><img src=\"$img_file\" alt=\"\" border=\"0\" /></a>";
			} else {
				if ($is_caption) {
					$list_content = $list[file][$i][bf_content];
					$img_tag .= "<div class=\"img-caption\">$list_content</div>";	
				}
				$img_tag .= "<img src=\"$img_file\" alt=\"\" border=\"0\" title=\"#imgcaption".$i."\" />";
			}			
		} else {
			$img_tag .= "<img src=\"$img_file\" alt=\"\" border=\"0\" />";
		}
		$img_tag .= "</li>\n";
	}	
}
?>
<link href="<?php echo $slider_skin_url?>/hn_swiper.css" rel="stylesheet" >
<link href="<?php echo G5_URL?>/plugin/swiper/swiper.min.css" rel="stylesheet">
<style>
<?php 
if ($height) { 
	echo ".swiper-slide img { height:{$height}; }\n";	
}

if ($r_height) { 
	echo "@media screen and (max-width:1024px) { \n";
	echo "	.swiper-slide img { height:{$r_height} !important; } \n";
	echo "}\n";
} else {
	echo "@media screen and (max-width:1024px) { \n";
	echo "	.swiper-slide img { width:100%; max-height:auto; } \n";
	echo "}\n";
}

if ($text_top || $text_align || $is_lead_html) { 
	echo "#swiperSlider .visual-content { ";
	echo ($text_top) ? "top:{$text_top}; " : "";
	echo ($text_align) ? "text-align:{$text_align}; " : "";
	echo ($is_lead_html) ? "pointer-events:auto; " : "";
	echo " }	\n";
}

if ($headline_style) { 
	echo "#swiperSlider .visual-content.active .headline { ".$headline_style." } \n";
}
if ($lead_style) { 
	echo "#swiperSlider .visual-content.active .lead-text { ".$lead_style." } \n";
}
?>
.swiper-button-prev {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTEuNDMzIDE1Ljk5MkwyMi42OSA1LjcxMmMuMzkzLS4zOS4zOTMtMS4wMyAwLTEuNDItLjM5My0uMzktMS4wMy0uMzktMS40MjMgMGwtMTEuOTggMTAuOTRjLS4yMS4yMS0uMy40OS0uMjg1Ljc2LS4wMTUuMjguMDc1LjU2LjI4NC43N2wxMS45OCAxMC45NGMuMzkzLjM5IDEuMDMuMzkgMS40MjQgMCAuMzkzLS40LjM5My0xLjAzIDAtMS40MmwtMTEuMjU3LTEwLjI5IiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIxIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=);    
}
.swiper-button-next {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTAuNzIyIDQuMjkzYy0uMzk0LS4zOS0xLjAzMi0uMzktMS40MjcgMC0uMzkzLjM5LS4zOTMgMS4wMyAwIDEuNDJsMTEuMjgzIDEwLjI4LTExLjI4MyAxMC4yOWMtLjM5My4zOS0uMzkzIDEuMDIgMCAxLjQyLjM5NS4zOSAxLjAzMy4zOSAxLjQyNyAwbDEyLjAwNy0xMC45NGMuMjEtLjIxLjMtLjQ5LjI4NC0uNzcuMDE0LS4yNy0uMDc2LS41NS0uMjg2LS43NkwxMC43MiA0LjI5M3oiIGZpbGw9IiNmZmZmZmYiIG9wYWNpdHk9IjEiIGZpbGwtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==);    
}
</style>

<div id="swiperSlider"  class="swiper-slider">
	<?php if($is_admin) { ?>
	<div class="admin-btn">
	<a href="<?php echo G5_BBS_URL?>/board.php?bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>" class="hnBtn small admin" >수정</a>
	</div>
	<?php } ?>
<?php
if($img_tag) {
?>
	<ul class="swiper-wrapper">
		<?php echo $img_tag ?>
	</ul>	
	<div class="swiper-pagination"></div>
	<div class="swiper-button-prev"></div>
	<div class="swiper-button-next"></div>
	
<?php } else { 	?>
	<div class="empty-msg">
		<a href="<?php echo G5_BBS_URL?>/write.php?w=u&bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>">이미지를 추가해 주세요.</a>
	</div>
<?php } ?>

	<div class="visual-content">
		<h1 class="headline"><?php echo $wr_subject?></h1>
		<div class="lead">
		<?php if ($wr_content) { echo "		<div class=\"lead-text\">{$wr_content}</div>"; } ?>
		</div>	
	</div>
</div>

<script src="<?php echo G5_URL?>/plugin/swiper/swiper.min.js"></script>
<script>
var slide_idx = 0;	
var end_idx = <?php echo ($text_hide_time) ? $text_hide_time:0; ?>;
	
var mySwiper = new Swiper ('.swiper-slider', {
    loop: true,
    pagination: {
      el: '.swiper-pagination',
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    }
});

mySwiper.on('slideChange', function () {
	if (end_idx) {
		slide_idx++;
		if ( slide_idx >= end_idx && $('#swiperSlider .visual-content').hasClass('active') ) {
			$('#swiperSlider .visual-content').removeClass('active');
		}
	}
});  


$(function() {	
	$(".swiper-slide img").one("load", function() {
		$('.swiper-slide img').addClass('active');
		$('#swiperSlider .visual-content').addClass('active');
	}).each(function() {
		if(this.complete) $(this).load();
	});	
}) ;
</script>