<?php
/* 
 * hn_owl 슬라이더
 * 
 * OWL Carousel : https://owlcarousel2.github.io/OwlCarousel2/
 *
 * 사용법
 * ----------------------------------------------------------------------------
 * include_once(G5_LIB_PATH.'/slider.lib.php');
 * 
 * // 슬라이더 옵션
 * $slider_options = array(
 * 	'height' 		=> "550px|70vw", // 슬라이더 기본 높이, 반응형 높이(% 또는 vw)	
 * 	'num' 			=> 5, // 이미지수
 * 	'is_headline' 	=> true, // 타이틀 출력 여부
 * 	'is_lead' 		=> true, // 내용 출력 여부
 * 	'is_caption' 	=> true, // 이미지 캡션 출력 여부
 * 	'text_top' 		=> "25%", // 텍스트 상단포지션(%, vh, px)
 * 	'text_align'	=> "center", // 텍스트정렬 : left, center, right		
 * 	'text_hide_time' => 0, // 슬라이드 전환 후 텍스트 사라짐 효과, 0이면 계속 보임
 * 	'headline_style' => "padding:0; font-size:4rem; color:#fff; background-color:transparent; ", // 타이틀 스타일
 * 	'lead_style' => "text-align:center; color:#fff; background-color:transparent; outline-color:transparent; " // 리드문 스타일
 * );
 * // 매개변수 : 스킨명, 게시판명, wr_id, 옵션
 * echo slider("hn_owl", "media", 1, $slider_options);
 * ----------------------------------------------------------------------------
 */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가 

// 옵션 변수화
extract($options);

$tmp_arr = explode("|", $height);
$height = $tmp_arr[0];
$r_height = $tmp_arr[1];

if ($is_headline) {
	$wr_subject = $list['wr_subject'];
}
if ($is_lead) {
	// html 출력여부
	if ($is_lead_html) {
		$wr_content = $list['wr_content'];
	} else {
		$list['wr_content'] = str_ireplace("</p><p>", "</p>\n\r<p>", $list['wr_content']);
		$wr_content = nl2br(strip_tags($list['wr_content']));
	}	
}

$img_idx = 0;
$img_count = count($list[file]);
$img_tag = "";

//출력할 이미지 개수 체크
if($img_count > $num) {
	$img_count = $num;
}
?>
<link rel="stylesheet" href="<?php echo $slider_skin_url?>/hn_owl.css">
<link href="<?php echo G5_URL?>/plugin/owl/owl.carousel.min.css" rel="stylesheet">
<link href="<?php echo G5_URL?>/plugin/owl/owl.theme.default.min.css" rel="stylesheet">
<style>
<?php 
if ($height) { 
	echo ".owl-carousel .item img { height:{$height}; } \n";
}
if ($r_height) { 
	echo "@media screen and (max-width:1024px) { \n";
	echo "	.owl-carousel .item img { max-height:{$r_height} !important; } \n";
	echo "} \n";
}

if ($text_top || $text_align || $is_lead_html) { 
	echo "#owlSlider .visual-content { ";
	echo ($text_top) ? "top:{$text_top}; " : "";
	echo ($text_align) ? "text-align:{$text_align}; " : "";
	echo ($is_lead_html) ? "pointer-events:auto; " : "";
	echo " }	\n";
}

if ($headline_style) { 
	echo "#owlSlider .visual-content.active .headline { {$headline_style}} \n";
}

if ($lead_style) {
	echo "#owlSlider .visual-content.active .lead-text { {$lead_style} } \n";
}
?>



<?php /*
#owlSlider .visual-content h1 { <?php if ($title_color) { ?>color:<?php echo $title_color; ?>; text-shadow:none; <?php } ?> }
#owlSlider .visual-content p { <?php if ($content_bgcolor) { ?>background-color:<?php echo $content_bgcolor; ?>; outline-color:<?php echo $content_bgcolor; ?>;<?php } ?> <?php if ($content_color) { ?>color:<?php echo $content_color; ?>;<?php } ?> <?php if ($align) { ?>text-align:<?php echo $align; ?>;<?php } ?> }	
*/ ?>
</style>
<div id="owlSlider"> 	
<?php if($is_admin) { ?>
	<div class="admin-btn">
	<a href="<?php echo G5_BBS_URL?>/board.php?bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>" class="hnBtn small admin" >수정</a>
	</div>
<?php } ?>
<div class="owl-carousel">
<?php
for ($i=0; $i<$img_count; $i++) {	
	$img_file = $list[file][$i][path]."/".$list[file][$i][file]; // 원본 이미지
	
	// 업로드된 파일 이미지가 존재하면
	if (preg_match("/\.(jp[e]?g|gif|png)$/i", $img_file)) {
		$img_tag = "";
		$img_idx++;		
		
		// 이미지캡션
		if($list[file][$i][bf_content] && strlen($list[file][$i][bf_content]) > 2) {
			$list_href = $list[file][$i][bf_content];
			//링크 체크
			if (preg_match('#^https?://#i', $list_href)) {				
				$img_tag .= "	<a href=\"$list_href\"><img src=\"$img_file\" alt=\"\" border=\"0\" /></a> \n";
			} else {
				if ($is_caption) {
					$list_content = $list[file][$i][bf_content];
					$img_tag .= "<div class=\"img-caption\">$list_content</div>";	
				}
				$img_tag .= "	<img src=\"$img_file\" alt=\"\" border=\"0\" title=\"#imgcaption".$i."\" /> \n";				
			}			
		} else {
			$img_tag .= "	<img src=\"$img_file\" alt=\"\" border=\"0\" /> \n";
		}
?>		
	<div class="item" rel="<?php echo $i?>">
		<?php echo $img_tag?>		
	</div>	
<?php		
	}
}
?>
</div>

<div class="visual-content">
	<h1 class="headline"><?php echo $wr_subject?></h1>
	<div class="lead">
	<?php if ($wr_content) { echo "		<div class=\"lead-text\">{$wr_content}</div>"; } ?>
	</div>	
</div>
</div>

<?php if ($img_count <= 1) { ?>
<style>#owlSlider { display:none;}</style>
<div class="empty-msg">
	<a href="<?php echo G5_BBS_URL?>/write.php?w=u&bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>">이미지를 추가해 주세요.</a>
</div>
<?php } ?>

<script src="<?php echo G5_URL?>/plugin/owl/owl.carousel.js"></script>
<script>
$(function() {
	var slide_idx = 0;	
	var end_idx = <?php echo ($text_hide_time) ? $text_hide_time:0; ?>;
	
	$(".owl-carousel").owlCarousel({  
		loop:true,
		margin:10,
		items: 1,
		navigation : false,
		dots : false,
		slideSpeed : 300,
		paginationSpeed : 400,
		autoHeight : true,
		singleItem : true
	});
	
	$(".owl-carousel").on('changed.owl.carousel', function(event) { 
		if (end_idx) {
			slide_idx++;
			if ( slide_idx >= end_idx && $('#owlSlider .visual-content').hasClass('active') ) {
				$('#owlSlider .visual-content').removeClass('active');
			}
		}
	});
  
	$(".owl-carousel img").one("load", function() {
		$('#owlSlider .owl-carousel').addClass('active');
		$('#owlSlider .visual-content').addClass('active');
	}).each(function() {
		if(this.complete) $(this).load();
	});	  
});
</script>

