<?php
/* 
 * hn_owl
 * 
 * OWL Carousel : https://owlcarousel2.github.io/OwlCarousel2/
 * ----------------------------------------------------------------------------
 * include_once(G5_LIB_PATH.'/slider.lib.php');
 * // hn_owl slider
 * // 매개변수 : 스킨명, 게시판명, wr_id, 옵션
 * echo slider("hn_owl_basic", $bo_table, $wr_id); 
 * ----------------------------------------------------------------------------
 */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가 

$img_idx = 0;
$img_count = count($list[file]);
?>
<link rel="stylesheet" href="<?php echo $slider_skin_url?>/hn_owl_basic.css">
<link href="<?php echo G5_URL?>/plugin/owl/owl.carousel.min.css" rel="stylesheet">
<link href="<?php echo G5_URL?>/plugin/owl/owl.theme.default.min.css" rel="stylesheet">

<div id="owlSlider">
<?php if($is_admin) { ?>
	<div class="admin-btn">
	<a href="<?php echo G5_BBS_URL?>/board.php?bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>" class="hnBtn small admin" >수정</a>
	</div>
<?php } ?>
<div class="owl-carousel">
<?php
for ($i=0; $i<$img_count; $i++) {	
	$img_file = $list[file][$i][path]."/".$list[file][$i][file]; // 원본 이미지
	
	// 업로드된 파일 이미지가 존재하면
	if (preg_match("/\.(jp[e]?g|gif|png)$/i", $img_file)) {
		$img_tag = "";
		$img_idx++;		
		
		// 이미지캡션
		if($list[file][$i][bf_content] && strlen($list[file][$i][bf_content]) > 2) {
			$list_href = $list[file][$i][bf_content];
			//링크 체크
			if (preg_match('#^https?://#i', $list_href)) {				
				$img_tag .= "	<a href=\"$list_href\"><img src=\"$img_file\" alt=\"\" border=\"0\" /></a> \n";
			} else {
				$list_content = $list[file][$i][bf_content];				
				$img_tag .= "	<img src=\"$img_file\" alt=\"\" border=\"0\" title=\"#imgcaption".$i."\" /> \n";
				$img_tag .= "	<div class=\"img-caption\">$list_content</div> \n";
			}			
		} else {
			$img_tag .= "	<img src=\"$img_file\" alt=\"\" border=\"0\" /> \n";
		}
?>		
	<div class="item" rel="<?php echo $i?>">
		<?php echo $img_tag?>
	</div>		
<?php		
	}
} 
?>
</div>
</div>

<?php if ($img_count <= 1) { ?>
<style>#owlSlider { display:none;}</style>
<div class="empty-msg">
	<a href="<?php echo G5_BBS_URL?>/write.php?w=u&bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>">이미지를 추가해 주세요.</a>
</div>
<?php } ?>

<script src="<?php echo G5_URL?>/plugin/owl/owl.carousel.js"></script>
<script>
$(function() {
  $(".owl-carousel").owlCarousel({  
	loop:true,
    margin:10,
	items: 1,
	navigation : false,
	dots : false,
	slideSpeed : 300,
	paginationSpeed : 400,
	autoHeight : true,
	singleItem : true
  });
});
</script>

