<?php
/* 
 * hn_nivo 슬라이더
 * 
 * Nivo-Slider-jQuery : https://github.com/Codeinwp/Nivo-Slider-jQuery
 *
 * 사용법
 * ----------------------------------------------------------------------------
 * include_once(G5_LIB_PATH.'/slider.lib.php');
 * 
 * // 슬라이더 옵션
 * $slider_options = array(
 * 	'height' 		=> "550px|70vw", // 슬라이더 기본 높이, 반응형 높이(% 또는 vw)	
 * 	'num' 			=> 5, // 이미지수
 * 	'pause_time' 	=> 3, // 슬라이드 멈춤 시간(초)	
 * 	'is_headline' 	=> true, // 타이틀 출력 여부
 * 	'is_lead' 		=> true, // 리드문 출력 여부
 * 	'text_top' 		=> "25%", // 텍스트 상단포지션(%, vh, px)
 * 	'text_align' 	=> "center", // 텍스트정렬(left, center, right)
 * 	'text_hide_time' => 0, // 슬라이드 전환 후 텍스트 사라짐 효과, 0이면 계속 보임	
 * 	'headline_style' => "padding:0; font-size:4rem; color:#fff; background-color:transparent; ", // 타이틀 스타일
 * 	'lead_style' => "text-align:center; color:#fff; background-color:transparent; outline-color:transparent; " // 리드문 스타일
 * );
 * // 매개변수 : 스킨명, 게시판명, wr_id, 옵션
 * echo slider("hn_nivo", "media", 1, $slider_options);
 * ----------------------------------------------------------------------------
 */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

// 옵션 변수화
extract($options);

$tmp_arr = explode("|", $height);
$height = $tmp_arr[0];
$r_height = $tmp_arr[1];

if ($is_headline) {
	$wr_subject = $list['wr_subject'];
}
if ($is_lead) {
	// html 출력여부
	if ($is_lead_html) {
		$wr_content = $list['wr_content'];
	} else {
		$list['wr_content'] = str_ireplace("</p><p>", "</p>\n\r<p>", $list['wr_content']);
		$wr_content = nl2br(strip_tags($list['wr_content']));
	}
}

$img_idx = 0;
$img_count = count($list[file]);
$img_tag = "";
$caption_str = "";

if(!$pause_time) {
	$pause_time=5;
} 
$pause_time *= 1000;

//출력할 이미지 개수 체크
if($img_count > $num) {
	$img_count = $num;
}

for ($i=0; $i<$img_count; $i++) {	
	$img_file = $list[file][$i][path]."/".$list[file][$i][file]; // 원본 이미지
	
	// 업로드된 파일 이미지가 존재하면
	if (preg_match("/\.(jp[e]?g|gif|png)$/i", $img_file)) {
		$img_idx++;		
		
		// 이미지캡션
		if($list[file][$i][bf_content] && strlen($list[file][$i][bf_content]) > 2) {
			$list_href = $list[file][$i][bf_content];
			//링크 체크
			if (preg_match('#^https?://#i', $list_href)) {				
				$img_tag .= "	<a href=\"$list_href\"><img src=\"$img_file\" alt=\"\" border=\"0\" /></a> \n";
			} else {
				$list_content = $list[file][$i][bf_content];
				$caption_str .= "<div id=\"imgcaption".$i."\" class=\"nivo-html-caption\">$list_content</div> \n";	
				$img_tag .= "	<img src=\"$img_file\" alt=\"\" border=\"0\" title=\"#imgcaption".$i."\" /> \n";
			}			
		} else {
			$img_tag .= "	<img src=\"$img_file\" alt=\"\" border=\"0\" /> \n";
		}
	}
}
?>
<link href="<?php echo $slider_skin_url?>/hn_nivo.css" rel="stylesheet" type="text/css">	
<style>	
<?php 
if ($height) { 
	echo "#nivoSlider { max-height:{$height}; }\n";
	echo "#nivoSlider #slider { max-height:{$height};}\n";
	echo "#nivoSlider #slider img { min-height:{$height}; height:{$height} !important; } \n";
	
}
if ($r_height) { 
	echo "@media screen and (max-width:1024px) { \n";
	echo "	#nivoSlider #slider img { min-height:auto; height:{$r_height} !important; } \n";
	echo "}\n";
}

if ($text_top || $text_align || $is_lead_html) { 
	echo "#nivoSlider .visual-content { ";
	echo ($text_top) ? "top:{$text_top}; " : "";
	echo ($text_align) ? "text-align:{$text_align}; " : "";
	echo ($is_lead_html) ? "pointer-events:auto; " : "";
	echo " }	\n";
}

if ($headline_style) { 
	echo "#nivoSlider .visual-content.active .headline { {$headline_style}} \n";
}

if ($lead_style) {
	echo "#nivoSlider .visual-content.active .lead-text { {$lead_style} } \n";
}
?>
</style>
<div id="nivoSlider">
<?php
if($img_tag) {
?>
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/themes/default/default.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/themes/light/light.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/themes/dark/dark.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/themes/bar/bar.css" type="text/css" media="screen" />	
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/nivo-slider.css" type="text/css" media="screen" />	

	<div class="slider-wrapper theme-default">
	<?php 
	if($is_admin) { ?>
	<div class="admin-btn">
	<a href="<?php echo G5_BBS_URL?>/board.php?bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>" class="hnBtn small admin" >수정</a>
	</div>
	<?php } ?>

	<div id="slider">
	<?php echo $img_tag ?>	
	</div>	
	<?php echo $caption_str ?>
	
	<div class="visual-content">
		<h1 class="headline"><?php echo $wr_subject?></h1>
		<div class="lead">
		<?php if ($wr_content) { echo "		<div class=\"lead-text\">{$wr_content}</div>"; } ?>
		</div>	
	</div>
	</div>	

	<script type="text/javascript" src="<?php echo G5_URL?>/plugin/nivo/jquery.nivo.slider.js"></script>
	<script type="text/javascript">	
	$(window).load(function() {
		var slide_idx = 0;	
		var end_idx = <?php echo ($text_hide_time)?$text_hide_time:0; ?>;
		$('#slider').nivoSlider({
			effect: 'random',               // Specify sets like: 'fold,fade,sliceDown'
			slices: 15,                     // For slice animations
			boxCols: 8,                     // For box animations
			boxRows: 4,                     // For box animations
			animSpeed: 500,                 // Slide transition speed
			pauseTime: <?php echo $pause_time?>,    // How long each slide will show
			startSlide: 0,                  // Set starting Slide (0 index)
			directionNav: true,             // Next & Prev navigation
			controlNav: true,               // 1,2,3... navigation
			controlNavThumbs: false,        // Use thumbnails for Control Nav
			pauseOnHover: true,             // Stop animation while hovering
			manualAdvance: false,           // Force manual transitions
			prevText: 'Prev',               // Prev directionNav text
			nextText: 'Next',               // Next directionNav text
			randomStart: false,             // Start on a random slide
			beforeChange: function(){},     // Triggers before a slide transition
			afterChange: function(){
				if (end_idx) {
					slide_idx++;
					if ( slide_idx >= end_idx && $('#nivoSlider .visual-content').hasClass('active') ) {
						$('#nivoSlider .visual-content').removeClass('active');
					}
				}
			},      // Triggers after a slide transition
			slideshowEnd: function(){},     // Triggers after all slides have been shown
			lastSlide: function(){},        // Triggers when last slide is shown
			afterLoad: function(){}         // Triggers when slider has loaded
		});  
	});
	</script>
<?php } else { ?>	
	<div class="empty-msg">
	<a href="<?php echo G5_BBS_URL?>/write.php?w=u&bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>">이미지를 추가해 주세요.</a>
	</div>
<?php } ?>

</div>
<script>
$(function() {	
	$("#nivoSlider img").one("load", function() {
		$('#nivoSlider .slider-wrapper').addClass('active');
		$('#nivoSlider .visual-content').addClass('active');
	}).each(function() {
		if(this.complete) $(this).load();
	});	
}) ;
</script>