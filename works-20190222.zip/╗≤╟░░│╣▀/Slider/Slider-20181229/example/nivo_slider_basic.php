<?php
include_once('./_common.php');
include_once(G5_PATH.'/head.sub.php');
?>
<style>
html, body { background-color:#393939; }

.hn h1 { 
	width: 500px; margin: 3em auto;
	background-color: white; border: 3px dashed #6bb2b6;
	line-height:3em; text-align:center; color:#0F7693;

	/*shadow*/
	-webkit-box-shadow: 3px 6px 12px rgba(0,0,0,0.2);
	-moz-box-shadow: 3px 6px 12px rgba(0,0,0,0.2);
	box-shadow: 3px 6px 12px rgba(0,0,0,0.2);

	/*rounded corners*/
	-webkit-border-radius: 20px;
	-moz-border-radius: 20px;
	border-radius: 20px;
}
#sidebar { display:none; }
</style>


<?php 
// 메뉴 네비게이션
include_once('./nav.inc.php');
?>


<div class="hn">
	<h1>HN NIVO SLIDER Basic</h1>
</div>

<!-- hn_nivo_basic -->
<?php
include_once(G5_LIB_PATH.'/slider.lib.php');

// hn_nivo_basic slider
// 매개변수 : 스킨명, 게시판명, wr_id
echo slider("hn_nivo_basic", "media", 1);
?>


	
<?php
include_once(G5_PATH.'/tail.sub.php');
?>
