<?php
/* 
 * hn_swiper : $wr_id에 해당되는 게시물의 이미지 슬라이더
 *
 * Swiper - Mobile Touch Slider : http://idangero.us/swiper/
 * ---------------------------------------------------------------------------- 
 * include_once(G5_LIB_PATH.'/visual_latest.lib.php'); 
 * echo visual_latest("hn_swiper", "media", 2, 5, 5); 
 * // 매개변수 : 스킨명, 게시판, 게시물 wr_id, 이미지 수, 대기시간(초) 
 * ----------------------------------------------------------------------------
 */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가 

global $is_admin;

/*
echo "<pre>";
print_r($options);
echo "</pre>";
Array
(
    [num] => 5
    [pause_time] => 3
    [view_title] => 1
    [view_content] => 1
    [max-height] => 300
)
*/
// options
$nums = $options[num];
$pause_time = $options[pause_time];
$swiper_height = $options[height];

if ($options['view_title']) 
	$visual_title = $list['wr_subject'];

if ($options['view_content']) 
	$visual_content = nl2br(strip_tags($list['wr_content']));

// 상대경로 지정
$g5_relative_path = g5_relative_path();

// 파일 얻기
$list_file =  get_file($bo_table, $wr_id);

$visual_img_count = count($list_file);
$visual_img_idx = 0;

$img_tag_str = "";
$caption_str = "";
if(!$pause_time) {
	$pause_time=5;
} 
$pause_time *= 1000;

//출력할 이미지 개수 체크
if($visual_img_count > $nums) {
	$visual_img_count = $nums;
}

for ($i=0; $i<$visual_img_count; $i++) {			
	// 원본이미지
	// $visual_img_file = $list_file[$i][path].'/'.$list_file[$i][file]; // 절대경로	
	
	// 이미지 상대경로
	$visual_img_file = $g5_relative_path.'/'.G5_DATA_DIR.'/file/'.$bo_table.'/'.$list_file[$i][file];	
		 
	if(preg_match("/\.(jp[e]?g|gif|png)$/i", $visual_img_file) && is_file($visual_img_file)) {			
		$visual_img_idx++;
		
		$img_tag_str .= "	<li class=\"swiper-slide\">";
		// 이미지캡션
		if($list_file[$i][bf_content] && strlen($list_file[$i][bf_content]) > 2) {
			$list_href = $list_file[$i][bf_content];			
			//링크인지 확인
			if (preg_match('#^https?://#i', $list_href)) {				
				$img_tag_str .= "<a href=\"$list_href\"><img src=\"$visual_img_file\" alt=\"\" border=\"0\" /></a>";
			} else {
				$list_content = $list_file[$i][bf_content];
				$caption_str .= "<div id=\"imgcaption".$i."\" class=\"nivo-html-caption\">$list_content</div>";	
				$img_tag_str .= "<img src=\"$visual_img_file\" alt=\"\" border=\"0\" title=\"#imgcaption".$i."\" />";
			}			
		} else {
			$img_tag_str .= "<img src=\"$visual_img_file\" alt=\"\" border=\"0\" />";
		}
		$img_tag_str .= "</li>\n";
	}
	
}

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.$latest_skin_url.'/hn_swiper.css">', 0);
?>
<link href="<?php echo G5_URL?>/plugin/swiper/swiper.min.css" rel="stylesheet">
<style>
.swiper-slide { height:<?php echo $swiper_height; ?>px; }
.swiper-slide img { min-width: 100%; min-height: 100%; width: auto; height: auto; }
</style>

<div id="swiper-<?php echo $bo_table?>"  class="lt-swiper swiper-container">
	<?php if($is_admin) { ?>
	<div class="ltAdminBtn" style=" position:absolute; right:10px; top:5px; z-index:99;">
	<a href="<?php echo G5_BBS_URL?>/board.php?bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>" class="hnBtn small admin" >관리자</a>
	</div>
	<?php } ?>
<?php
if($img_tag_str) {
?>
	<ul class="swiper-wrapper">
		<?php echo $img_tag_str ?>
	</ul>
	
	<div class="swiper-pagination"></div>

	<div class="swiper-button-prev"></div>
	<div class="swiper-button-next"></div>
	
<?php } else { 	?>
	<div class="emptyMsg">
		<a href="<?php echo G5_BBS_URL?>/write.php?w=u&bo_table=<?php echo $bo_table?>&wr_id=2" class="infoText">슬라이더에 사용할 이미지를 넣어주세요.</a>
	</div>
<?php } ?>


	<div class="visual-text">
		<h1><?php echo $visual_title?></h1>
		<p class="text-multiline"><?php echo $visual_content?></p>
	</div>
	
	
</div><!-- / <?php echo  $board[bo_subject]?> 최신글 -->

<script src="<?php echo G5_URL?>/plugin/swiper/swiper.min.js"></script>
<script>
var mySwiper = new Swiper ('.swiper-container', {
    loop: true,
    pagination: {
      el: '.swiper-pagination',
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    }
});
</script>