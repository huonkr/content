<?php
include_once('./_common.php');
include_once(G5_PATH.'/_head.php');
?>



<!-- visual -->
<?php
// 모바일 메인 비주얼 이미지
include_once(G5_LIB_PATH.'/visual.lib.php');
// 옵션 - 출력이미지 수, 이미지 정지 시간(초)
$visual_options = array(
	'num' => 5, 
	'pause_time' => 3,	
	'view_title' => true,
	'view_content' => true,
	'height' => 300
);
// 매개변수("스킨명: hn_swiper", "게시판명: media", wr_id, 이미지 수, 대기시간(초)) 
// echo visual("hn_swiper", "media", 1, 3, 5); 
echo visual("hn_swiper", "media", 1, $visual_options); 
?>



	
<?php
include_once(G5_PATH.'/_tail.php');
?>
