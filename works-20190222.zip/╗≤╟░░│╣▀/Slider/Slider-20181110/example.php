<?php
include_once('./_common.php');
include_once(G5_PATH.'/_head.php');
?>
<style>
#sidebar { display:none; }
</style>



<!-- visual -->
<?php
include_once(G5_LIB_PATH.'/visual.lib.php');

// 옵션 - 출력이미지 수, 이미지 정지 시간(초), 제목과 내용 출력여부, 내용배경
$visual_options = array(
	'num' => 5, 
	'pause_time' => 3,	
	'view_title' => true,
	'view_content' => true,
	'content_bg' => "#555555"
);

// 메인이미지
// 매개변수 : 스킨명, 게시판명, wr_id, 옵션
if (defined('_INDEX_')) {	
	
// 서브이미지
} else if ($global_index) { 	
	$visual_options['max-height'] = 230;
	echo visual("hn_visual", "media", 3, $visual_options); 
}

	$visual_options['max-height'] = 550;
	echo visual("hn_visual", "media", 1, $visual_options); 
?>
	
	
<?php
include_once(G5_PATH.'/_tail.php');
?>
