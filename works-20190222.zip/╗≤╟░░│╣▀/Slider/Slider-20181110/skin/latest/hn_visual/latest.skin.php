<?php
/* 
 * hn_visual - nivo_slider
 * 니보슬라이더를 이용한 비주얼이미지 스킨
 *
 * [ 사용법 ] 
 * 최신글 매개변수(스킨명, 게시판명, $wr_id, 보여질 이미지 수, 옵션)
 * echo visual_latest("hn_nivo_slider", "main_visual", 1, 3, $options); 
 *
 * 게시판의 $wr_id에 해당되는 게시물에 이미지를 추가한 후 이 스킨을 적용합니다.
 *
 */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

global $is_admin;

// 옵션
$pause_time = $options['pause_time'];
$max_height = $options['max-height'];
/*
if ($options['view_title']) 
	$visual_title = $list['wr_subject'];

if ($options['view_content']) 
	$visual_content = nl2br(strip_tags($list['wr_content']));
*/
$list[file] = get_file($bo_table, $wr_id);		

$visual_img_count = $list[file]['count'];
$visual_img_idx = 0;

echo "<h1># $visual_img_count #</h1>";


$img_tag_str = "";
$caption_str = "";
if(!$pause_time) {
	$pause_time=5;
} 
$pause_time *= 1000;

//출력할 이미지 개수 체크
if($visual_img_count > $number) {
	$visual_img_count = $number;
}

for ($i=0; $i < $visual_img_count; $i++) {	
	$visual_img_file = $list[file][$i][path]."/".$list[file][$i][file]; // 원본 이미지
	
	// 업로드된 파일 이미지가 존재하면
	if (preg_match("/\.(jp[e]?g|gif|png)$/i", $visual_img_file)) {
		$visual_img_idx++;		
		
		// 이미지캡션
		if($list[file][$i][bf_content] && strlen($list[file][$i][bf_content]) > 2) {
			$list_href = $list[file][$i][bf_content];
			//링크인지 확인
			if (preg_match('#^https?://#i', $list_href)) {				
				$img_tag_str .= "	<a href=\"$list_href\"><img src=\"$visual_img_file\" alt=\"\" border=\"0\" /></a> \n";
			} else {
				$list_content = $list[file][$i][bf_content];
				$caption_str .= "<div id=\"imgcaption".$i."\" class=\"nivo-html-caption\">$list_content</div> \n";	
				$img_tag_str .= "	<img src=\"$visual_img_file\" alt=\"\" border=\"0\" title=\"#imgcaption".$i."\" /> \n";
			}			
		} else {
			$img_tag_str .= "	<img src=\"$visual_img_file\" alt=\"\" border=\"0\" /> \n";
		}
	}
}
?>

<div id="visual">
<?php
if($img_tag_str) {
?>
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/themes/default/default.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/themes/light/light.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/themes/dark/dark.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/themes/bar/bar.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/nivo-slider.css" type="text/css" media="screen" />
	<link href="<?php echo $latest_skin_url?>/hn_visual.css" rel="stylesheet" type="text/css">
	<?php if ($max_height) { ?>
	<style>
	.slider-wrapper { position:relative;}
	#slider.nivoSlider { overflow:hidden; max-height:<?php echo $max_height; ?>;}
	</style>
	<?php } ?>
	
	<div class="slider-wrapper theme-default">
	<?php 
	if($is_admin) { ?>
	<div class="ltAdminBtn" style=" position:absolute; right:10px; top:5px; z-index:10;">
	<a href="<?php echo G5_BBS_URL?>/board.php?bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>" class="hnBtn" >수정</a>
	</div>
	<?php } ?>

	<div id="slider" class="nivoSlider">
	<?php echo $img_tag_str ?>	
	</div>	
	<?php echo $caption_str ?>
	</div>

	<script type="text/javascript" src="<?php echo G5_URL?>/plugin/nivo/jquery.nivo.slider.js"></script>
	<script type="text/javascript">	
	$(window).load(function() {		
		$('#slider').nivoSlider({
			effect: 'random',               // Specify sets like: 'fold,fade,sliceDown'
			slices: 15,                     // For slice animations
			boxCols: 8,                     // For box animations
			boxRows: 4,                     // For box animations
			animSpeed: 500,                 // Slide transition speed
			pauseTime: <?php echo $pause_time?>,    // How long each slide will show
			startSlide: 0,                  // Set starting Slide (0 index)
			directionNav: true,             // Next & Prev navigation
			controlNav: true,               // 1,2,3... navigation
			controlNavThumbs: false,        // Use thumbnails for Control Nav
			pauseOnHover: true,             // Stop animation while hovering
			manualAdvance: false,           // Force manual transitions
			prevText: 'Prev',               // Prev directionNav text
			nextText: 'Next',               // Next directionNav text
			randomStart: false,             // Start on a random slide
			beforeChange: function(){},     // Triggers before a slide transition
			afterChange: function(){},      // Triggers after a slide transition
			slideshowEnd: function(){},     // Triggers after all slides have been shown
			lastSlide: function(){},        // Triggers when last slide is shown
			afterLoad: function(){}         // Triggers when slider has loaded
		});
		
		$('#slider img').click(function() {
			var href = $(this).attr("alt");		
			if (href && (href.indexOf("http://") !== 0)) { 
				href = "http://" + href;
				location.href = href;
			} else	if(href) {
				location.href = href;
			}
		});
		
		/*
		var slider_height = $('.slider-wrapper').parent().height();
		$('.nivoSlider').height(slider_height);		
		*/
	});
	</script>
<?php } else { ?>	
	<div class="lt_hnNivoSlider">
	<a href="<?php echo G5_BBS_URL?>/write.php?w=u&bo_table=<?php echo $bo_table?>&wr_id=1" class="infoText">비주얼 슬라이드에 사용할 이미지를 넣어주세요.</a>
	</div>
<?php } ?>

</div>