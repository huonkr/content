<?php
/* 
 * hn_nivo : $wr_id에 해당되는 게시물의 이미지 슬라이더
 * 니보슬라이더(nivo_slider)를 이용한 비주얼이미지 스킨
 *
 * [ 사용법 ] 
 * include_once(G5_LIB_PATH.'/slider.lib.php');
 *  // 슬라이더 옵션
 * $slider_options = array(
 * 	'height' 		=> 900, // 슬라이더 높이
 * 	'num' 			=> 5, // 이미지수
 * 	'pause_time' 	=> 3, // 슬라이드 멈춤 시간(초)	
 * 	'is_title' 		=> true, // 타이틀 출력 여부
 * 	'is_content' 	=> true, // 내용 출력 여부
 * 	'text_top' 		=> "30%", // 텍스트 상단포지션 : 0%, 0px
 * 	'text_align' 	=> "center", // 텍스트정렬 : left, center, right		
 * 	'title_color' 	=> "white", // 제목 색상
 * 	'content_color' => "white", // 내용 텍스트 색상
 * 	'content_bgcolor' => "rgba(0,0,0,0.2)" // 내용 배경 색상 : HTML색상표, 색상명, rgba()
 * 	'content_bgcolor' => "black"
 * );
 * // 매개변수 : 스킨명, 게시판명, wr_id, 옵션
 * echo slider("hn_nivo", $bo_table, $wr_id, $slider_options);
 *
 */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

// 옵션 변수화
extract($options);

if ($is_title) {
	$wr_subject = $list['wr_subject'];
}

if ($is_content) {
	$wr_content = nl2br(strip_tags($list['wr_content']));
}

$img_idx = 0;
$img_count = count($list[file]);
$img_tag = "";
$caption_str = "";

if(!$pause_time) {
	$pause_time=5;
} 
$pause_time *= 1000;

//출력할 이미지 개수 체크
if($img_count > $num) {
	$img_count = $num;
}

for ($i=0; $i<$img_count; $i++) {	
	$img_file = $list[file][$i][path]."/".$list[file][$i][file]; // 원본 이미지
	
	// 업로드된 파일 이미지가 존재하면
	if (preg_match("/\.(jp[e]?g|gif|png)$/i", $img_file)) {
		$img_idx++;		
		
		// 이미지캡션
		if($list[file][$i][bf_content] && strlen($list[file][$i][bf_content]) > 2) {
			$list_href = $list[file][$i][bf_content];
			//링크 체크
			if (preg_match('#^https?://#i', $list_href)) {				
				$img_tag .= "	<a href=\"$list_href\"><img src=\"$img_file\" alt=\"\" border=\"0\" /></a> \n";
			} else {
				$list_content = $list[file][$i][bf_content];
				$caption_str .= "<div id=\"imgcaption".$i."\" class=\"nivo-html-caption\">$list_content</div> \n";	
				$img_tag .= "	<img src=\"$img_file\" alt=\"\" border=\"0\" title=\"#imgcaption".$i."\" /> \n";
			}			
		} else {
			$img_tag .= "	<img src=\"$img_file\" alt=\"\" border=\"0\" /> \n";
		}
	}
}
?>
<link href="<?php echo $slider_skin_url?>/hn_nivo.css" rel="stylesheet" type="text/css">	
<style>	
<?php if ($height) { ?>
#nivoSlider { max-height:<?php echo $height; ?>px; }
@media screen and (max-width:1024px) { 
	#nivoSlider { max-height:auto; } 
}
#nivoSlider #slider { max-height:<?php echo $height; ?>px;}
<?php } ?>	
#nivoSlider .visual-text { <?php if ($text_top) { ?>top:<?php echo $text_top; ?>;<?php } ?><?php if ($text_align) { ?>text-align:<?php echo $text_align; ?>;<?php } ?> }	
#nivoSlider .visual-text h1 { <?php if ($title_color) { ?>color:<?php echo $title_color; ?>; <?php } ?> }
#nivoSlider .visual-text p { <?php if ($content_bgcolor) { ?>background-color:<?php echo $content_bgcolor; ?>; outline-color:<?php echo $content_bgcolor; ?>;<?php } ?> <?php if ($content_color) { ?>color:<?php echo $content_color; ?>;<?php } ?> <?php if ($text_align) { ?>text-align:<?php echo $text_align; ?>;<?php } ?> }
</style>
<div id="nivoSlider">
<?php
if($img_tag) {
?>
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/themes/default/default.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/themes/light/light.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/themes/dark/dark.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/themes/bar/bar.css" type="text/css" media="screen" />	
	<link rel="stylesheet" href="<?php echo G5_URL?>/plugin/nivo/nivo-slider.css" type="text/css" media="screen" />	

	<div class="slider-wrapper theme-default">
	<?php 
	if($is_admin) { ?>
	<div class="admin-btn">
	<a href="<?php echo G5_BBS_URL?>/board.php?bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>" class="hnBtn" >수정</a>
	</div>
	<?php } ?>

	<div id="slider">
	<?php echo $img_tag ?>	
	</div>	
	<?php echo $caption_str ?>
	
	<div class="visual-text">
		<h1><?php echo $wr_subject?></h1>
		<?php if ($wr_content) { echo "<p>{$wr_content}</p>"; } ?>
	</div>
	</div>	

	<script type="text/javascript" src="<?php echo G5_URL?>/plugin/nivo/jquery.nivo.slider.js"></script>
	<script type="text/javascript">	
	$(window).load(function() {		
		$('#slider').nivoSlider({
			effect: 'random',               // Specify sets like: 'fold,fade,sliceDown'
			slices: 15,                     // For slice animations
			boxCols: 8,                     // For box animations
			boxRows: 4,                     // For box animations
			animSpeed: 500,                 // Slide transition speed
			pauseTime: <?php echo $pause_time?>,    // How long each slide will show
			startSlide: 0,                  // Set starting Slide (0 index)
			directionNav: true,             // Next & Prev navigation
			controlNav: true,               // 1,2,3... navigation
			controlNavThumbs: false,        // Use thumbnails for Control Nav
			pauseOnHover: true,             // Stop animation while hovering
			manualAdvance: false,           // Force manual transitions
			prevText: 'Prev',               // Prev directionNav text
			nextText: 'Next',               // Next directionNav text
			randomStart: false,             // Start on a random slide
			beforeChange: function(){},     // Triggers before a slide transition
			afterChange: function(){},      // Triggers after a slide transition
			slideshowEnd: function(){},     // Triggers after all slides have been shown
			lastSlide: function(){},        // Triggers when last slide is shown
			afterLoad: function(){}         // Triggers when slider has loaded
		});
	});
	</script>
<?php } else { ?>	
	<div class="empty-msg">
	<a href="<?php echo G5_BBS_URL?>/write.php?w=u&bo_table=<?php echo $bo_table?>&wr_id=1" class="info-text">메인비주얼에 사용할 이미지를 넣어주세요.</a>
	</div>
<?php } ?>

</div>
<script>
$(function() {	
	$("#nivoSlider img").one("load", function() {
		$('#nivoSlider .slider-wrapper').addClass('active');
		$('#nivoSlider .visual-text').addClass('active');
	}).each(function() {
		if(this.complete) $(this).load();
	});	
}) ;
</script>