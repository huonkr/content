<?php
/* 
 * hn_slider : $wr_id에 해당되는 게시물의 이미지 슬라이더
 * 
 * jQuery Plugin : Swiper - Mobile Touch Slider : http://idangero.us/swiper/
 *
 * 사용법 
 * ---------------------------------------------------------------------------- 
 * include_once(G5_LIB_PATH.'/slider.lib.php');
 * // 슬라이더 옵션
 * $slider_options = array(
 * 	'height' 		=> 350, // 슬라이더 높이
 * 	'num' 			=> 5, // 이미지수
 * 	'pause_time' 	=> 3, // 슬라이드 멈춤 시간(초)	
 * 	'view_title' 	=> true, // 타이틀 출력 여부
 * 	'view_content' 	=> true, // 내용 출력 여부
 * 	'top' 			=> "20%", // 텍스트 상단포지션 : 0%, 0px
 * 	'align' 		=> "center", // 텍스트정렬 : left, center, right		
 * 	'title_color' 	=> "#ffffff", // 제목 색상(기본 white)
 * 	'content_bgcolor' => "rgba(0,0,0,0.3)", // 내용 배경 색상 : HTML색상표, 색상명, 투명도
 * 	'content_color' => "#ffffff" // 내용 텍스트 색상(기본 white)
 * );
 * // 매개변수 : 스킨명, 게시판명, wr_id, 옵션
 * echo slider("hn_swiper", $bo_table, $wr_id, $slider_options); 
 * ----------------------------------------------------------------------------
 */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가 

// 옵션 변수화
extract($options);

if ($is_title) {
	$wr_subject = $list['wr_subject'];
}

if ($is_content) {
	$wr_content = nl2br(strip_tags($list['wr_content']));
}

$img_idx = 0;
$img_count = count($list[file]);
$img_tag = "";

if(!$pause_time) {
	$pause_time=5;
} 
$pause_time *= 1000;

//출력할 이미지 개수 체크
if($img_count > $num) {
	$img_count = $num;
}

for ($i=0; $i<$img_count; $i++) {	
	$img_file = $list[file][$i][path]."/".$list[file][$i][file]; // 원본 이미지
		 
	if(preg_match("/\.(jp[e]?g|gif|png)$/i", $img_file)) {			
		$img_idx++;		
		$img_tag .= "	<li class=\"swiper-slide\">";
		
		// 이미지캡션
		if($list[file][$i][bf_content] && strlen($list[file][$i][bf_content]) > 2) {
			$list_href = $list[file][$i][bf_content];			
			//링크 체크
			if (preg_match('#^https?://#i', $list_href)) {				
				$img_tag .= "<a href=\"$list_href\"><img src=\"$img_file\" alt=\"\" border=\"0\" /></a>";
			} else {
				if ($is_caption) {
					$list_content = $list[file][$i][bf_content];
					$img_tag .= "<div class=\"img-caption\">$list_content</div>";	
				}
				$img_tag .= "<img src=\"$img_file\" alt=\"\" border=\"0\" title=\"#imgcaption".$i."\" />";
			}			
		} else {
			$img_tag .= "<img src=\"$img_file\" alt=\"\" border=\"0\" />";
		}
		$img_tag .= "</li>\n";
	}	
}
?>
<link href="<?php echo $slider_skin_url?>/hn_slider.css" rel="stylesheet" >
<link href="<?php echo G5_URL?>/plugin/swiper/swiper.min.css" rel="stylesheet">
<style>
.swiper-slide img { max-height: <?php echo $height; ?>px; }
@media screen and (max-width:1024px) {
	.swiper-slide img { width:100%; max-height:auto; }
}
#swiperSlider .slider-text { <?php if ($top) { ?>top:<?php echo $top; ?>;<?php } ?><?php if ($align) { ?>text-align:<?php echo $align; ?>;<?php } ?> }	
#swiperSlider .slider-text h1 { <?php if ($title_color) { ?>color:<?php echo $title_color; ?>; text-shadow:none; <?php } ?> }
#swiperSlider .slider-text p { <?php if ($content_bgcolor) { ?>background-color:<?php echo $content_bgcolor; ?>; outline-color:<?php echo $content_bgcolor; ?>;<?php } ?> <?php if ($content_color) { ?>color:<?php echo $content_color; ?>;<?php } ?> <?php if ($align) { ?>text-align:<?php echo $align; ?>;<?php } ?> }	
.swiper-button-prev {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTEuNDMzIDE1Ljk5MkwyMi42OSA1LjcxMmMuMzkzLS4zOS4zOTMtMS4wMyAwLTEuNDItLjM5My0uMzktMS4wMy0uMzktMS40MjMgMGwtMTEuOTggMTAuOTRjLS4yMS4yMS0uMy40OS0uMjg1Ljc2LS4wMTUuMjguMDc1LjU2LjI4NC43N2wxMS45OCAxMC45NGMuMzkzLjM5IDEuMDMuMzkgMS40MjQgMCAuMzkzLS40LjM5My0xLjAzIDAtMS40MmwtMTEuMjU3LTEwLjI5IiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIxIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=);    
}
.swiper-button-next {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTAuNzIyIDQuMjkzYy0uMzk0LS4zOS0xLjAzMi0uMzktMS40MjcgMC0uMzkzLjM5LS4zOTMgMS4wMyAwIDEuNDJsMTEuMjgzIDEwLjI4LTExLjI4MyAxMC4yOWMtLjM5My4zOS0uMzkzIDEuMDIgMCAxLjQyLjM5NS4zOSAxLjAzMy4zOSAxLjQyNyAwbDEyLjAwNy0xMC45NGMuMjEtLjIxLjMtLjQ5LjI4NC0uNzcuMDE0LS4yNy0uMDc2LS41NS0uMjg2LS43NkwxMC43MiA0LjI5M3oiIGZpbGw9IiNmZmZmZmYiIG9wYWNpdHk9IjEiIGZpbGwtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==);    
}
</style>

<div id="swiperSlider"  class="swiper-slider">
	<?php if($is_admin) { ?>
	<div class="admin-btn">
	<a href="<?php echo G5_BBS_URL?>/board.php?bo_table=<?php echo $bo_table?>&wr_id=<?php echo $wr_id?>" class="hnBtn small admin" >수정</a>
	</div>
	<?php } ?>
<?php
if($img_tag) {
?>
	<ul class="swiper-wrapper">
		<?php echo $img_tag ?>
	</ul>	
	<div class="swiper-pagination"></div>
	<div class="swiper-button-prev"></div>
	<div class="swiper-button-next"></div>
	
<?php } else { 	?>
	<div class="empty-msg">
		<a href="<?php echo G5_BBS_URL?>/write.php?w=u&bo_table=<?php echo $bo_table?>&wr_id=2" class="infoText">슬라이더에 사용할 이미지를 넣어주세요.</a>
	</div>
<?php } ?>

	<div class="slider-text">
		<h1><?php echo $wr_subject?></h1>
		<?php if ($wr_content) { echo "<p>{$wr_content}</p>"; } ?>
	</div>
</div>

<script src="<?php echo G5_URL?>/plugin/swiper/swiper.min.js"></script>
<script>
var mySwiper = new Swiper ('.swiper-slider', {
    loop: true,
    pagination: {
      el: '.swiper-pagination',
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    }
});


$(function() {	
	$(".swiper-slide img").one("load", function() {
		$('.swiper-slide img').addClass('active');
		$('#swiperSlider .slider-text').addClass('active');
	}).each(function() {
		if(this.complete) $(this).load();
	});	
}) ;
</script>