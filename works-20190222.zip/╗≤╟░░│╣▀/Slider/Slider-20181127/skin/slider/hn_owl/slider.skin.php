<?php
/* 
 * hn_owl
 * 
 * OWL Carousel : https://owlcarousel2.github.io/OwlCarousel2/
 * ----------------------------------------------------------------------------
 * include_once(G5_LIB_PATH.'/slider.lib.php');
 * // hn_owl slider
 * // 매개변수 : 스킨명, 게시판명, wr_id
 * echo slider("hn_owl", $bo_table, $wr_id); 
 * ----------------------------------------------------------------------------
 */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가 

// 옵션 변수화
extract($options);

if ($is_title) {
	$wr_subject = $list['wr_subject'];
}

if ($is_content) {
	$wr_content = nl2br(strip_tags($list['wr_content']));
}

$img_idx = 0;
$img_count = count($list[file]);
$img_tag = "";

//출력할 이미지 개수 체크
if($img_count > $num) {
	$img_count = $num;
}
?>
<link rel="stylesheet" href="<?php echo $slider_skin_url?>/hn_owl.css">
<link href="<?php echo G5_URL?>/plugin/owl/owl.carousel.min.css" rel="stylesheet">
<link href="<?php echo G5_URL?>/plugin/owl/owl.theme.default.min.css" rel="stylesheet">
<style>
.owl-carousel .item img { height: <?php echo $height; ?>px; }
@media screen and (max-width:1024px) {
	.owl-carousel .item img { width:100%; height:auto; }
}
#owlSlider .slider-text { <?php if ($top) { ?>top:<?php echo $top; ?>;<?php } ?><?php if ($align) { ?>text-align:<?php echo $align; ?>;<?php } ?> }	
#owlSlider .slider-text h1 { <?php if ($title_color) { ?>color:<?php echo $title_color; ?>; text-shadow:none; <?php } ?> }
#owlSlider .slider-text p { <?php if ($content_bgcolor) { ?>background-color:<?php echo $content_bgcolor; ?>; outline-color:<?php echo $content_bgcolor; ?>;<?php } ?> <?php if ($content_color) { ?>color:<?php echo $content_color; ?>;<?php } ?> <?php if ($align) { ?>text-align:<?php echo $align; ?>;<?php } ?> }	
</style>

<div id="owlSlider"> 
<div class="owl-carousel">
<?php
for ($i=0; $i<$img_count; $i++) {	
	$img_file = $list[file][$i][path]."/".$list[file][$i][file]; // 원본 이미지
	
	// 업로드된 파일 이미지가 존재하면
	if (preg_match("/\.(jp[e]?g|gif|png)$/i", $img_file)) {
		$img_tag = "";
		$img_idx++;		
		
		// 이미지캡션
		if($list[file][$i][bf_content] && strlen($list[file][$i][bf_content]) > 2) {
			$list_href = $list[file][$i][bf_content];
			//링크 체크
			if (preg_match('#^https?://#i', $list_href)) {				
				$img_tag .= "	<a href=\"$list_href\"><img src=\"$img_file\" alt=\"\" border=\"0\" /></a> \n";
			} else {
				if ($is_caption) {
					$list_content = $list[file][$i][bf_content];
					$img_tag .= "<div class=\"img-caption\">$list_content</div>";	
				}
				$img_tag .= "	<img src=\"$img_file\" alt=\"\" border=\"0\" title=\"#imgcaption".$i."\" /> \n";				
			}			
		} else {
			$img_tag .= "	<img src=\"$img_file\" alt=\"\" border=\"0\" /> \n";
		}
?>		
	<div class="item" rel="<?php echo $i?>">
		<?php echo $img_tag?>		
	</div>	
<?php		
	}
}
if (count($list) == 0) { ?><div class="empty-msg"><a href="<?php echo G5_BBS_URL?>/write.php?bo_table=<?php echo $bo_table; ?>"><?=$bo_table?> 게시물이 없습니다.</a></div><?php } 
?>
</div>

<div class="slider-text">
	<h1><?php echo $wr_subject?></h1>
	<?php if ($wr_content) { echo "<p>{$wr_content}</p>"; } ?>
</div>
</div>

<script src="<?php echo G5_URL?>/plugin/owl/owl.carousel.js"></script>
<script>
$(function() {
	$(".owl-carousel").owlCarousel({  
		loop:true,
		margin:10,
		items: 1,
		navigation : false,
		dots : false,
		slideSpeed : 300,
		paginationSpeed : 400,
		autoHeight : true,
		singleItem : true
	});
  
	$(".owl-carousel img").one("load", function() {
		$('#owlSlider .slider-text').addClass('active');
	}).each(function() {
		if(this.complete) $(this).load();
	});	  
});
</script>

