<?php
include_once('./_common.php');
include_once(G5_PATH.'/head.sub.php');
?>
<style>
#sidebar { display:none; }
</style>

<!-- hn_nivo_basic -->
<?php
/* 
include_once(G5_LIB_PATH.'/slider.lib.php');

// hn_nivo_basic slider
// 매개변수 : 스킨명, 게시판명, wr_id
echo slider("hn_nivo_basic", "media", 1);
*/
?>

<!-- hn_owl_basic -->
<?php
/*
include_once(G5_LIB_PATH.'/slider.lib.php');
 
// hn_owl slider
// 매개변수 : 스킨명, 게시판명, wr_id
echo slider("hn_owl_basic", "media", 1);
*/
?>


<!-- hn_swiper_basic --> 
<?php
/* 
include_once(G5_LIB_PATH.'/slider.lib.php');

// hn_swiper_basic
// 매개변수 : 스킨명, 게시판명, wr_id
echo slider("hn_swiper_basic", "media", 1); 
*/
?>


<!-- hn_nivo -->
<?php
/* */
include_once(G5_LIB_PATH.'/slider.lib.php');

// hn_nivo slider
$slider_options = array(
	'height' 		=> 550, // 슬라이더 높이
	'num' 			=> 5, // 이미지수
	'pause_time' 	=> 3, // 슬라이드 멈춤 시간(초)	
	'is_title' 		=> true, // 타이틀 출력 여부
	'is_content' 	=> true, // 내용 출력 여부
	'text_top' 		=> "25%", // 텍스트 상단포지션 : 0%, 0px
	'text_align' 	=> "center", // 텍스트정렬 : left, center, right		
	'title_color' 	=> "white", // 제목 색상
	'content_color' => "white", // 내용 텍스트 색상
	'content_bgcolor' => "rgba(0,0,0,0.2)" // 내용 배경 색상 : HTML색상표, 색상명, rgba()	
);
// 매개변수 : 스킨명, 게시판명, wr_id, 옵션
echo slider("hn_nivo", "media", 1, $slider_options);

?>



<!-- hn_owl -->
<?php
/*  
include_once(G5_LIB_PATH.'/slider.lib.php');
*/
// hn_owl slider
$slider_options = array(
	'height' 		=> 650, // 슬라이더 높이
	'num' 			=> 5, // 이미지수
	'is_title' 	=> true, // 타이틀 출력 여부
	'is_content' 	=> true, // 내용 출력 여부
	'is_caption' 	=> true, // 이미지 캡션 출력 여부
	'top' 			=> "25%", // 텍스트 상단포지션 : 0%, 0px
	'align' 		=> "center", // 텍스트정렬 : left, center, right		
	'title_color' 	=> "#ffffff", // 제목 색상(기본 white)
	'content_color' => "#ffffff", // 내용 텍스트 색상(기본 white)
	'content_bgcolor' => "rgba(0,0,0,0.3)" // 내용 배경 색상 : HTML색상표, 색상명, 투명도
);
// 매개변수 : 스킨명, 게시판명, wr_id, 옵션
echo slider("hn_owl", "media", 1, $slider_options);

?>
 
 


<!-- hn_swiper -->
<?php
/* 
include_once(G5_LIB_PATH.'/slider.lib.php');
*/
// hn_swiper
$slider_options = array(
	'height' 		=> 550, // 슬라이더 높이
	'num' 			=> 5, // 이미지수
	'pause_time' 	=> 3, // 슬라이드 멈춤 시간(초)	
	'is_title' 	=> true, // 타이틀 출력 여부
	'is_content' 	=> true, // 내용 출력 여부
	'is_caption' 	=> true, // 이미지 캡션 출력 여부
	'top' 			=> "25%", // 텍스트 상단포지션 : 0%, 0px
	'align' 		=> "center", // 텍스트정렬 : left, center, right		
	'title_color' 	=> "#ffffff", // 제목 색상(기본 white)
	'content_color' => "#ffffff", // 내용 텍스트 색상(기본 white)
	'content_bgcolor' => "rgba(0,0,0,0.3)" // 내용 배경 색상 : HTML색상표, 색상명, 투명도
);
// 매개변수 : 스킨명, 게시판명, wr_id, 옵션
echo slider("hn_swiper", "media", 1, $slider_options); 

?>

 

	
<?php
include_once(G5_PATH.'/tail.sub.php');
?>
