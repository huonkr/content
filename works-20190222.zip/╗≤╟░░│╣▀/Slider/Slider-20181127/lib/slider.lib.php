<?php
if (!defined('_GNUBOARD_')) exit;

// 게시물 파일에서 비주얼 이미지 추출
function slider($skin_dir="hn_nivo", $bo_table, $wr_id=1, $options=array())
{	
    global $g5, $is_admin;
		
	if(preg_match('#^theme/(.+)$#', $skin_dir, $match)) {
        $skin_dir = $match[1];
		if (G5_IS_MOBILE) {
            $slider_skin_path = G5_THEME_MOBILE_PATH.'/'.G5_SKIN_DIR.'/slider/'.$skin_dir;
            if(!is_dir($slider_skin_path))
                $slider_skin_path = G5_THEME_PATH.'/'.G5_SKIN_DIR.'/slider/'.$skin_dir;
            $slider_skin_url = str_replace(G5_PATH, G5_URL, $slider_skin_path);
        } else {
            $slider_skin_path = G5_THEME_PATH.'/'.G5_SKIN_DIR.'/slider/'.$skin_dir;
            $slider_skin_url = str_replace(G5_PATH, G5_URL, $slider_skin_path);
        }        
    } else {
        if(G5_IS_MOBILE) {
			$slider_skin_path = G5_MOBILE_PATH.'/'.G5_SKIN_DIR.'/slider/'.$skin_dir;
			$slider_skin_url  = G5_MOBILE_URL.'/'.G5_SKIN_DIR.'/slider/'.$skin_dir;
		} else {
			$slider_skin_path = G5_SKIN_PATH.'/slider/'.$skin_dir;
			$slider_skin_url  = G5_SKIN_URL.'/slider/'.$skin_dir;
		}
    }
	
	$list = array();

	$sql = " select * from {$g5['board_table']} where bo_table = '{$bo_table}' ";
	$board = sql_fetch($sql);
	$bo_subject = get_text($board['bo_subject']);
	
	if($board['bo_table'] != $bo_table) {
		return "<div style='margin:1em 0; padding:3em 1em; text_align:center; font-size:.8rem; '>&lt;!&gt; <strong>$bo_table</strong> 게시판이 존재하지 않습니다.</div>";	
	}				

	$tmp_write_table = $g5['write_prefix'].$bo_table; // 게시판 테이블 전체이름	
	$sql = " select * from {$tmp_write_table} where wr_id='$wr_id' ";
	$row = sql_fetch($sql);		
	$list = get_list($row, $board, $slider_skin_path);
	$list[file] = get_file($bo_table, $wr_id);
	
    ob_start();
    include $slider_skin_path.'/slider.skin.php';
    $content = ob_get_contents();
    ob_end_clean();

    return $content;
}
?>
