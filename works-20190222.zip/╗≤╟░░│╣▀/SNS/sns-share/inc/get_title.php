<?php 
// 페이지 제목 설정
if (!defined("_GNUBOARD_")) exit;

// 제목 설정
// index 페이지거나 게시물 보기일때 제목을 출력하지 않음
if(!$page_title && !defined("_INDEX_") && (!$wr_id || $w=="u")) {	
	// 메뉴명	
	if($local_index) {
		$global_key = $globalmenu[$global_index-1][0];
		$local_key = $localmenu[$global_key][$local_index-1][0];
		
		if($page_index) {
			$page_title = $pagemenu[$global_key][$local_key][$local_index-1][0];
		} else {
			$page_title = $local_key;
		}	
	// 콘텐츠		
	} else if($co_id) {
		$page_title = strip_tags($co['co_subject']);
	// 게시물
	} else if($wr_id) {
		$page_title = strip_tags($write['wr_subject']);
	// 게시판
	} else if($bo_table) {
		$page_title = $board['bo_subject'];	
	} 
}
  
// 상태바에 표시될 제목 설정
if($page_title && $page_title != $config['cf_title'] ) {
    $g5_head_title = $page_title." | ".$config['cf_title'];
} else if($g5['title']) {
    $g5_head_title = $g5['title']." | ".$config['cf_title'];
} else if(!isset($g5['title'])) {
	$g5['title'] = $config['cf_title'];
	$g5_head_title = $g5['title'];    
}
?>
