<?php
// 페이지 내용 안내
if (!defined("_GNUBOARD_")) exit;

// page description
if(!$page_description) {
	// 콘텐츠
	if($co_id) {
		$page_description = get_text(strip_tags($co['co_content']));
	// 게시물
	} else if($wr_id) {		
		$page_description = get_text(strip_tags($write['wr_content']));			
	// 게시판
	} else if($bo_table) {
		$page_description = $board['bo_subject'];
	// 페이지 제목
	} else {
		$page_description = $page_title;
	}
	$page_description = preg_replace('/\s+/', ' ', trim($page_description));
	$page_description = mb_strimwidth($page_description, 0, 300, "...", "utf-8");
	$page_description = preg_replace("/\"/", "&quot;", $page_description);	
} 
?>