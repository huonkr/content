<?php
// SNS 공유 링크 설정 
// ----------------------------------------------------------------------------
// 웹사이트 제목, url, 대표이미지, 소개글
$sns_title = $config['cf_title']; 
$sns_url = G5_URL."/index.php"; 
$sns_image = G5_URL."/images/sns-share.jpg";
$sns_description = "웹사이트 소개글";
	
// 모바일 카카오 링크 설정
if(G5_IS_MOBILE) {
	// 카카오 Javascript API Key	
	// API Key는 [관리자 > 환경설정 > SNS]에서 설정하거나 직접 입력할 수 있습니다.
	// API Key 등록: 카카오 디벨로퍼스 - https://developers.kakao.com/
	$kakao_app_key = ($config['cf_kakao_js_apikey']) ? $config['cf_kakao_js_apikey'] : "카카오 Javascript API Key";	
	
	// 카톡 메세지
	$kakao_message = $sns_title; 
	// 대표이미지
	$kakao_image = $sns_image; // 메세지와 함께 넣을 이미지 경로
	$kakao_image_width = 300;
	$kakao_image_height = 200;
	// 버튼
	$kakao_btn_text = $sns_title; // 카톡 앱 버튼 텍스트
	$kakao_btn_url = $sns_url; // 카카오 디벨로퍼스 앱 설정의 웹 플랫폼에 등록한 도메인을 포함하는 URL이어야 합니다.		
} 

// og meta tag
// index og meta
if (defined('_INDEX_')) {	
	$og_meta_tag = "<meta property=\"og:title\" content=\"{$sns_title}\" />".PHP_EOL;
	$og_meta_tag .= "<meta property=\"og:url\" content=\"{$sns_url}\" />".PHP_EOL;
	$og_meta_tag .= "<meta property=\"og:image\" content=\"{$sns_image}\" />".PHP_EOL;
	$og_meta_tag .= "<meta property=\"og:description\" content=\"{$sns_description}\" />".PHP_EOL;
	$og_meta_tag .= "<meta property=\"og:type\" content=\"website\" />".PHP_EOL;
	
// 콘텐츠 페이지의 URL과 제목, 요약글 얻기	
} else {	
	// 페이지 제목과 설명
	$sns_page_title = $sns_title;
	$sns_page_description = $sns_description;
	$sns_page_url = $sns_url;
	
	// HTML Page
	if($page_title && $page_description) {
		$sns_page_title = $page_title;	
		$sns_page_description = cut_str($page_description, 240, "...");

	// 콘텐츠
	} else if($co_id) {
		$sns_page_title = $co['co_subject'];
		$sns_page_description = cut_str(get_text(strip_tags($co['co_content'])), 240, "...");

	// 게시물
	} else if($wr_id) {		
		$sns_page_title = $write['wr_subject'];
		$sns_page_description = cut_str(get_text(strip_tags($write['wr_content'])), 240, "...");	
		
	// 게시판
	} else if($bo_table) {
		$sns_page_title = $board['bo_subject'];
		$sns_page_description = $board['bo_subject'];
	}
	
	// 공유할 URL
	$sns_page_url = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; 
	if(strpos($sns_page_url, "&page=") !== false) {
		$sns_page_url = substr($sns_page_url, 0, strpos($sns_page_url, "&page="));
	}
	
	// 내용페이지의 og meta tag	
	$og_meta_tag = "<meta property=\"og:site_name\" content=\"{$config['cf_title']}\" />".PHP_EOL;
	$og_meta_tag .= "<meta property=\"og:title\" content=\"{$sns_page_title}\" />".PHP_EOL;
	$og_meta_tag .= "<meta property=\"og:url\" content=\"{$sns_page_url}\" />".PHP_EOL;
	$og_meta_tag .= "<meta property=\"og:image\" content=\"{$sns_image}\" />".PHP_EOL;
	$og_meta_tag .= "<meta property=\"og:description\" content=\"{$sns_page_description}\" />".PHP_EOL;	
	$og_meta_tag .= "<meta property=\"og:type\" content=\"website\" />".PHP_EOL;
}

$org_page_url = $sns_page_url;
// url encode
$sns_url = urlencode($sns_url);
$sns_page_url = urlencode($sns_page_url);
?>
