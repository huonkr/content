<?php
// 내용페이지용 SNS 공유 버튼
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

// 페이스북 공유에서 수정 내용이 갱신되지 않으면 디버깅 해 주세요.
// 공유 디버그 : https://developers.facebook.com/tools/debug/
// 페이스북 디버거 : https://developers.facebook.com/tools/debug/og/object/

// 공유 버튼 스타일시트
if (G5_IS_MOBILE) {
?>
<link href="<?php echo G5_CSS_URL; ?>/sns/sns_share_mobile.css" rel="stylesheet" type="text/css">
<?php } else { ?>
<link href="<?php echo G5_CSS_URL; ?>/sns/sns_share.css" rel="stylesheet" type="text/css">
<?php } ?>

<div id="snsBtn">
<ul>
	<li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $sns_page_url; ?>&amp;t=<?php echo $sns_page_title;?>" target="_blank" title="Share This on Facebook" onClick="return snsWin(this.href, 750, 690)" class="facebook"><i class="fa fa-facebook fa-lg" aria-hidden="true"></i></a></li>	
	
	<li><a href="https://twitter.com/intent/tweet?url=<?php echo $sns_page_url; ?>&amp;text=[<?php echo $config['cf_title']; ?>]<?php echo $sns_page_title." - ".cut_str($sns_page_description, 60); ?>" target="_blank" title="Share This on Twitter" onClick="return snsWin(this.href, 750, 320)" class="twitter"><i class="fa fa-twitter fa-lg" aria-hidden="true"></i></a></li>
	
	<li><a href="https://plus.google.com/share?url=<?php echo $sns_page_url; ?>" target="_blank" title="Share This on Google" onClick="return snsWin(this.href, 420, 520)" class="google"><i class="fa fa-google-plus fa-lg" aria-hidden="true"></i></a></li>
	
	<?php if(G5_IS_MOBILE && $config['cf_kakao_js_apikey']) { ; ?>   
	<li><a href="#" title="Share This on Kakao" target="_blank" class="kakaotalk"><i class="fa fa-comment fa-lg" aria-hidden="true"></i></a></li>
	<?php } ; ?>	
	
	<li><a href="http://blog.naver.com/openapi/share?url=<?php echo $sns_page_url; ?>&title=<?php echo $sns_page_title;?>" target="_blank" title="Share This on Naver Blog" onClick="return snsWin(this.href, 600, 400)" class="naverblog"><i class="fa fa-comment-o" aria-hidden="true"></i></a></li>	
	
	<li><a href="https://story.kakao.com/share?url=<?php echo $sns_page_url; ?>" target="_blank" title="Share This on KakaoStory" onClick="return snsWin(this.href, 600, 400)" class="kakaostory"><i class="fa fa-quote-right" aria-hidden="true"></i></a></li>
	
	<li><a href="http://band.us/plugin/share?body=<?php echo $sns_page_title."%0D%0A".cut_str($sns_page_description, 60);?>%0D%0A<?php echo $sns_page_url; ?>&route=<?php echo $sns_page_url; ?>" target="_blank" title="Share This on Band" onClick="return snsWin(this.href, 700, 600)" class="band"><i class="fa fa-podcast" aria-hidden="true"></i></a></li>	
	
	<li><input type="text" id="copy" value="<?php echo $org_page_url; ?>"><a href="#" title="Copy to clipboard" onClick="copyClipboard()" class="copy show-icon"><i class="fa fa-link" aria-hidden="true"></i></a></li>	
	
	<li><a href="mailto:?subject=<?php echo $config['cf_title']; ?>&amp;body=<?php echo $sns_page_title;?>%0D%0A<?php echo $sns_page_description;?>%0D%0A<?php echo $sns_page_url; ?>" title="Share This on Email"  class="email show-icon"><i class="fa fa-envelope" aria-hidden="true"></i></a></li>
</ul>
</div>

<script type="text/javascript">
function snsWin(href, w, h) {
	var width = w;
	var height = h;
	var centerX, centerY;	
	centerX = (screen.width/2) - ((width/2) + 10);
    centerY = (screen.height/2) - ((height/2) + 40);	
	
	var winFeatures = "width="+width+", height="+height+", menubar=no, toolbar=no, resizable=yes, scrollbars=yes, location=no, status=no, directories=no, left=" + centerX + ",top=" + centerY + ",screenX=" + centerX + ",screenY=" + centerY;
	
	copyURL();
	window.open(href, 'snsWin', winFeatures);
	return false;
}
function copyClipboard() {
    copyURL();
    alert("URL을 복사하였습니다.");
	return false;
}
function copyURL() {
	var copyText = document.getElementById("copy");
    copyText.select();
    document.execCommand("copy");
}
</script>

<?php 
// 카카오 링크버튼 설정
if (G5_IS_MOBILE && !defined('G5_IS_ADMIN')) {
?>
<script src="https://developers.kakao.com/sdk/js/kakao.min.js"></script>
<script>
$(function() {
// 카카오 앱의 Javascript 키를 설정해 주세요.
// 키는 [관리자 > 환경설정 > SNS] 또는 inc/sns_config.php에서 입력할 수 있습니다.
// 카카오 디벨로퍼스 - https://developers.kakao.com/
Kakao.init('<?php echo $kakao_app_key; ?>');

// 카카오톡 링크 버튼을 생성합니다. 처음 한번만 호출하면 됩니다.
// 링크 설정은 inc/sns_config.php 파일에서 합니다.
Kakao.Link.createDefaultButton({
	container: '#snsBtn .kakaotalk',
	objectType: 'feed',
	content: {
		title: '<?php echo $kakao_message; ?>',
		description: '<?php echo $sns_description; ?>',
		imageUrl: '<?php echo $kakao_image; ?>',
		imageWidth : <?php echo $kakao_image_width; ?>,
		imageHeight : <?php echo $kakao_image_height; ?>,
		link: {
		  mobileWebUrl: '<?php echo $sns_url; ?>',
		  webUrl: '<?php echo $sns_url; ?>'
		}
	},
	buttons: [
		{
		  title: '<?php echo $kakao_btn_text; ?>',
		  link: {
			mobileWebUrl: '<?php echo $kakao_btn_url; ?>',
			webUrl: '<?php echo $kakao_btn_url; ?>'
		  }
		}
	]
});
});
</script>
<?php } ?>