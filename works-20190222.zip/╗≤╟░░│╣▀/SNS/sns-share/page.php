<?php
include_once('./_common.php');

// 모바일페이지가 따로 있다면 
/*
if (G5_IS_MOBILE) {
    include_once(G5_MOBILE_PATH.'/page/ceo.php');
    return;
}
*/

$page_title = "인사말";
$page_description = "창의적인 마인드로 더 좋은 웹, 더 좋은 나눔을 만드는 기업 휴온입니다.";

include_once("./_head.php");
?>
<link href="./css/ceo.css" rel="stylesheet" type="text/css">

<div id="greeting">
	
	<!-- <h1>COMPANY NAME</h1> -->
	
	<div class="slogan">사람을 위한 온라인 콘텐츠 제작 기업 - 휴온</div>
	
	<div class="lead">
		창의적인 마인드로 꿈을 현실로 만듭니다.<br>
		우리가 꿈꾸는 <strong>더 좋은 웹, 더 좋은 나눔</strong>을 함께 만들어 나가고 있습니다.
	</div>	
	
	
	<div class="photo">
		<img src="./img/ceo.jpg" alt="" width="300" height="300">
	</div>	
	<div class="msg">		
		<p>휴온은 2002년부터 고객님의 제품과 상품, 서비스를 웹으로 잘 알릴 수 있도록 홈페이지, 모바일웹 제작 서비스를 제공하고 있습니다.</p>

		<p>
		저희 휴온은 윤리경영과 가치경영에 바탕을 두고 우수한 제품, 완벽한 작업, 철저한 사후관리에 이르기까지 축적된 기술과 풍부한 경험으로 웹콘텐츠 제작의 선도기업으로 자리 잡았습니다.<br>
		<br>
		앞으로도 저희 휴온은 새로운 가치와 보다 나은 서비스를 창출해 고객사의 온라인 마케팅 발판을 마련하겠습니다.
		</p>
		  
		<p>보다 나은 기능과 세련된 기술개발을 통하여 생각하는 기업, 창의적인 기업, 발전하는 기업이 될 수 있도록 휴온의 노력은 계속될 것입니다.</p>
		
		<div class="sign">대표 ㅇㅇㅇ</div>	
	</div>
	
</div><!-- /greeting -->

<?php
// sns 공유버튼
include_once(G5_PATH."/inc/sns_share.php");

$board['bo_use_sns'] = true;
include_once(G5_SNS_PATH."/view.sns.skin.php");

include_once("./_tail.php");
?>
