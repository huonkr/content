<?php
include_once('./_common.php');

// include_once(G5_PATH.'/_head.php');
include_once(G5_PATH.'/head.sub.php');
?>


<?php
include_once(G5_LIB_PATH.'/post.lib.php');
// 포스트출력 : post(스킨, 게시판, $wr_id, $cache_time, $options)
echo post("hn_basic", "test", 9); 
?>

	
<?php
// include_once(G5_PATH.'/_tail.php');
include_once(G5_PATH.'/tail.sub.php');
?>