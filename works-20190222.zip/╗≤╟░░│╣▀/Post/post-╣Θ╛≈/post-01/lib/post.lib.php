<?php
if (!defined('_GNUBOARD_')) exit;


// wr_id에 해당되는 게시물 정보와 파일
// $cache_time 캐시 갱신시간
function post($skin_dir="", $bo_table, $wr_id=1, $cache_time=1, $options='') {
    global $g5;
    //static $css = array();

    if (!$skin_dir) $skin_dir = 'hn_basic';

	if(preg_match('#^theme/(.+)$#', $skin_dir, $match)) {
        if (G5_IS_MOBILE) {
            $post_skin_path = G5_THEME_MOBILE_PATH.'/'.G5_SKIN_DIR.'/post/'.$match[1];
            if(!is_dir($post_skin_path))
                $post_skin_path = G5_THEME_PATH.'/'.G5_SKIN_DIR.'/post/'.$match[1];
            $post_skin_url = str_replace(G5_PATH, G5_URL, $post_skin_path);
        } else {
            $post_skin_path = G5_THEME_PATH.'/'.G5_SKIN_DIR.'/post/'.$match[1];
            $post_skin_url = str_replace(G5_PATH, G5_URL, $post_skin_path);
        }
        $skin_dir = $match[1];
    } else {
        if(G5_IS_MOBILE) {
            $post_skin_path = G5_MOBILE_PATH.'/'.G5_SKIN_DIR.'/post/'.$skin_dir;
            $post_skin_url  = G5_MOBILE_URL.'/'.G5_SKIN_DIR.'/post/'.$skin_dir;
        } else {
            $post_skin_path = G5_SKIN_PATH.'/post/'.$skin_dir;
            $post_skin_url  = G5_SKIN_URL.'/post/'.$skin_dir;
        }
    }
	
	if (!is_dir($post_skin_path)) {
		return "<div style='margin:10px 0; padding:30px 5px; text-align:center; font-size:12px; '><strong><span style='font-size:20px;'>&lt;!&gt;</span> $skin_dir</strong> 스킨이 존재하지 않습니다.</div>";			
	}
	
    $cache_fwrite = false;
    if(G5_USE_CACHE) {
        $cache_file = G5_DATA_PATH."/cache/post-{$bo_table}-{$skin_dir}-{$bo_table}-{$wr_id}.php";

        if(!file_exists($cache_file)) {
            $cache_fwrite = true;
        } else {
            if($cache_time > 0) {
                $filetime = filemtime($cache_file);
                if($filetime && $filetime < (G5_SERVER_TIME - 3600 * $cache_time)) {
                    @unlink($cache_file);
                    $cache_fwrite = true;
                }
            }

			if(!$cache_fwrite) {
                try{
                    $file_contents = file_get_contents($cache_file);
                    $file_ex = explode("\n\n", $file_contents);
                    $caches = unserialize(base64_decode($file_ex[1]));

                    $post = (is_array($caches) && isset($caches['list'])) ? $caches['list'] : array();
                    $bo_subject = (is_array($caches) && isset($caches['bo_subject'])) ? $caches['bo_subject'] : '';
                } catch(Exception $e){
                    $cache_fwrite = true;
                    $post = array();
                }
            }
        }
    }

    if(!G5_USE_CACHE || $cache_fwrite) {
        $post = array();

        $sql = " select * from {$g5['board_table']} where bo_table = '{$bo_table}' ";
        $board = sql_fetch($sql);
        $bo_subject = get_text($board['bo_subject']);
		
		if($board['bo_table'] != $bo_table) {
			return "<div style='margin:10px 0; padding:30px 5px; text-align:center; font-size:12px; '>&lt;!&gt; <strong>$bo_table</strong> 게시판이 존재하지 않습니다.</div>";	
		}				

        $tmp_write_table = $g5['write_prefix'] . $bo_table; // 게시판 테이블 전체이름		
        
		$sql = " select * from {$tmp_write_table} where wr_id='$wr_id' ";
		$row = sql_fetch($sql);		
		
		//패스워드, 이메일, 비밀글일 경우 내용, 링크, 파일 저장 안함
		try {
			unset($row['wr_password']);
		} catch (Exception $e) {
		}
		$row['wr_email'] = '';
		if (strstr($row['wr_option'], 'secret')) {
			$row['wr_content'] = $row['wr_link1'] = $row['wr_link2'] = '';
			$row['file'] = array('count'=>0);
		}	
		
		$post = get_list($row, $board, $post_skin_path);
		
        if($cache_fwrite) {
			$handle = fopen($cache_file, 'w');
            $caches = array(
                'list' => $post,
                'bo_subject' => sql_escape_string($bo_subject),
                );
            $cache_content = "<?php if (!defined('_GNUBOARD_')) exit; ?>\n\n";
            $cache_content .= base64_encode(serialize($caches));  //serialize

            fwrite($handle, $cache_content);
            fclose($handle);

            @chmod($cache_file, 0640);
        }
    }
	
    ob_start();
    include $post_skin_path.'/post.skin.php';
    $content = ob_get_contents();
    ob_end_clean();

    return $content;
}

?>