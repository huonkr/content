<?php
include_once('./_common.php');

include_once(G5_PATH.'/head.sub.php');
// include_once(G5_PATH.'/_head.php');
?>


<?php
include_once(G5_LIB_PATH.'/post.lib.php');
// 'hn_nivo_slider' 포스트스킨 옵션
$options = array("num" => 5, "pause_time" => 3);
// 포스트 매개변수 : 스킨명, 게시판명, wr_id, 캐시타임, 옵션
echo post("hn_nivo_slider", "media", 3, 1, $options);
?>
	
	
<?php
// include_once(G5_PATH.'/_tail.php');
include_once(G5_PATH.'/tail.sub.php');
?>