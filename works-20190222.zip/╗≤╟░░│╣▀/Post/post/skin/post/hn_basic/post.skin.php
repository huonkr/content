<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

$post[file] = get_file($bo_table, $wr_id);

$post['subject'] = get_text($post['wr_subject']);
// $post['href'] = G5_BBS_URL."/board.php?bo_table={$bo_table}&wr_id={$wr_id}";

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.$post_skin_url.'/hn_basic.css">', 0);
?>
<!-- <?php echo $post_subject; ?> 최신글 시작 { -->
<div class="post">
	<h3 class="post-title">
		<a href="<?php echo $post['href'] ?>"><?php echo $post['wr_subject']; ?></a>
	</h3>  
	
	<div class="post-content">
	<?php 
	// 이미지	
	$img_tag = "";
	for ($i=0; $i < count($post[file]); $i++) {
		$upload_file = $post[file][$i][path]."/".$post[file][$i][file]; // 원본 이미지
		
		// 업로드된 파일 이미지가 존재하면
		if (preg_match("/\.(jp[e]?g|gif|png)$/i", $upload_file)) {
			// 이미지캡션
			if($list[file][$i][bf_content] && strlen($list[file][$i][bf_content]) > 2) {
				$img_tag .= "	<img src=\"$upload_file\" alt=\"{$list[file][$i][bf_content]}\"> \n";
			} else {
				$img_tag .= "	<img src=\"$upload_file\" alt=\"{$post['wr_subject']}\"> \n";
			}
			$img_tag .= "<br> \n";
		}
	}
	echo $img_tag;
	
	// 콘텐츠
	echo nl2br($post['wr_content']);
	?>
	</div>
</div>