<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// 컴포넌트 사용
/*
include_once(G5_LIB_PATH.'/component.lib.php');
// 대기시간, 스타일, 이미지경로, 링크주소
$visual_options = [
	"pause" => 3, //초
	"css" => ["max-height" => 500, "background" => "#555"],	
	"src" => [".", ".", "."],
	"url" => ["http://...", "http://...", "http://..."]
];
hn_component("visual", $visual_options);
*/

// 슬라이더 대기시간
$pause_time = ( $options['setting']['pause'] ) ? $options['setting']['pause']*1000 : 3000;
?>
<link href="<?php echo G5_PLUGIN_URL?>/nivo/nivo-slider.css" rel="stylesheet" type="text/css" />  
<link href="<?php echo G5_PLUGIN_URL?>/nivo/themes/default/default.css" rel="stylesheet" type="text/css">
<link href="<?php echo G5_PLUGIN_URL?>/nivo/themes/light/light.css" rel="stylesheet" type="text/css">
<link href="<?php echo G5_PLUGIN_URL?>/nivo/themes/dark/dark.css" rel="stylesheet" type="text/css">
<link href="<?php echo G5_PLUGIN_URL?>/nivo/themes/bar/bar.css" rel="stylesheet" type="text/css">
<style>
.slider-wrapper { position:relative;}
#slider.nivoSlider.<?php echo $options['class']; ?> { overflow:hidden; max-height:<?php echo $options['css']['max-height']; ?>px;}
</style>

<div class="slider-wrapper theme-<?php echo $options['theme']; ?>">
	<div id="slider" class="nivoSlider <?php echo $options['class']; ?>">
	<?php
	for ($i=0; $i<count($options['src']); $i++) {
		if ( $options['url'][$i] ) {
			echo "	<a href=\"{$options['url'][$i]}\"><img src=\"{$options['src'][$i]}\" alt=\"\"></a>\n";
		} else {
			echo "	<img src=\"{$options['src'][$i]}\" alt=\"\">\n";
		}
	}
	?>
	</div>	
</div>			
<script src="<?php echo G5_PLUGIN_URL?>/nivo/jquery.nivo.slider.pack.js" type="text/javascript"></script>
<script type="text/javascript">	
$(window).load(function() {		
	$('.nivoSlider.<?php echo $options['class']; ?>').nivoSlider({
		effect: 'random',               // Specify sets like: 'fold,fade,sliceDown'
		slices: 15,                     // For slice animations
		boxCols: 8,                       // For box animations 
		boxRows: 4,                       // For box animations
		animSpeed: 500,                 // Slide transition speed
		pauseTime: <?php echo $pause_time?>,    // How long each slide will show
		startSlide: 0,                  // Set starting Slide (0 index)
		directionNav: true,             // Next & Prev navigation
		controlNav: true,               // 1,2,3... navigation
		controlNavThumbs: false,        // Use thumbnails for Control Nav
		pauseOnHover: true,             // Stop animation while hovering
		manualAdvance: false,           // Force manual transitions
		prevText: 'Prev',               // Prev directionNav text
		nextText: 'Next',               // Next directionNav text
		randomStart: false,             // Start on a random slide
		beforeChange: function(){},     // Triggers before a slide transition
		afterChange: function(){},      // Triggers after a slide transition
		slideshowEnd: function(){},     // Triggers after all slides have been shown
		lastSlide: function(){},        // Triggers when last slide is shown
		afterLoad: function(){}         // Triggers when slider has loaded
	});
	
	$('#slider img').click(function() {
		var href = $(this).attr("alt");		
		if (href && (href.indexOf("http://") !== 0)) { 
			href = "http://" + href;
			location.href = href;
		} else	if(href) {
			location.href = href;
		}
	});
});
</script>