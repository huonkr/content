<?php
if (!defined('_GNUBOARD_')) exit;

// 컴포넌트 실행
function hn_component($name="", $options=array()) {
	global $g5;	
	$component = array();
		
	// 컴포넌트 이름
	$component['name'] = $name;

	// 컴포넌트 폴더와 파일
	$component['url'] = G5_URL."/component/".$component['name'];
	$component['path'] = G5_PATH."/component/".$component['name'];	
	$component['file'] = $component['url']."/".$component['name'].".php";
	$component['file_path'] = $component['path']."/".$component['name'].".php";

	// 컴포넌트내의 리소스 위치
	$component['css'] = $component['url']."/css";
	$component['js'] = $component['url']."/js";
	$component['images'] = $component['url']."/images";
	
	if ( is_file($component['file_path']) ) {		
		ob_start();
		include $component['file_path'];
		$content = ob_get_contents();
		ob_end_clean();
		
		echo $content;
	} else {
		echo "<p>'".$component['file_path']."' 파일이 존재하지 않습니다. </p>\n"; 
	}
}
?>