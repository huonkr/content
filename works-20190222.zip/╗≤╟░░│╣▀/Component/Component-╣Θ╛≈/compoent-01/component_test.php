<?php
include_once('./_common.php');

define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가
	
if(defined('G5_THEME_PATH')) {
    require_once(G5_THEME_PATH.'/index.php');
    return;
}

if (G5_IS_MOBILE) {
    include_once(G5_MOBILE_PATH.'/index.php');
    return;
}

// include_once(G5_PATH.'/_head.php');
include_once(G5_PATH.'/head.sub.php');
?>
<h2>메인비주얼</h2>

<?php
// 컴포넌트 - visual
include_once(G5_LIB_PATH.'/component.lib.php');
// 매개변수 : 컴포넌트명, 옵션
// 옵션: 클래스명, 테마, 슬라이더세팅, 스타일, 이미지경로, 링크주소
$visual_options = [
	"class" => "main",
	"theme" => "default",
	"setting" => [
		"pause" => 3 //초
	],
	"css" => [
		"max-height" => 500
	],
	"src" => [
		"http://hnsite.cafe24.com/hnbuilder/data/file/media/1029960964_mnvithUk_981a386891703ded97167b29a9bc4d1a0ba7672a.jpg",
		"http://hnsite.cafe24.com/hnbuilder/data/file/media/1029960964_ksnBj9rt_c6fed9522bf6c87ffccee3f892920048aba9b897.jpg",
		"http://hnsite.cafe24.com/hnbuilder/data/file/media/1029960964_eQ8sd06J_1a6f527ee8c486cd87567f85d4d702d77ce32a56.jpg"
	],
	"url" => [
		"http://huon.co.kr",
		"http://hnsite.cafe24.com/hnbuilder",
		"http://jejuma.net"
	]
];
hn_component("visual", $visual_options);
?>
	
<br><br><br>
	
	
	
<h2>서브비주얼</h2>	

<?php
// 옵션 - 대기시간, 스타일, 이미지경로, 링크주소
$visual_options = [
	"class" => "sub",
	"theme" => "dark",
	"setting" => [
		"pause" => 3 //초
	],
	"css" => [
		"max-height" => 300
	],
	"src" => [
		G5_URL."/images/visual/panorama.jpg",
		G5_URL."/images/visual/turquoise.jpg",
		G5_URL."/images/visual/sunset.jpg"
	],
	"url" => [
		"http://huon.co.kr",
		"http://jejuma.net"
	]
];
hn_component("visual", $visual_options);
?>

<br><br><br>
	

<h2>서브비주얼-2</h2>

<?php
// 옵션 - 대기시간, 스타일, 이미지경로, 링크주소
$visual_options = [
	"class" => "sub2",
	"theme" => "light",
	"setting" => [
		"pause" => 5 //초
	],
	"css" => [
		"max-height" => 200
	],
	"src" => [
		G5_URL."/images/visual/plate.jpg",
		G5_URL."/images/visual/sunflower.jpg",
		G5_URL."/images/visual/grass.jpg"
	],
	"url" => [
		"http://huon.co.kr"
	]
];
hn_component("visual", $visual_options);
?>

<br><br><br>
	

<h2>서브비주얼-3</h2>

<?php
// 옵션 - 대기시간, 스타일, 이미지경로, 링크주소
$visual_options = [
	"class" => "sub3",
	"theme" => "bar",
	"setting" => [
		"pause" => 2 //초
	],
	"css" => [
		"max-height" => 300
	],
	"src" => [
		G5_URL."/images/visual/turquoise.jpg",
		G5_URL."/images/visual/panorama.jpg",
		G5_URL."/images/visual/sunflower.jpg",
		G5_URL."/images/visual/sunset.jpg",
		G5_URL."/images/visual/grass.jpg",
		G5_URL."/images/visual/plate.jpg"
	],
	"url" => [
		"http://huon.co.kr"
	]
];
hn_component("visual", $visual_options);
?>

<br><br><br>
	

	


	
<?php
// include_once(G5_PATH.'/_tail.php');
include_once(G5_PATH.'/tail.sub.php');
?>