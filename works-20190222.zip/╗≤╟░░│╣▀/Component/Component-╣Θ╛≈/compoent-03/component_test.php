<?php
include_once('./_common.php');

define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가
	
if(defined('G5_THEME_PATH')) {
    require_once(G5_THEME_PATH.'/index.php');
    return;
}

if (G5_IS_MOBILE) {
    include_once(G5_MOBILE_PATH.'/index.php');
    return;
}
 
// include_once(G5_PATH.'/_head.php');
include_once(G5_PATH.'/head.sub.php');
?>

<h2>메인비주얼</h2>
<?php
// 컴포넌트 - visual
include_once(G5_LIB_PATH.'/component.lib.php');

// visual 컴포넌트 데이터: 이미지주소, 링크url
// php 5.4 이하에서는 배열 리터럴 표기를 array()로 변경하여 사용하세요.
$cpt_data = [
	"src" => [
		"http://hnsite.cafe24.com/hnbuilder/data/file/media/1029960964_mnvithUk_981a386891703ded97167b29a9bc4d1a0ba7672a.jpg",
		"http://hnsite.cafe24.com/hnbuilder/data/file/media/1029960964_ksnBj9rt_c6fed9522bf6c87ffccee3f892920048aba9b897.jpg",
		"http://hnsite.cafe24.com/hnbuilder/data/file/media/1029960964_eQ8sd06J_1a6f527ee8c486cd87567f85d4d702d77ce32a56.jpg"
	],
	"alt" => [
		"이미지 설명 - 1",
		"이미지 설명 - 2",
		"이미지 설명 - 3"
	],
	"url" => [
		"http://huon.co.kr",
		"http://hnsite.cafe24.com/hnbuilder",
		"http://jejuma.net"
	]
];

// 게시판
// 'bo_table' 필수, 'wr_id' 선택, 'wr_id'가 있으면 게시물 데이터 사용
// 'wr_id'를 배열로도 지정 가능
/*
$cpt_data = [
	"bo_table" = "gallery"
];
$cpt_data = [
	"bo_table" = "gallery",	
	"wr_id" = 1
];
$cpt_data = [
	"bo_table" = "gallery",	
	"wr_id" = [1, 2, 3, 4, 5]
];
*/

// 콘텐츠
// 'co_id' 필수
/*
$cpt_data = [
	"co_id" = "main_visual"
];
*/
// visual 컴포넌트 옵션: 클래스명, 테마, 대기시간(초), 최대높이
$cpt_options = [
	"class" => "main",
	"theme" => "default",
	"pause" => 3,
	"max-height" => 500
];
// 매개변수 : 컴포넌트명, 데이터, 옵션
component("visual", $cpt_data, $cpt_options);
?>
	
	
<br>	
	
<h2>비주얼컴포넌트1 - 게시물 데이터</h2>	
<?php
// 데이터 - 게시판
$cpt_data = ["bo_table" => "media", "wr_id" => 7];
$cpt_options = [
	"class" => "sub",
	"theme" => "dark",
	"pause" => 3,
	"max-height" => 300
];
component("visual", $cpt_data, $cpt_options);
?>

<br>

<h2>비주얼컴포넌트2 - media 게시판</h2>
<?php
// 데이터 - 게시판
$cpt_data = ["bo_table" => "media"];
// 옵션 - 대기시간, 스타일, 이미지경로, 링크주소
$cpt_options = [
	"class" => "sub2",
	"theme" => "light",
	"pause" => 5,
	"max-height" => 350
];
component("visual", $cpt_data, $cpt_options);
?>

<br>


<h2>비주얼컴포넌트2-2 - 멀티게시물 데이터</h2>	
<?php
// 데이터 - 게시판
$cpt_data = [
	"bo_table" => "media",
	"wr_id" => [1,2,3,4,5]
];
$cpt_options = [
	"class" => "sub4",
	"theme" => "light",
	"pause" => 3,
	"max-height" => 300
];
component("visual", $cpt_data, $cpt_options);
?>

<br>

<h2>비주얼컴포넌트3 - 'main_visual' 콘텐츠</h2>
<?php
// 콘텐츠 데이터
$cpt_data = ["co_id" => "main_visual"];

// 옵션 - 대기시간, 스타일, 이미지경로, 링크주소
$cpt_options = [
	"class" => "sub3",
	"theme" => "bar",
	"pause" => 2,
	"max-height" => 300
];
component("visual", $cpt_data, $cpt_options);
?>


<br><br><br><br>
	
	
<?php
// include_once(G5_PATH.'/_tail.php');
include_once(G5_PATH.'/tail.sub.php');
?>