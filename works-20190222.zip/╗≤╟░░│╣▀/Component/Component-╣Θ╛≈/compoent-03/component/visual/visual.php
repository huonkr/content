<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// 게시판이나 콘텐츠인 경우 데이터 처리
// -------------------------------------------------------------------------
// 게시물인 경우
if ($bo_table && $wr_id) {
	$visual_idx = 0;
	$list[file] = get_file($bo_table, $wr_id);
	for ($i=0; $i < count($list[file]); $i++) {
		$visual_file = $list[file][$i][path]."/".$list[file][$i][file]; // 원본 이미지
	
		// 업로드된 파일 이미지가 존재하면
		if (preg_match("/\.(jp[e]?g|gif|png)$/i", $visual_file)) {					
			$data['src'][$visual_idx] = $visual_file;
			
			// 이미지캡션
			if($list[file][$i][bf_content] && strlen($list[file][$i][bf_content]) > 2) {
				$bf_content = $list[file][$i][bf_content];
				//링크인지 확인
				if (preg_match('#^https?://#i', $bf_content)) {
					$data['url'][$visual_idx] = $bf_content;
				} else {
					$data['alt'][$visual_idx] = $bf_content;
				}			
			}
			
			$visual_idx++;
		}
	}
// 게시판인 경우	
} else if ($bo_table) {
	$visual_idx = 0;	
	for ($i=0; $i < count($list); $i++) {
		$wr_id = $list[$i]['wr_id'];	
		$list[$i][file] = get_file($bo_table, $wr_id);
		
		// 원본 이미지
		for ($k=0; $k < count($list[$i][file]['count']); $k++) {
			$visual_file = $list[$i][file][$k][path]."/".$list[$i][file][$k][file];
			if (preg_match("/\.(jp[e]?g|gif|png)$/i", $visual_file)) {
				$data['src'][$visual_idx] = $visual_file;				
			}
			
			// 이미지캡션
			if($list[$i][file][$k][bf_content] && strlen($list[$i][file][$k][bf_content]) > 2) {
				$bf_content = $list[$i][file][$k][bf_content];
				//링크인지 확인
				if (preg_match('#^https?://#i', $bf_content)) {
					$data['url'][$visual_idx] = $bf_content;
				} else {
					$data['alt'][$visual_idx] = $bf_content;
				}			
			}			
			
			if ($data['src'][$visual_idx]) {
				break;
			} 
		}
		
		if ($data['src'][$visual_idx]) {
			$visual_idx++;
		}
	}
	
// 콘텐츠인경우	
} else if( $co_id ) {		
	// 콘텐츠 내용 중 이미지 src 추출	
	preg_match_all("/<img[^>]*src=[\"']?([^>\"']+)[\"']?[^>]*>/i", $list['content'], $imgs);	
	// 링크가 적용된 이미지 추출			
	preg_match_all("/<a[^>]*href=[\"']?([^>\"']+)[\"']?[^>]*><img[^>]*src=[\"']?([^>\"']+)[\"']?[^>]*>/i", $list['content'], $urls);
	
	$visual_idx = 0;
	// 데이터 입력
	foreach($imgs[1] as $key => $val) {		
		// 링크가 적용되었는지 체크
		if (in_array($val, $urls[2])) {
			$url_key = array_search($val, $urls[2]);
			$data['url'][$visual_idx] = $urls[1][$url_key];
		}
		
		$data['src'][$visual_idx] = $val;
		$visual_idx++;
	}
}
// -------------------------------------------------------------------------

// 슬라이더 대기시간
$pause_time = ( $options['pause'] ) ? $options['pause']*1000 : 3000;
?>
<link href="<?php echo G5_PLUGIN_URL?>/nivo/nivo-slider.css" rel="stylesheet" type="text/css" />  
<link href="<?php echo G5_PLUGIN_URL?>/nivo/themes/default/default.css" rel="stylesheet" type="text/css">
<link href="<?php echo G5_PLUGIN_URL?>/nivo/themes/light/light.css" rel="stylesheet" type="text/css">
<link href="<?php echo G5_PLUGIN_URL?>/nivo/themes/dark/dark.css" rel="stylesheet" type="text/css">
<link href="<?php echo G5_PLUGIN_URL?>/nivo/themes/bar/bar.css" rel="stylesheet" type="text/css">
<style>
.slider-wrapper { position:relative;}
#slider.nivoSlider.<?php echo $options['class']; ?> { overflow:hidden; max-height:<?php echo $options['max-height']; ?>px;}
</style>

<div class="slider-wrapper theme-<?php echo $options['theme']; ?>">
	<div id="slider" class="nivoSlider <?php echo $options['class']; ?>">
	<?php
	for ($i=0; $i < count($data['src']); $i++) {
		if ( $data['url'][$i] ) {
			echo "	<a href=\"{$data['url'][$i]}\"><img src=\"{$data['src'][$i]}\" alt=\"\"></a>\n";
		} else {
			echo "	<img src=\"{$data['src'][$i]}\" alt=\"{$data['alt'][$i]}\">\n";
		}
	}
	?>
	</div>	
</div>			
<script src="<?php echo G5_PLUGIN_URL?>/nivo/jquery.nivo.slider.pack.js" type="text/javascript"></script>
<script type="text/javascript">	
$(window).load(function() {		
	$('.nivoSlider.<?php echo $options['class']; ?>').nivoSlider({
		effect: 'random',               // Specify sets like: 'fold,fade,sliceDown'
		slices: 15,                     // For slice animations
		boxCols: 8,                       // For box animations 
		boxRows: 4,                       // For box animations
		animSpeed: 500,                 // Slide transition speed
		pauseTime: <?php echo $pause_time?>,    // How long each slide will show
		startSlide: 0,                  // Set starting Slide (0 index)
		directionNav: true,             // Next & Prev navigation
		controlNav: true,               // 1,2,3... navigation
		controlNavThumbs: false,        // Use thumbnails for Control Nav
		pauseOnHover: true,             // Stop animation while hovering
		manualAdvance: false,           // Force manual transitions
		prevText: 'Prev',               // Prev directionNav text
		nextText: 'Next',               // Next directionNav text
		randomStart: false,             // Start on a random slide
		beforeChange: function(){},     // Triggers before a slide transition
		afterChange: function(){},      // Triggers after a slide transition
		slideshowEnd: function(){},     // Triggers after all slides have been shown
		lastSlide: function(){},        // Triggers when last slide is shown
		afterLoad: function(){}         // Triggers when slider has loaded
	});
	
	$('#slider img').click(function() {
		var href = $(this).attr("alt");		
		if (href && (href.indexOf("http://") !== 0)) { 
			href = "http://" + href;
			location.href = href;
		} else	if(href) {
			location.href = href;
		}
	});
});
</script>