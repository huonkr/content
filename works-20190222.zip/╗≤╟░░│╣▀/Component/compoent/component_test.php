<?php
include_once('./_common.php');

define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가
	
if(defined('G5_THEME_PATH')) {
    require_once(G5_THEME_PATH.'/index.php');
    return;
}

if (G5_IS_MOBILE) {
    include_once(G5_MOBILE_PATH.'/index.php');
    return;
}
 
// include_once(G5_PATH.'/_head.php');
include_once(G5_PATH.'/head.sub.php');
?>




<h2>컴포넌트 - 메인비주얼이미지</h2>
<?php
// 컴포넌트 - visual
include_once(G5_LIB_PATH.'/component.lib.php');

// visual 컴포넌트 데이터: 이미지주소, 링크url
// php 5.4 이하에서는 배열 리터럴 표기를 array()로 변경하여 사용하세요.
$component_data = array(
	"src" => array(
		"http://hnsite.cafe24.com/hnbuilder/data/file/gallery/1029960964_0aC2zPyx_be61308e630d9ef18e06e969e4007f5303cc62bf.jpg",
		"http://hnsite.cafe24.com/hnbuilder/data/file/gallery/1029960964_h6AmMtSd_0491fbc951063e7a4a2a88396d3a25c0f91f4b5a.jpg",
		"http://hnsite.cafe24.com/hnbuilder/data/file/gallery/1029960964_v0pzChy2_a1293df81d813c48f62f2e0342a8a1ca55efc5a6.jpg"
	),
	"alt" => array(
		"이미지 설명 - 1",
		"이미지 설명 - 2",
		"이미지 설명 - 3"
	),
	"url" => array(
		"http://huon.co.kr",
		"http://hnsite.cafe24.com/hnbuilder",
		"http://jejuma.net"
	)
);

// visual 컴포넌트 옵션: 클래스명, 테마, 대기시간(초), 최대높이
$component_options = array(	
	"theme" => "default",
	"pause" => 3,
	"max-height" => 500,
	"class" => "main"
);
// 매개변수 : 컴포넌트명, 데이터, 옵션
component("visual", $component_data, $component_options);
?>	
	
<br>	
	
<h2>컴포넌트 - 메인비주얼이미지 - 게시물 데이터</h2>	
<?php

// 게시판
// 'bo_table' 필수, 'wr_id' 선택, 'wr_id'가 있으면 게시물 데이터 사용
// 'wr_id'를 배열로도 지정 가능
/*
$component_data = [
	"bo_table" = "gallery"
];
$component_data = [
	"bo_table" = "gallery",	
	"wr_id" = 1
];
$component_data = [
	"bo_table" = "gallery",	
	"wr_id" = [1, 2, 3, 4, 5]
];
*/

// 데이터 - 게시판
$component_data = array("bo_table" => "media", "wr_id" => 3);
$component_options = [	
	"theme" => "dark",
	"pause" => 3,
	"max-height" => 300,
	"class" => "sub"
];
component("visual", $component_data, $component_options);
?>

<br>

<h2>컴포넌트 - 메인비주얼이미지 - media 게시판</h2>
<?php
// 데이터 - 게시판
$component_data = array("bo_table" => "media");
// 옵션 - 대기시간, 스타일, 이미지경로, 링크주소
$component_options = [	
	"theme" => "light",
	"pause" => 5,
	"max-height" => 350,
	"class" => "sub2"
];
component("visual", $component_data, $component_options);
?>

<br>


<h2>컴포넌트 - 메인비주얼이미지 - 멀티게시물 데이터</h2>	
<?php
// 데이터 - 게시판
$component_data = array(
	"bo_table" => "media",
	"wr_id" => [1,2,3,4,5]
);
$component_options = array(	
	"theme" => "light",
	"pause" => 3,
	"max-height" => 300,
	"class" => "sub3"
);
component("visual", $component_data, $component_options);
?>

<br>

<h2>컴포넌트 - 메인비주얼이미지 - 'main_visual' 콘텐츠</h2>
<?php
// 콘텐츠
// 'co_id' 필수
/*
$component_data = [
	"co_id" = "main_visual"
];
*/

// 콘텐츠 데이터
$component_data = array("co_id" => "main_visual");

// 옵션 - 대기시간, 스타일, 이미지경로, 링크주소
$component_options = array(	
	"theme" => "bar",
	"pause" => 2,
	"max-height" => 300,
	"class" => "sub4",
);
component("visual", $component_data, $component_options);
?>


<br><br><br><br>
	
	
<?php
// include_once(G5_PATH.'/_tail.php');
include_once(G5_PATH.'/tail.sub.php');
?>