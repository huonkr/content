<?php
if (!defined('_GNUBOARD_')) exit;

// 컴포넌트 실행
function component($name="", $data=array(), $options=array()) {
	global $g5;	
	$component = array();
		
	// 컴포넌트 이름
	$component['name'] = $name;

	// 컴포넌트 폴더와 파일
	$component['url'] = G5_URL."/component/".$component['name'];
	$component['path'] = G5_PATH."/component/".$component['name'];	  
	$component['file'] = $component['url']."/".$component['name'].".php";
	$component['file_path'] = $component['path']."/".$component['name'].".php";

	// 컴포넌트내의 리소스 위치
	$component['css'] = $component['url']."/css";
	$component['js'] = $component['url']."/js";
	$component['images'] = $component['url']."/images";
		
	// $data 처리
	// 게시판 데이터
	if ( $data['bo_table'] ) {
		$bo_table = $data['bo_table'];
		
		$sql = " select * from {$g5['board_table']} where bo_table = '{$bo_table}' ";
        $board = sql_fetch($sql);
        $bo_subject = get_text($board['bo_subject']);
		
		// 게시판이 없으면 실행 종료
		if( !count($board) ) {
			echo "<p>'".$bo_table."' 게시판이 존재하지 않습니다. </p>\n"; 
			return;	
		}
		
		$tmp_write_table = $g5['write_prefix'] . $bo_table;
		
		// 여러 게시물
		if ( $data['wr_id'] && is_array($data['wr_id'])) {
			$wr_id_arr = $data['wr_id'];
			$wr_id_str = implode(",", $wr_id_arr);
			$sql = "select * from {$tmp_write_table} where wr_id in ($wr_id_str)";
			$result = sql_query($sql);
			for ($i=0; $row = sql_fetch_array($result); $i++) {				
				$list[$i] = get_board_data($row, $board);
			}	
		// 단일 게시물	
		} else if ( $data['wr_id'] ) {
			$wr_id = $data['wr_id'];						
			$sql = " select * from {$tmp_write_table} where wr_id='$wr_id' ";
			$row = sql_fetch($sql);			
			$list = get_board_data($row, $board);
		// 게시판 목록
		} else {			
			$sql = " select * from {$tmp_write_table} where wr_is_comment = 0 order by wr_num ";
			$result = sql_query($sql);
			for ($i=0; $row = sql_fetch_array($result); $i++) {				
				$list[$i] = get_board_data($row, $board);
			}			
		}
	// 콘텐츠 데이터
	} else if ( $data['co_id'] ) {
		$co_id = $data['co_id'];
		$sql = "select * from {$g5['content_table']} where co_id = '$co_id'";
		$row = sql_fetch($sql);
		$list['co_id'] = $co_id;
		$list['title'] = $row['co_subject'];
		$list['content'] = conv_content($row['co_content'], $row['co_html'], $row['co_tag_filter_use']);			
	}
	
	if ( is_file($component['file_path']) ) {		
		ob_start();
		include $component['file_path'];
		$content = ob_get_contents();
		ob_end_clean();		
		echo $content;
	} else {
		echo "<p>'".$component['file_path']."' 컴포넌트가 존재하지 않습니다. </p>\n"; 
	}
}

// 게시물 데이터
function get_board_data($write_row, $board)
{
    global $g5, $config;

    //$t = get_microtime();

    // 배열전체를 복사
    $list = $write_row;
    unset($write_row);
	
	try {
		unset($list['wr_password']);     //패스워드 저장 안함( 아예 삭제 )
	} catch (Exception $e) {
	}
	// $list['wr_email'] = '';              //이메일 저장 안함
	if (strstr($list['wr_option'], 'secret')){           // 비밀글일 경우 내용, 링크, 파일 저장 안함
		$list['wr_content'] = $list['wr_link1'] = $list['wr_link2'] = '';
		$list['file'] = array('count'=>0);
	}

    if ($subject_len)
        $list['subject'] = conv_subject($list['wr_subject'], $subject_len, '…');
    else
        $list['subject'] = conv_subject($list['wr_subject'], $board['bo_subject_len'], '…');

	$html = 0;
	if (strstr($list['wr_option'], 'html1'))
		$html = 1;
	else if (strstr($list['wr_option'], 'html2'))
		$html = 2;
	$list['content'] = conv_content($list['wr_content'], $html);

    $list['wr_homepage'] = get_text($list['wr_homepage']);

    $list['name'] = get_text(cut_str($list['wr_name'], $config['cf_cut_name'])); 
    
    $list['href'] = G5_BBS_URL.'/board.php?bo_table='.$board['bo_table'].'&amp;wr_id='.$list['wr_id'];
    $list['comment_href'] = $list['href'];

    // 링크
    for ($i=1; $i<=G5_LINK_COUNT; $i++) {
        $list['link'][$i] = set_http(get_text($list["wr_link{$i}"]));
        $list['link_href'][$i] = G5_BBS_URL.'/link.php?bo_table='.$board['bo_table'].'&amp;wr_id='.$list['wr_id'];
        $list['link_hit'][$i] = (int)$list["wr_link{$i}_hit"];
    }

    // 가변 파일
    if ($board['bo_use_list_file'] || ($list['wr_file'] && $subject_len == 255) /* view 인 경우 */) {
        $list['file'] = get_file($board['bo_table'], $list['wr_id']);
    } else {
        $list['file']['count'] = $list['wr_file'];
    }

    return $list;
}
?>