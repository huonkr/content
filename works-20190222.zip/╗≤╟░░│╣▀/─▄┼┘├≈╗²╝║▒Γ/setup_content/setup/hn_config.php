<?php
/* 휴온빌더 > 환경설정 변경
------------------------------------------------------ */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

if ($is_admin != "super") {
	alert("관리자로 로그인 후 실행하세요.", G5_BBS_URL."/login.php");
}

if (!$_GET['sitename']) {
	$sitename = "사이트명";
}

// 기본환경설정 변경
// 테마 초기화, 제목, 회원스킨, faq스킨
$sql = "update {$g5['config_table']} 
		set cf_theme = '', 
			cf_title = '$sitename', 
			cf_admin_email_name = '$sitename', 
			cf_member_skin = 'hn_basic', 
			cf_mobile_member_skin = 'hn_basic',
			cf_faq_skin = 'hn_basic', 
			cf_mobile_faq_skin = 'hn_basic'		
		";	
sql_query($sql);

// qa 스킨 변경
$sql = "update {$g5['qa_config_table']} set qa_skin = 'hn_basic', qa_mobile_skin = 'hn_basic' ";
sql_query($sql);
?>
