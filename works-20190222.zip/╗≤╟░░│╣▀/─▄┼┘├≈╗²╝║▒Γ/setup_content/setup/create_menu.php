<?php
/* 휴온빌더 > 환경설정 변경
------------------------------------------------------ */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

if($is_admin != "super") {
	alert("관리자로 로그인 후 실행하세요.", G5_BBS_URL."/login.php");
}

// 기본메뉴
// 메뉴 링크에 쓰인 "[G5_URL]"은 그누보드 상수로 대체됩니다.
$menus = array(
	array('10', '회사소개', "[G5_URL]/page/ceo.php"),
	array('1010', '인사말', 	"[G5_URL]/page/ceo.php"),
	array('1020', '회사연혁', "[G5_URL]/page/history.php"),
	array('1030', '오시는길', "[G5_URL]/page/map.php"),
	
	array('20', '콘텐츠', "[G5_URL]/content.php"),
	array('2010', '콘텐츠1', "[G5_URL]/bbs/content.php?co_id=content1"),
	array('2020', '콘텐츠2', "[G5_URL]/bbs/content.php?co_id=content2"),
	
	array('30', '갤러리', "[G5_URL]/bbs/board.php?bo_table=gallery"),
	array('3010', '갤러리', "[G5_URL]/bbs/board.php?bo_table=gallery"),
	
	array('40', '게시판', "[G5_URL]/page/cs.php"),
	array('4010', '공지사항', "[G5_URL]/bbs/board.php?bo_table=notice"),
	array('4020', '1:1문의', "[G5_URL]/bbs/board.php?bo_table=myqna"),
	array('4030', '질문답변', "[G5_URL]/bbs/board.php?bo_table=qna"),
	array('4040', '자유게시판', "[G5_URL]/bbs/board.php?bo_table=bbs"),
	
	array('90', '관리자', "[G5_URL]/adm/"),
	array('9010', '관리자', "[G5_URL]/adm/"),
	array('9020', '미디어관리', "[G5_URL]/bbs/board.php?bo_table=media")
);

for($i=0; $i<count($menus); $i++) {	
	$me_code = $menus[$i][0];
	$me_name = $menus[$i][1];
	$me_link = $menus[$i][2];
	
	$m_row=sql_fetch("select count(*) as cnt from {$g5['menu_table']} where me_name='$me_name' and me_code='$me_code' and me_link='$me_link'");
	if($m_row['cnt']) {
		continue;
	}
	
	$me_use = 1;
	$me_mobile_use = 1;
	/*
	// 특정 메뉴 모바일에서 숨기기
	if($me_code == "30" || $me_code == "3010") {
		$me_mobile_use = 0;
	} 
	*/
	
	$sql = " insert into {$g5['menu_table']}
		   set me_code         = '$me_code',
				me_name         = '$me_name',
				me_link         = '$me_link',
				me_target       = 'self',
				me_order        = '0',
				me_use          = '$me_use',
				me_mobile_use   = '$me_mobile_use' ";
	sql_query($sql);
}
?>
