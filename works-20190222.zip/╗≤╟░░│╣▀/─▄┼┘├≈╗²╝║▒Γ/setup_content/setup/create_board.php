<?php
/* 휴온빌더 > 샘플용 게시판 자동생성
------------------------------------------------------ */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

$mb_id=$member[mb_id];

if($is_admin != "super") {
	alert("관리자로 로그인 후 실행하세요.", G5_BBS_URL."/login.php");
}

// 게시판이 이미 생성되어 있는지 확인
function exist_board($bo_table) {
	global $g5;

	$sql = " select count(*) as cnt from $g5[board_table] where bo_table='$bo_table' ";
	$row = sql_fetch($sql);
	if ($row[cnt]) {
		return true;
	} else {
		return false;
	}
}

$gr_id="hnbuilder";

//그룹 생성
$sql = " select count(*) as cnt from $g5[group_table] where gr_id = '$gr_id' ";
$row = sql_fetch($sql);
if (!$row[cnt]) {
	$sql = " insert into $g5[group_table] set gr_id = '$gr_id', gr_subject = '휴온빌더' ";
	sql_query($sql);
}

// 게시판 생성
$create_board = array(
	array("media", 	 "미디어", 	 "hn_media"),
	array("gallery", "갤러리", 	 "hn_gallery"),
	array("notice",  "공지사항", 	 "hn_basic"),
	array("qna", 	 "질문답변", 	 "hn_basic"),
	array("myqna", 	 "1:1문의", 	 "hn_basic"),
	array("bbs", 	 "자유게시판", "hn_basic")
);

//미디어, 갤러리 게시판
for($i=0; $i<2; $i++) {
	$bo_table = $create_board[$i][0];
	$bo_subject = $create_board[$i][1];
	$bo_skin = $create_board[$i][2];

	// 게시판이 존재하지 않으면 생성
	$is_exist = exist_board($bo_table);
	
	// 그누보드5 기본 세팅된 갤러리 스킨 업데이트
	if($bo_table == "gallery" && $is_exist) {
		$sql = "update {$g5['board_table']} 
				set bo_skin='{$bo_skin}', 
					bo_mobile_skin='{$bo_skin}',
					bo_write_level = '5',
					bo_gallery_cols = '3',
					bo_gallery_width='240',
					bo_gallery_height='170',
					bo_mobile_gallery_width='300',
					bo_mobile_gallery_height='250',
					bo_upload_count = '5',
					bo_upload_size  = '3145728'
					where bo_table='{$bo_table}' ";
		sql_query($sql);	
		
	// 게시판 생성	
	} else if (!$is_exist) {
		$sql = "insert into $g5[board_table] set
					gr_id = '$gr_id',
					bo_table = '$bo_table',
					bo_subject = '$bo_subject',
					bo_list_level = '1',
					bo_read_level = '1',
					bo_write_level = '5',
					bo_reply_level = '5',
					bo_comment_level = '5',
					bo_upload_level = '5',
					bo_download_level = '1',
					bo_html_level = '1',
					bo_link_level = '1',
					bo_count_modify = '3',
					bo_count_delete = '3',
					bo_use_file_content = '1',
					bo_use_dhtml_editor = '1',					
					bo_gallery_cols = '3',
					bo_gallery_width='230',
					bo_gallery_height='170',
					bo_mobile_gallery_width='150',
					bo_mobile_gallery_height='110',					
					bo_table_width='100',
					bo_subject_len='60',
					bo_page_rows='15',
					bo_new='24',
					bo_hot='100',
					bo_image_width='600',
					bo_use_sns='1',
					bo_skin = '{$bo_skin}',
					bo_mobile_skin='{$bo_skin}',
					bo_include_head='./_head.php',
					bo_include_tail='./_tail.php',					
					bo_mobile_subject_len='30',
					bo_mobile_page_rows='15',
					bo_upload_size = '3145728',
					bo_reply_order = '1',
					bo_use_search = '1',					
					bo_upload_count = '5'
					";
		sql_query($sql);

		// 게시판 테이블 생성
		$create_table = $g5[write_prefix].$bo_table;
	    $file = file(G5_ADMIN_PATH."/sql_write.sql");
	    $sql = implode($file, "\n");

	    // sql_board.sql 파일의 테이블명을 변환
	    $source = array("/__TABLE_NAME__/", "/;/");
	    $target = array($create_table, "");
	    $sql = preg_replace($source, $target, $sql);

	    sql_query($sql);

	    // 게시물 업데이트		
		if($bo_table == "media") {			
			$sql = "update {$g5['board_table']} set bo_use_file_content='1', bo_use_dhtml_editor = '0' where bo_table='$bo_table'";
			sql_query($sql);
			
			// 메인용
			$today = date("Y-m-d H:i:s");
			$page_content = "관리자로 로그인하여 메인이미지 파일을 추가하여주세요.\n이미지는 2개 이상, 이미지 폭은 보여질 곳의 폭(픽셀) 정도가 적당합니다. \n\n파일 설명은 캡션으로 표시되며, \'http://연결할 링크 주소\'로 입력하면 이미지 클릭시 해당 링크로 이동합니다.";			
			$wr_sql = "insert into $create_table set wr_subject='메인이미지', wr_content='$page_content', wr_num='-1', wr_parent='1', mb_id='$mb_id', wr_name='관리자',  wr_datetime='$today' ";
			sql_query($wr_sql);
			
			// 서브페이지용
			$page_content = "관리자로 로그인하여 서브이미지 파일을 추가하여 주세요.\n이미지는 2개 이상, 이미지 폭은 화면의 폭(픽셀) 정도가 적당합니다. \n\n파일 설명은 캡션으로 표시되며, \'http://연결할 링크 주소\'로 입력하면 이미지 클릭시 해당 링크로 이동합니다.";			
			$wr_sql = "insert into $create_table set wr_subject='서브이미지', wr_content='$page_content', wr_num='-2', wr_parent='2', mb_id='$mb_id', wr_name='관리자',  wr_datetime='$today' ";
			sql_query($wr_sql);	
		} 		
    } //end if
}

//일반게시판
for($i=2; $i<count($create_board); $i++) {
	$bo_table=$create_board[$i][0];
	$bo_subject=$create_board[$i][1];	
	$bo_skin = $create_board[$i][2];	
	
	// 게시판이 존재하지 않으면 생성
	$is_exist = exist_board($bo_table); 
	
	// 그누보드5 기본 세팅된 공지사항 스킨 업데이트
	if($bo_table == "notice" && $is_exist) {
		$sql = "update {$g5['board_table']} 
				set bo_skin='{$bo_skin}', 
					bo_mobile_skin='{$bo_skin}',
					bo_write_level = '5', 
					bo_reply_level = '5' 
					where bo_table='{$bo_table}' "; 
		sql_query($sql);
		
	// 게시판 생성	
	} else if (!$is_exist) {
		sql_query("delete from $g5[board_table] where bo_table='$bo_table' ");
		$sql = "insert into $g5[board_table] set
					gr_id = '$gr_id',
					bo_table = '$bo_table',
					bo_subject = '$bo_subject',
					bo_list_level = '1',
					bo_read_level = '1',
					bo_write_level = '1',
					bo_reply_level = '1',
					bo_comment_level = '1',
					bo_upload_level = '1',
					bo_download_level = '1',
					bo_html_level = '1',
					bo_link_level = '1',
					bo_count_modify = '3',
					bo_count_delete = '3',
					bo_gallery_cols = '3',
					bo_gallery_width='230',
					bo_gallery_height='170',
					bo_mobile_gallery_width='150',
					bo_mobile_gallery_height='110',					
					bo_table_width='100',
					bo_subject_len='60',
					bo_page_rows='15',
					bo_new='24',
					bo_hot='100',
					bo_image_width='600',
					bo_use_sns='1',
					bo_skin = '{$bo_skin}',
					bo_mobile_skin='{$bo_skin}',
					bo_include_head='./_head.php',
					bo_include_tail='./_tail.php',	
					bo_mobile_subject_len='30',
					bo_mobile_page_rows='15',
					bo_upload_size = '10485760',
					bo_reply_order = '1',
					bo_use_search = '1',					
					bo_upload_count = '2'
					";
		sql_query($sql);
		
		// 질문답변 - 비밀글 체크
		if($bo_table == "qna") {
			$sql = "update {$g5['board_table']} set bo_use_secret='1' where bo_table='$bo_table'";
			sql_query($sql);
		}
		
		// 주문게시판 상단스킨
		if($bo_table == "myqna") {
			$sql = "update {$g5['board_table']} set bo_include_head='./_head_myboard.php',
					bo_content_head = '1:1 문의는 회원 자신의 글만 확인할 수 있는 게시판입니다.' where bo_table='$bo_table'";
			sql_query($sql);
		} 

		// 게시판 테이블 생성
		$create_table = $g5[write_prefix].$bo_table;

	    $file = file(G5_ADMIN_PATH."/sql_write.sql");
	    $sql = implode($file, "\n");

	    // sql_board.sql 파일의 테이블명을 변환
	    $source = array("/__TABLE_NAME__/", "/;/");
	    $target = array($create_table, "");
	    $sql = preg_replace($source, $target, $sql);
	    sql_query($sql);
	} // --- 게시판 생성 끝 ---
}
?>
