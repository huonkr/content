<?php
/* 휴온빌더 > 샘플용 콘텐츠 자동생성
------------------------------------------------------ */
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

$mb_id=$member[mb_id];

if($is_admin != "super") {
	alert("관리자로 로그인 후 실행하세요.", G5_BBS_URL."/login.php");
}

// content - 내용 추가
$contents = array();
$contents['content1'] = "콘텐츠1";
$contents['content2'] = "콘텐츠2";

foreach( $contents as $key => $value ){
	$content_sample = get_html_content($key);
	
	$c_row=sql_fetch("select count(*) as cnt from {$g5['content_table']} where co_id = '$key'");
	if(!$c_row['cnt']) { 		
		$sql = "insert {$g5['content_table']} 
				set  co_id = '$key',
				co_html    = '1',                
				co_subject = '$value',
				co_content = '".$content_sample."',
				co_skin    = 'hn_basic',
				co_mobile_skin = 'hn_basic'
				";
				
				echo $sql;
		sql_query($sql);
	} else {
		$sql = "update {$g5['content_table']} 
				set co_html    = '1',                
				co_subject = '$value',
				co_content = '".$content_sample."',
				co_skin    = 'hn_basic',
				co_mobile_skin = 'hn_basic'
				where co_id = '$key'
				";
		sql_query($sql);
	}
}

function get_html_content($content_name) {	
	$content_file = "../content/".$content_name.".html";

	if ( is_file($content_file) ) {
		// 콘텐츠 import
		$html = file_get_contents($content_file);		
		$delete_str = array(
			'<meta charset="utf-8">',
			'<link rel="stylesheet" href="../css/site.css">',
			'<link rel="stylesheet" href="../js/font-awesome/css/font-awesome.min.css">',
			'<script src="../js/jquery-1.8.3.min.js"></script>'
		);	
		
		// 주석 제거		
		$html = preg_replace('/<!--(.*?)-->/is', '', $html);
		$html = str_replace($delete_str, "", $html);		
		$content = addslashes(trim($html));		
		return $content;		
	} else {
		return "<p style=\"text-align:center;\">콘텐츠 준비중입니다.</p>";
	}
}
?>
