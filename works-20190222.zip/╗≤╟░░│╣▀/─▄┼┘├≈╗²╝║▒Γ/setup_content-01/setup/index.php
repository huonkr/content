<?php
include_once("./_common.php");

$page_title = "휴온빌더 셋업 설정";

include_once("./_head.php");

if ($is_admin != "super") {
	alert("관리자로 로그인 후 실행하세요.", G5_BBS_URL."/login.php");
}

// 사이트명
if (!$_GET['sitename']) {
	$sitename = $config['cf_title'];	
?>

<style>
.container {  
	position: relative; width:500px; margin:5em auto;
	vertical-align:middle; white-space:nowrap;	
}
.container label { display:inline-block; min-width:100px; height:35px; line-height:35px; border-left:5px solid #3DA5D6; padding-left:.5em;  }
</style>


<div class="container">
	<form action="#">
	
	<div class="infoBox blue">사이트명을 입력하세요.</div>
	
	<br>
	
	<label for="sitename">사이트명</label>
	<input type="text" name="sitename" value="<?php echo $sitename;?>" id="sitename" size="30" maxlength="255">
	
	 <input type="submit" value="확인">
	</form>
</div>



<?php 
} else {
	//### 기본환경설정과 기본게시판 생성 ###
	//============================================================================================
	include_once(G5_PATH."/setup/hn_config.php");
	include_once(G5_PATH."/setup/create_board.php");
	include_once(G5_PATH."/setup/create_content.php");
	include_once(G5_PATH."/setup/create_menu.php");
	//============================================================================================


	// alert("휴온빌더의 기본 게시판과 메뉴가 생성되었습니다.\\n\\n이제 \'setup\' 폴더는 삭제하셔도 됩니다.\\n", G5_URL."/index.php");
	alert("휴온빌더의 기본 게시판과 메뉴가 생성되었습니다.\\n\\n이제 \'setup\' 폴더는 삭제하셔도 됩니다.\\n");
	// goto_url(G5_URL);
}

include_once("./_tail.php");
?>
