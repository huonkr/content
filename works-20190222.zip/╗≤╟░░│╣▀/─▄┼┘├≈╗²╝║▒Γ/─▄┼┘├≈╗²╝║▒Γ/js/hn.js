$(function() {
	// menu nav - superfish
	var menu_option1 = { delay: 800, animation: {opacity:'show'}, speed: 'fast', cssArrows:false };
	var menu_option2 = { delay: 0, animation: { opacity:'show', height:'show'}, cssArrows:false }
	var menu_option;
	
	if ( $(window).width() > 768 ) {
		menu_option = menu_option1;
	} else {
		menu_option = menu_option2;
	}
	var mainmenu = $('#mainmenu').superfish(menu_option);
	
	// 반응형 모바일화면 메뉴
	$('.nav-toggle-icon').toggle(function() {
		$( this ).addClass("active");
		$('#globalnav').show();		
	}, function() {
		$( this ).removeClass("active");			
		$('#globalnav').hide();
	});
	
	$( window ).resize(function() {
		var win_width = $(this).width();
		if ( win_width > 780 && $('#globalnav:hidden') ) {
			$('#globalnav').fadeIn("fast");
			mainmenu.superfish('destroy');
			mainmenu = $('#mainmenu').superfish(menu_option1);			
		} else if ( win_width < 750 && $('#globalnav:visible') ) {			
			$('#globalnav').hide();
			$('.nav-toggle-icon').removeClass("active");	
			mainmenu.superfish('destroy');
			mainmenu = $('#mainmenu').superfish(menu_option2);
		}
	});


	// toTop
	var $toTop = $('#toTop');
	var show_top = $('#header').height()+50;
	var fixed_bottom = $('#footer').height()+$toTop.height()+20;
	
	if ($toTop.length > 0) {
		$toTop.hide();
		$(window).scroll(function () {
			var footer_offset = $('#footer').offset();
			var scroll_bottom = $(window).scrollTop()+$(window).height();

			if ($(this).scrollTop() > show_top) {
				$toTop.fadeIn();
			} else {
				$toTop.fadeOut();
			}

			if(footer_offset.top < scroll_bottom) {
				$toTop.css({'bottom': fixed_bottom+'px'});
			} else {
				$toTop.css({'bottom': '20px'});
			}

			// console.log("footer:"+footer_offset.top + ", window: " + scroll_bottom);
		});
		$toTop.click(function () {
			$('html, body').animate({scrollTop: 0}, 500);
			return false;
		});
	}
	
		
	// 상단으로
	$('#ft_totop').click(function () {
		$('body,html').animate({
			scrollTop: 0
		}, 300);
		return false;
	});


	// 북마크
	$('#bookmark').click(function(e){
		var url = this.href;
		var bookmarkTitle = this.title;

		if (navigator.userAgent.indexOf("Chrome") > -1 || navigator.userAgent.indexOf("Safari") > -1) {
			alert("Ctrl+D 를 누르면 북마크에 추가할 수 있습니다.");
		} else if (window.external) {
			  window.external.AddFavorite(url, bookmarkTitle);
		} else if (window.sidebar) {
			  window.sidebar.addPanel(bookmarkTitle, url, "");
		 } else if (window.opera && window.print) {
			  var $this = $(this);
			  $this.attr('href',url);
			  $this.attr('title',bookmarkTitle);
			  $this.attr('rel','sidebar');
		 } else {
			  alert('죄송합니다. 이 브라우저는 즐겨찾기를 지원하지 않습니다.');
		 }

		 e.preventDefault();
	});
});




// 파일 미리보기 - by 휴온, 2019.01
$(function() {
	$(".bf-file input[type=file]").live('change', fileHandler);
});

function fileHandler(event) {	 
	 var input = event.target;
	 var files = input.files;
	 var input_type = input.files[0].type;
	 
	 console.log(input_type); 
	 
	 $(input).prev().remove();
	 
	 if (input.files[0]) {
		 // image
		 if (input_type.match("image.*")) {
			//파일을 읽기 위한 FileReader객체 생성
			var reader = new FileReader();  
			
			//파일 읽어들이기를 성공시
			reader.onload = function (e) {
				$(input).prev('img').remove();
				$(input).before('<img src="' + e.target.result + '" class="preview">');
			};

			//File 내용을 읽어 dataURL 형식의 문자열로 저장
			reader.readAsDataURL(input.files[0]); 
		// text	
		} else if (input_type.match("text.*")) {
			$(input).before('<i class="fa fa-file-text-o" aria-hidden="true"></i>');
		// audio	
		} else if (input_type.match("audio.*")) {			
			$(input).before('<i class="fa fa-file-audio-o" aria-hidden="true"></i>');
		// video	
		} else if (input_type.match("video.*")) {
			$(input).before('<i class="fa fa-file-video-o" aria-hidden="true"></i>');
		// application	
		} else if (input_type.match("application.*")) {
			$(input).before('<i class="fa fa-file-o" aria-hidden="true"></i>');
		} else {
			$(input).before('<i class="fa fa-file" aria-hidden="true"></i>');
		}
	 }
};