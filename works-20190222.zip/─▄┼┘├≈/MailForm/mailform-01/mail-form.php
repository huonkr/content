<?php
include_once('./_common.php');

include_once(G5_PATH.'/_head.php');
?>



<!-- mailform -->
<div style="width:100%; height:100%; background:#f7f8fa; border-top:2px solid #3dafe2; box-sizing:border-box;">

<!-- header -->
<div style="padding:30px 0; text-align:center;">
<h2 style="padding:0; margin:0; font-size:36px; font-weight:700; color:#fff; text-shadow:0 0 3px #333;  "><?php echo $config['cf_title']?></h2>
</div>


<!-- mail content -->
<div style="max-width:900px; width:80%; padding:1.7em 1.5em; margin:0 auto 30px;  background:#fff; border-radius:.5em; box-shadow:0 1px 5px rgba(25,25,25,.3);">


내용을 입력하세요.


</div><!-- /mail content -->


<!-- footer -->
<div style="margin-bottom:30px; text-align:center; font-size:11px; color:#555;">
<a href="<?php echo G5_URL;?>" target="_blank" style="color:#445566;text-decoration:none;font-weight:bold;">Copyright ⓒ <?php echo $config['cf_title']?>. All Rights Reserved.</a>
</div>

</div><!-- /mailform -->

	
	
	
<?php
include_once(G5_PATH.'/_tail.php');
?>
