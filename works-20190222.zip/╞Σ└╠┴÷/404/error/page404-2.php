<?php
include_once('./_common.php');

$page_title = "PAGE NOT FOUND";

include_once("./_head.php");
?>
<style>
html, body { height:100%; padding:0; margin:0; }

#page404 { width:100%; height:100%; background-color:#eff2f3; font-size:14px; line-height:1.6em; }
#page404 h1 { 
	padding:1em 0; margin:0 auto; letter-spacing:-2px;
	font-family: Lora, serif, verdana, tahoma, sans-serif; font-weight: bold; font-size:5rem; color:#a0c4d5; text-align:center;  
}
.page-content { 
	width:600px; padding:5em 2em 3em; margin:0 auto; 
	background:#fff; border:1px solid #d1d1d1; border-radius:10px; 
	box-shadow:0 2px 10px rgba(25,25,25,.3); 
	text-align:center;
}
.page-content h2 { margin:0; padding:0 0 1em; font-size:3rem; color:#2e2e2e; }

.page-footer { margin:3em 0; font-size:13px; text-align:center; }


#page404 .btn { padding:2em 0; vertical-align:middle;}
#page404 a:link,
#page404 a:visited { color:#2292c6; text-decoration:none; vertical-align:middle; }
#page404 a:hover { color: #71bbdd; text-decoration: underline; }
#page404 .bar { padding:0 10px; font-size:11px; color:#a0a0a0; }
</style>
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

<div id="page404">	

	<h1>404 ERROR</h1>

	<div class="page-content">
		<h2>LOGO</h2>
		
		<p>
		불편을 드려 죄송합니다.<br>
		요청하신 페이지를 찾을 수 없습니다.<br>
		<br>
		입력하신 페이지 주소가 잘못되었거나, <br>
		변경 혹은 삭제로 인해 페이지를 찾을 수 없습니다.		
		</p>
		
		<p class="btn">
			<a href="javascript:history.back()" title="이전페이지로 이동합니다.">이전페이지</a> 
			<span class="bar">|</span>   
			<a href="<?php echo G5_URL?>">Back to HOME</a>
			<span class="bar">|</span>   
			<a href="mailto:<?php echo $config['cf_admin_email']; ?>">관리자 이메일</a>		  
		</p>
	</div>

	<div class="page-footer">
		고객센터 Tel.전화번호<br>		
		Copyright © 사이트. All rights reserved.
	</div>

</div><!-- /page404 -->


<?php
include_once("./_tail.php");
?>
