<?php
include_once('./_common.php');

$page_title = "Coming Soon Page";
$page_description = "Under Construction";

include_once("./_head.php");
?>
<style>
html, body{ height:100%; padding:0; margin:0; }
#comingSoon {
	position:relative; 
	width:100%; height:100%; 
	background:#333 url(img/westrock.jpg) no-repeat center center; background-size:cover; 
	
}
.inner-content {
	position:absolute;
	left:50%; top:45%;
	-webkit-transform: translate(-50%, -50%);
	-ms-transform: translate(-50%, -50%);
	transform: translate(-50%, -50%);	
	text-align:center; vertical-align:middle;
}
.content-text {
	display:inline-block; padding:3em; background-color:#eee;
	font-size:14px; text-align:center; line-height:1.8em; color:#111; vertical-align:middle;
}
.footer {
    position:absolute; left:0; bottom:0; width:100%; box-sizing:border-box; 
    padding:10px; font-size:13px; text-align:center; color:#fff; 
}

@media (min-width:769px) and (max-width:1024px) {  
	.inner-content { margin-left:0; }
}
</style>
<div id="comingSoon">
	<div class="inner-content">
		<div class="content-text">
		<h1>Coming Soon</h1>
		<p>안내글</p>
		</div>
	</div>
</div>

<div class="footer">
Copyright © 2020 Huon. Designed by huon.co.kr
</div>

<?php
include_once("./_tail.php");
?>
